﻿unit Curriculum_U;

interface

type
  TFAQ = record
    iSubject: Integer;  // 0 = both subjects.
    sPrompt, sKeywords, sAnswer: string;
  end;

const
  iCAT = 1;
  iIT = 2;
  arrSubject: array[1..2] of string = ('CAT', 'IT');
  arrSubjectName: array[1..2] of string =
    ('Computer Applications Technology', 'Information Technology');
  arrIntro: array[1..2] of string = (
    'Teach learners to solve meaningful problems with applications. Model a realistic task, then ask each learner to explain a choice made in a document, spreadsheet, database or web page.',
    'Teach learners to design, implement and test solutions. Model the reasoning before showing Delphi code, then assess whether learners can trace and explain their own solutions.');

  arrCAPSUrl: array[1..2] of string = (
    'https://www.education.gov.za/Portals/0/CD/National%20Curriculum%20Statements%20and%20Vocational/CAPS%20FET%20_%20COMPUTER%20APPLICATIONS%20TECHNOLOGY%20_%20GR%2010-12%20_%20Web_6AC6.pdf',
    'https://www.education.gov.za/Portals/0/CD/National%20Curriculum%20Statements%20and%20Vocational/CAPS%20FET%20_%20INFORMATION%20TECHNOLOGY%20_%20GR%2010-12%20_%20Web_E677.pdf');
  sCAPSUpdateUrl = 'https://www.education.gov.za/LinkClick.aspx?fileticket=R5nrN-u0KdY%3D&mid=13958&portalid=0&tabid=587';
  sCircularUrl = 'https://www.education.gov.za/Curriculum/NationalCirculars.aspx';
  sATPFETUrl = 'https://www.education.gov.za/Curriculum/NationalCurriculumStatementsGradesR-12/2023ATPsFET.aspx';
  sPATUrl = 'https://www.education.gov.za/Curriculum/NationalCurriculumStatementsGradesR-12/Grade12PATs2026.aspx';

  // First dimension = subject. Second dimension = grade.
  // These are the 2026 document links listed on IT & CAT in EC's teacher page.
  arrATPUrl: array[1..2, 10..12] of string = (
    ('https://drive.google.com/file/d/1lKwU3ooLmBlOBVujO88aRVEbA-W0JQt0/view',
     'https://drive.google.com/file/d/1wMNvPvJLZjy9lmZ2KMGnsgp1wonlEZjx/view',
     'https://drive.google.com/file/d/1_l5MbLjnU7Fnq1j2Fku8lx0C9Fb9VMZ5/view'),
    ('https://drive.google.com/file/d/1uN0dZr9LR4axxen6uhhw0Idpi5oZI2oY/view',
     'https://drive.google.com/file/d/1ktE7fmSAIZVynfW_WNBfvT5SBtnV5Wed/view',
     'https://drive.google.com/file/d/1n1Lf80jM8h0oM2JzpiDCFIKFEaUHzn5u/view')
  );

  // Shared entries and subject-specific entries use a single editable array.
  arrFAQ: array[1..15] of TFAQ = (
    (iSubject: 0; sPrompt: 'What is the difference between CAPS and the ATP?';
     sKeywords: 'caps|atp|policy|pacing|curriculum|teaching plan';
     sAnswer: 'CAPS sets out the curriculum and assessment policy. The ATP helps you sequence the content across the year. Open CAPS and ATP, select the grade, and compare both documents before planning a term. For 2026, check DBE Circulars S9 and S19 of 2025 and any newer directive from your province.'),
    (iSubject: 0; sPrompt: 'How do I set up the Grade 12 PAT?';
     sKeywords: 'pat|practical assessment task|phase|submission';
     sAnswer: 'Use the current DBE Grade 12 PAT pack for your subject and year. Read the learner instructions and teacher guidance, build a milestone calendar from the published requirements, and retain process evidence. Confirm school deadlines and moderation dates with your subject head.'),
    (iSubject: 0; sPrompt: 'How do I plan SBA and record marks?';
     sKeywords: 'sba|weight|weighting|marks|programme of assessment|formal task';
     sAnswer: 'Build a term assessment calendar using the applicable CAPS assessment section, the current programme of assessment and any circular that amends it. Record each task in the school-approved mark system and keep the task, marking instrument and sample evidence for moderation.'),
    (iSubject: 0; sPrompt: 'What should I keep for moderation?';
     sKeywords: 'moderation|moderate|teacher file|evidence';
     sAnswer: 'Ask your subject head for the district or school checklist. Prepare the task, memo or rubric, assessment record, representative learner evidence and notes on changes made after moderation. Keep evidence in the school-approved location with restricted access.'),
    (iSubject: 0; sPrompt: 'How can I teach during a power outage?';
     sKeywords: 'power outage|load shedding|loadshedding|electricity|offline|internet|connectivity';
     sAnswer: 'Keep a paper copy of the task and a small dataset for each group. Learners can predict formulas, trace algorithms or annotate a plan during the outage. When the lab is available again, have each learner apply and verify their work individually.'),
    (iSubject: 0; sPrompt: 'What if learners share computers?';
     sKeywords: 'share|shared computers|devices|limited computers|lab|pairs';
     sAnswer: 'Use pairs with a driver and a navigator. Switch roles at a checkpoint and require an individual exit task. For formal practical assessments, confirm the approved arrangements with the school exam team.'),
    (iSubject: 0; sPrompt: 'How should I handle learner privacy and AI?';
     sKeywords: 'privacy|popia|personal data|ai|chatgpt|names';
     sAnswer: 'Use fictional names and sample data in demonstrations. Keep learner marks and PAT files in approved systems. Apply the school policy on AI-assisted work, tell learners what evidence of authorship you need, and check their understanding through a short explanation or demonstration.'),
    (iSubject: 0; sPrompt: 'How do I support an approved exam concession?';
     sKeywords: 'concession|accommodation|extra time|accessibility|reader';
     sAnswer: 'Check the learner''s approved accommodation through the school exam coordinator. Confirm the venue, equipment and arrangements ahead of the session. Practise the approved setup with a non-exam task.'),
    (iSubject: 0; sPrompt: 'Where do I find NSC practical exemplars?';
     sKeywords: 'nsc|exam|paper 1|paper 2|exemplar|past papers';
     sAnswer: 'Use DBE past papers with the matching memo and practical data files. Select questions that match the grade and topics already taught. Use a short timed practice and then have learners explain where they lost marks. Check the current exam guidance with your subject head.'),
    (iSubject: 1; sPrompt: 'How do I teach spreadsheet formulas in CAT?';
     sKeywords: 'spreadsheet|formula|excel|countblank|counta|reference';
     sAnswer: 'Use a small fictional sales sheet. Ask learners to predict results with a few rows, enter a formula, fill it down and check whether references change as intended. Increase the difficulty by adding blanks, text and five rows of unseen data.'),
    (iSubject: 1; sPrompt: 'How do I introduce Access or database queries in CAT?';
     sKeywords: 'access|database|query|queries|criteria';
     sAnswer: 'Start with a question that a school club could ask of a fictional membership list. Learners select fields, set one criterion, and compare the result with a hand-checked list. Add a second criterion once they can explain the first result.'),
    (iSubject: 1; sPrompt: 'How do I assess CAT word processing or HTML?';
     sKeywords: 'word processing|word|html|web design|website';
     sAnswer: 'Give a realistic brief with a target audience. In a document task, assess styles, structure and consistency. In an HTML task, assess the specified elements and test the saved page locally. Ask learners to explain one design decision.'),
    (iSubject: 2; sPrompt: 'How should I start teaching Delphi?';
     sKeywords: 'delphi|programming|first lesson|input|variables';
     sAnswer: 'Start with a short input-process-output problem. Name each component before coding, model an event handler, then ask learners to trace an example and change one condition. Check both the program result and their explanation.'),
    (iSubject: 2; sPrompt: 'How do I teach arrays and debugging?';
     sKeywords: 'array|arrays|debug|debugging|loop|trace|index';
     sAnswer: 'Have learners trace the index, current value and accumulator in separate columns. Use first, last and repeated values during testing. Compare expected and actual results, find the first divergence, revise the code and rerun the same tests.'),
    (iSubject: 2; sPrompt: 'How do I teach SQL and relational databases in IT?';
     sKeywords: 'sql|relational|database|query|queries|join';
     sAnswer: 'Use a small fictional dataset. Ask learners to predict the rows selected by a filter, run the query and compare the result. For joins, mark the keys on paper and trace a matching pair of records before using a larger database.')
  );

function CAPSGuide(iSubject, iGrade: Integer): string;
function ATPGuide(iSubject, iGrade, iTerm: Integer): string;
function BotAnswer(iSubject: Integer; const sQuestion: string): string;

implementation

uses
  System.SysUtils;

const
  // Examples unpack a curriculum strand and show possible classroom evidence.
  arrGradeExample: array[1..2, 10..12] of string = (
    ('Use a fictional shop spreadsheet to distinguish data from information. Model a formula and ask learners to explain how its result answers a question.',
     'Use a fictional club database to practise extracting records. Have learners choose a criterion and explain which records it includes.',
     'Use the PAT brief to connect information gathering, application skills and a coherent report. Ask learners to justify the software used for each product.'),
    ('Use a small Delphi input-process-output task. Have learners trace a formula and test numeric boundary values.',
     'Use a dataset or array to practise decomposition, searching and test design. Compare the result against a table trace.',
     'Use an integrated programming task to connect data, interface and implementation. Have learners explain a chosen test and justify the expected result.')
  );
  arrTermFocus: array[1..4] of string = (
    'Map the first teaching weeks, find prerequisite knowledge and plan a short baseline activity.',
    'Check the actual teaching days and mid-year assessment window. Stage practical activities from guided examples to individual work.',
    'Identify gaps from the previous term. Check PAT milestones in the relevant official pack and plan time to review evidence.',
    'Use the current plan to distinguish new content from consolidation. Mark assessment windows and plan targeted revision.'
  );

function CAPSGuide(iSubject, iGrade: Integer): string;
var
  sStrands: string;
begin
  // Keep document navigation distinct from illustrative teaching guidance.
  if iSubject = iCAT then
    sStrands := 'Systems, networks, internet technologies, information management, social implications and solution development using applications.'
  else
    sStrands := 'Solution development, communication, systems, internet technologies, data and information management, and social implications.';

  Result := 'CAPS POLICY GUIDE' + sLineBreak + arrSubject[iSubject] + ' GRADE ' +
    IntToStr(iGrade) + sLineBreak + sLineBreak +
    'Start with Section 2 to check the subject aims and resources. Use Section 3 ' +
    'and the applicable amendments to locate the grade content. Use Section 4 ' +
    'and current assessment directives to verify formal requirements.' + sLineBreak + sLineBreak +
    'SUBJECT STRANDS' + sLineBreak + sStrands + sLineBreak + sLineBreak +
    'CLASSROOM EXAMPLE' + sLineBreak + arrGradeExample[iSubject, iGrade] +
    sLineBreak + sLineBreak + 'PLANNING EVIDENCE' + sLineBreak +
    'Write one measurable learning intention and one example of learner work ' +
    'that would show the intention was met.' + sLineBreak + sLineBreak +
    'Source: DBE CAPS Grades 10-12. Read with the CAT/IT amendments and current circulars.';
end;

function ATPGuide(iSubject, iGrade, iTerm: Integer): string;
begin
  // Give planning actions for the chosen term without assigning unverified weeks.
  Result := 'ATP PLANNING GUIDE' + sLineBreak + arrSubject[iSubject] + ' GRADE ' +
    IntToStr(iGrade) + '  /  TERM ' + IntToStr(iTerm) + sLineBreak + sLineBreak +
    'Open the linked 2026 grade ATP or a school-supplied PDF and find the ' +
    'Term ' + IntToStr(iTerm) + ' table. Confirm the subject, grade, language and ' +
    'version with your subject head or advisor.' + sLineBreak + sLineBreak +
    'TERM CHECKPOINT' + sLineBreak + arrTermFocus[iTerm] + sLineBreak + sLineBreak +
    'FROM THE ATP TO YOUR WEEKLY PLAN' + sLineBreak +
    '1. Record the week, topic and planned time from the official table.' + sLineBreak +
    '2. Match the topic to a CAPS skill and choose a practical learning task.' + sLineBreak +
    '3. Record formative evidence, school assessment dates and a recovery slot.' + sLineBreak +
    '4. Track actual coverage and agree on any necessary adjustment with your subject head.' +
    sLineBreak + sLineBreak +
    '2026 reference: DBE Circular S19 of 2025 excludes CAT and IT from the general ' +
    'ATP rollover and refers to Circular S9 of 2025. The 2026 ATP links come from ' +
    'the IT & CAT in EC teacher resource hub. Use the circulars and the copy issued ' +
    'to your school to verify applicability.';
end;

function SearchableWords(const sValue: string): string;
var
  iChar: Integer;
  cValue: Char;
  sLower: string;
begin
  // Treat punctuation as word breaks so "pat" never matches "pattern".
  sLower := LowerCase(sValue);
  Result := ' ';
  for iChar := 1 to Length(sLower) do
  begin
    cValue := sLower[iChar];
    if CharInSet(cValue, ['a'..'z', '0'..'9']) then
      Result := Result + cValue
    else if Result[Length(Result)] <> ' ' then
      Result := Result + ' ';
  end;
  if Result[Length(Result)] <> ' ' then
    Result := Result + ' ';
end;

function HasPhrase(const sWords, sPhrase: string): Boolean;
var
  iStart: Integer;
begin
  // A simple loop performs the whole-phrase match.
  Result := False;
  for iStart := 1 to Length(sWords) - Length(sPhrase) + 1 do
    if Copy(sWords, iStart, Length(sPhrase)) = sPhrase then
      Exit(True);
end;

function BotAnswer(iSubject: Integer; const sQuestion: string): string;
var
  iTopic, iChar, iStart, iScore, iBest, iBestScore: Integer;
  sWords, sKeywords, sKeyword: string;
begin
  // Match an exact suggested prompt first. Otherwise score applicable topics.
  sWords := SearchableWords(sQuestion);
  iBest := 0;
  iBestScore := 0;
  for iTopic := Low(arrFAQ) to High(arrFAQ) do
  begin
    if (arrFAQ[iTopic].iSubject <> 0) and (arrFAQ[iTopic].iSubject <> iSubject) then
      Continue;
    if sWords = SearchableWords(arrFAQ[iTopic].sPrompt) then
      Exit(arrFAQ[iTopic].sAnswer);
    sKeywords := arrFAQ[iTopic].sKeywords + '|';
    iScore := 0;
    iStart := 1;
    for iChar := 1 to Length(sKeywords) do
      if sKeywords[iChar] = '|' then
      begin
        sKeyword := Copy(sKeywords, iStart, iChar - iStart);
        if HasPhrase(sWords, SearchableWords(sKeyword)) then
          Inc(iScore, 1 + Length(sKeyword));
        iStart := iChar + 1;
      end;
    if iScore > iBestScore then
    begin
      iBestScore := iScore;
      iBest := iTopic;
    end;
  end;
  // Keep policy judgments with the applicable documents and school staff.
  if iBest > 0 then
    Result := arrFAQ[iBest].sAnswer
  else
    Result := 'I could not match that question. Try one topic such as PAT, SBA, ' +
      'moderation, load shedding or CAPS and ATP. Ask your subject head or ' +
      'advisor for school-specific decisions.';
end;

end.
