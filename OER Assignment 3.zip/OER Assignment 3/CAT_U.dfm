object frmCAT: TfrmCAT
    ClientWidth = 1120
    ClientHeight = 744
    Color = $00E5EDF5
    Font.Name = 'Segoe UI'
    Font.Height = -16
    Scaled = True
    PixelsPerInch = 96
    Caption = 'Beyond the Computer Lab'
    Position = poScreenCenter
    Constraints.MinWidth = 1136
    Constraints.MinHeight = 720
    OnCloseQuery = FormCloseQuery
  object pnlHeader: TPanel
      Left = 0
      Top = 0
      Width = 1120
      Height = 96
      Color = $00273338
      ParentBackground = False
      BevelOuter = bvNone
      Align = alTop
    object shpHeaderAccent: TShape
      Align = alBottom
      Height = 3
      Brush.Color = $007BCADF
      Pen.Style = psClear
    end
    object lblBrand: TLabel
        Left = 24
        Top = 16
        Width = 590
        Height = 38
        Caption = 'Beyond the Computer Lab'
        AutoSize = False
        Font.Height = -30
        Font.Color = clWhite
        Font.Style = [fsBold]
        ParentFont = False
    end
    object lblAudience: TLabel
        Left = 25
        Top = 59
        Width = 620
        Height = 22
        Caption = 'Cape Lab Field Guide'
        AutoSize = False
        Font.Height = -15
        Font.Color = $007BCADF
        Font.Style = []
        ParentFont = False
    end
    object lblSubjectGrade: TLabel
      Left = 858
      Top = 19
      Width = 236
      Height = 22
      Caption = 'CAT for Grades 10-12'
      AutoSize = False
      Anchors = [akTop, akRight]
      Alignment = taRightJustify
      Font.Color = clWhite
      ParentFont = False
    end
    object btnSubjectMenu: TButton
      Left = 906
      Top = 50
      Width = 188
      Height = 30
      Caption = '&Subject menu'
      OnClick = btnSubjectMenuClick
      Anchors = [akTop, akRight]
    end
  end
  object pnlSidebar: TPanel
      Left = 16
      Top = 111
      Width = 270
      Height = 617
      Color = clWhite
      ParentBackground = False
      BevelOuter = bvNone
      Anchors = [akLeft, akTop, akBottom]
    object lblBrowse: TLabel
        Left = 15
        Top = 14
        Width = 237
        Height = 23
        Caption = 'Activity library'
        AutoSize = False
        Font.Height = -18
        Font.Color = $00344853
        Font.Style = [fsBold]
        ParentFont = False
    end
    object lblSearch: TLabel
        Left = 15
        Top = 49
        Width = 235
        Height = 20
        Caption = '&Search the guide'
        AutoSize = False
        Font.Height = -14
        Font.Color = $00455860
        Font.Style = []
        ParentFont = False
        FocusControl = edtSearch
    end
    object edtSearch: TEdit
        Left = 15
        Top = 71
        Width = 240
        Height = 28
        OnChange = edtSearchChange
        TextHint = 'Try privacy or spreadsheets'
    end
    object lblCategory: TLabel
        Left = 15
        Top = 110
        Width = 235
        Height = 20
        Caption = '&Category'
        AutoSize = False
        Font.Height = -14
        Font.Color = $00455860
        Font.Style = []
        ParentFont = False
        FocusControl = cmbCategory
    end
    object cmbCategory: TComboBox
        Left = 15
        Top = 132
        Width = 240
        Height = 29
        Style = csDropDownList
        OnChange = cmbCategoryChange
    end
    object lblMatch: TLabel
        Left = 15
        Top = 170
        Width = 240
        Height = 20
        Caption = 'Loading activities'
        AutoSize = False
        Font.Height = -14
        Font.Color = $00455860
        Font.Style = []
        ParentFont = False
    end
    object lstActivity: TListBox
        Left = 15
        Top = 194
        Width = 240
        Height = 320
        Anchors = [akLeft, akTop, akBottom]
        Style = lbOwnerDrawFixed
        ItemHeight = 29
        OnDrawItem = lstActivityDrawItem
        OnClick = lstActivityClick
    end
    object lblCompletion: TLabel
        Left = 15
        Top = 525
        Width = 240
        Height = 22
        Caption = 'Quiz progress'
        AutoSize = False
        Font.Height = -14
        Font.Color = $00455860
        Font.Style = []
        ParentFont = False
        Anchors = [akLeft, akBottom]
    end
    object prgCompletion: TProgressBar
        Left = 15
        Top = 552
        Width = 240
        Height = 8
        Anchors = [akLeft, akBottom]
        Max = 8
        Smooth = True
    end
    object btnHome: TButton
        Left = 15
        Top = 572
        Width = 240
        Height = 30
        Caption = '&Introduction'
        OnClick = btnHomeClick
        Anchors = [akLeft, akBottom]
    end
  end
  object pgcMain: TPageControl
      Left = 300
      Top = 111
      Width = 803
      Height = 617
      Anchors = [akLeft, akTop, akRight, akBottom]
      ActivePage = tabIntro
    object tabIntro: TTabSheet
        Caption = 'Introduction'
      object lblWelcome: TLabel
          Left = 24
          Top = 24
          Width = 720
          Height = 48
          Caption = 'Plan your next lab lesson'
          AutoSize = False
          Font.Height = -28
          Font.Color = $00344853
          Font.Style = [fsBold]
          ParentFont = False
          Anchors = [akLeft, akTop, akRight]
      end
      object memIntroduction: TMemo
          Left = 24
          Top = 87
          Width = 746
          Height = 397
          ReadOnly = True
          ScrollBars = ssVertical
          Anchors = [akLeft, akTop, akRight, akBottom]
          TabStop = False
          BorderStyle = bsNone
          Color = clWhite
      end
      object btnStart: TButton
          Left = 24
          Top = 509
          Width = 190
          Height = 38
          Caption = '&Start exploring'
          OnClick = btnStartClick
          Anchors = [akLeft, akBottom]
      end
    end
    object tabGuide: TTabSheet
        Caption = 'Read the guide'
      object lblGuideCategory: TLabel
          Left = 24
          Top = 12
          Width = 745
          Height = 21
          Caption = 'Activity'
          AutoSize = False
          Font.Height = -14
          Font.Color = $00455860
          Font.Style = []
          ParentFont = False
          Anchors = [akLeft, akTop, akRight]
      end
      object lblGuideTitle: TLabel
          Left = 24
          Top = 36
          Width = 745
          Height = 38
          Caption = 'Activity'
          AutoSize = False
          Font.Height = -26
          Font.Color = $00344853
          Font.Style = [fsBold]
          ParentFont = False
          Anchors = [akLeft, akTop, akRight]
      end
      object redGuide: TRichEdit
          Left = 24
          Top = 83
          Width = 746
          Height = 392
          ReadOnly = True
          ScrollBars = ssVertical
          Anchors = [akLeft, akTop, akRight, akBottom]
      end
      object btnOpenQuiz: TButton
          Left = 24
          Top = 509
          Width = 142
          Height = 38
          Caption = '&Topic quiz'
          OnClick = btnOpenQuizClick
          Anchors = [akLeft, akBottom]
      end
      object btnOpenPlan: TButton
          Left = 176
          Top = 509
          Width = 158
          Height = 38
          Caption = 'Lesson &planner'
          OnClick = btnOpenPlanClick
          Anchors = [akLeft, akBottom]
      end
      object btnTopicResource: TButton
          Left = 344
          Top = 509
          Width = 184
          Height = 38
          Caption = '&Additional resource'
          Enabled = False
          OnClick = btnTopicResourceClick
          Anchors = [akLeft, akBottom]
      end
      object btnTopicReference: TButton
          Left = 538
          Top = 509
          Width = 170
          Height = 38
          Caption = 'Paper &reference'
          Enabled = False
          OnClick = btnTopicReferenceClick
          Anchors = [akLeft, akBottom]
      end
    end
    object tabQuiz: TTabSheet
        Caption = 'Section quiz'
      object lblQuizTitle: TLabel
          Left = 24
          Top = 18
          Width = 746
          Height = 32
          Caption = 'Section quiz'
          AutoSize = False
          Font.Height = -23
          Font.Color = $00344853
          Font.Style = [fsBold]
          ParentFont = False
          Anchors = [akLeft, akTop, akRight]
      end
      object lblQuizStep: TLabel
          Left = 24
          Top = 56
          Width = 746
          Height = 21
          Caption = 'Question'
          AutoSize = False
          Font.Height = -14
          Font.Color = $00455860
          Font.Style = []
          ParentFont = False
          Anchors = [akLeft, akTop, akRight]
      end
      object prgQuiz: TProgressBar
          Left = 24
          Top = 82
          Width = 746
          Height = 8
          Max = 3
          Anchors = [akLeft, akTop, akRight]
          Smooth = True
      end
      object lblQuestion: TLabel
          Left = 24
          Top = 108
          Width = 746
          Height = 70
          Caption = 'Question'
          AutoSize = False
          Font.Height = -18
          Font.Color = $00273338
          Font.Style = [fsBold]
          ParentFont = False
          WordWrap = True
          Anchors = [akLeft, akTop, akRight]
      end
      object rgpAnswers: TRadioGroup
          Left = 24
          Top = 186
          Width = 746
          Height = 157
          Caption = ' Choose one answer '
          Anchors = [akLeft, akTop, akRight]
          OnClick = rgpAnswersClick
      end
      object memFeedback: TMemo
          Left = 24
          Top = 358
          Width = 746
          Height = 120
          ReadOnly = True
          ScrollBars = ssVertical
          Anchors = [akLeft, akTop, akRight, akBottom]
          Color = clWhite
          TabStop = False
      end
      object btnCheck: TButton
          Left = 24
          Top = 509
          Width = 175
          Height = 38
          Caption = '&Check answer'
          OnClick = btnCheckClick
          Anchors = [akLeft, akBottom]
          Enabled = False
      end
      object btnNext: TButton
          Left = 213
          Top = 509
          Width = 175
          Height = 38
          Caption = '&Next question'
          OnClick = btnNextClick
          Anchors = [akLeft, akBottom]
          Enabled = False
      end
      object btnRetry: TButton
          Left = 595
          Top = 509
          Width = 175
          Height = 38
          Caption = '&Restart quiz'
          OnClick = btnRetryClick
          Anchors = [akRight, akBottom]
      end
    end
    object tabPlan: TTabSheet
        Caption = 'Lesson planner'
      object lblPlanTitle: TLabel
          Left = 24
          Top = 18
          Width = 746
          Height = 36
          Caption = 'Build a lesson plan'
          AutoSize = False
          Font.Height = -25
          Font.Color = $00344853
          Font.Style = [fsBold]
          ParentFont = False
          Anchors = [akLeft, akTop, akRight]
      end
      object lblPlanSubject: TLabel
        Left = 24
        Top = 89
        Width = 126
        Height = 28
        Caption = 'CAT'
        AutoSize = False
        ParentFont = False
        Font.Height = -24
        Font.Color = $00344853
        Font.Style = [fsBold]
      end
      object lblGrade: TLabel
          Left = 167
          Top = 66
          Width = 108
          Height = 20
          Caption = '&Grade'
          AutoSize = False
          Font.Height = -14
          Font.Color = $00455860
          Font.Style = []
          ParentFont = False
          FocusControl = cmbGrade
      end
      object cmbGrade: TComboBox
          Left = 167
          Top = 89
          Width = 108
          Height = 29
          Style = csDropDownList
      end
      object lblAccess: TLabel
          Left = 292
          Top = 66
          Width = 270
          Height = 20
          Caption = 'Classroom &access'
          AutoSize = False
          Font.Height = -14
          Font.Color = $00455860
          Font.Style = []
          ParentFont = False
          FocusControl = cmbAccess
      end
      object cmbAccess: TComboBox
          Left = 292
          Top = 89
          Width = 270
          Height = 29
          Style = csDropDownList
      end
      object btnGenerate: TButton
          Left = 578
          Top = 84
          Width = 192
          Height = 37
          Caption = '&Use this activity'
          OnClick = btnGenerateClick
          Anchors = [akTop, akRight]
      end
      object memPlan: TMemo
          Left = 24
          Top = 141
          Width = 746
          Height = 344
          ReadOnly = False
          ScrollBars = ssVertical
          Anchors = [akLeft, akTop, akRight, akBottom]
          OnChange = memPlanChange
      end
      object btnExport: TButton
          Left = 24
          Top = 509
          Width = 178
          Height = 38
          Caption = '&Export lesson plan'
          OnClick = btnExportClick
          Anchors = [akLeft, akBottom]
          Enabled = False
      end
      object lblPlanStatus: TLabel
          Left = 221
          Top = 518
          Width = 550
          Height = 24
          Caption = 'Choose an activity to start.'
          AutoSize = False
          Font.Height = -14
          Font.Color = $00455860
          Font.Style = []
          ParentFont = False
          Anchors = [akLeft, akRight, akBottom]
      end
    end
    object tabCurriculum: TTabSheet
      Caption = 'CAPS and ATP'
      object lblCurriculum: TLabel
        Left = 24
        Top = 18
        Width = 740
        Height = 34
        Caption = 'Curriculum and teaching plans'
        AutoSize = False
        ParentFont = False
        Font.Height = -24
        Font.Color = $00344853
        Font.Style = [fsBold]
        Anchors = [akLeft, akTop, akRight]
      end
      object lblCurrGrade: TLabel
        Left = 24
        Top = 66
        Width = 100
        Height = 22
        Caption = '&Grade'
        AutoSize = False
        FocusControl = cmbCurrGrade
      end
      object cmbCurrGrade: TComboBox
        Left = 24
        Top = 90
        Width = 100
        Height = 28
        Style = csDropDownList
        OnChange = cmbCurrGradeChange
      end
      object lblCurrTerm: TLabel
        Left = 143
        Top = 66
        Width = 100
        Height = 22
        Caption = '&Term'
        AutoSize = False
        FocusControl = cmbCurrTerm
      end
      object cmbCurrTerm: TComboBox
        Left = 143
        Top = 90
        Width = 100
        Height = 28
        Style = csDropDownList
        OnChange = cmbCurrTermChange
      end
      object lblDocument: TLabel
        Left = 261
        Top = 66
        Width = 260
        Height = 22
        Caption = '&Document'
        AutoSize = False
        FocusControl = cmbDocument
      end
      object cmbDocument: TComboBox
        Left = 261
        Top = 90
        Width = 260
        Height = 28
        Style = csDropDownList
        OnChange = cmbDocumentChange
      end
      object memCurriculum: TMemo
        Left = 24
        Top = 133
        Width = 746
        Height = 263
        ReadOnly = True
        ScrollBars = ssVertical
        Anchors = [akLeft, akTop, akRight, akBottom]
      end
      object lblCurrCheck: TLabel
        Left = 24
        Top = 405
        Width = 745
        Height = 23
        Caption = 'Self-check'
        AutoSize = False
        Anchors = [akLeft, akRight, akBottom]
      end
      object cmbCurrCheck: TComboBox
        Left = 24
        Top = 431
        Width = 550
        Height = 28
        Style = csDropDownList
        Anchors = [akLeft, akRight, akBottom]
      end
      object btnCurrCheck: TButton
        Left = 587
        Top = 431
        Width = 183
        Height = 28
        Caption = 'Check &answer'
        OnClick = btnCurrCheckClick
        Anchors = [akRight, akBottom]
      end
      object lblCurrFeedback: TLabel
        Left = 24
        Top = 470
        Width = 746
        Height = 23
        Caption = ''
        AutoSize = False
        Anchors = [akLeft, akRight, akBottom]
      end
      object btnOfficial: TButton
        Left = 24
        Top = 513
        Width = 166
        Height = 34
        Caption = 'Open DBE &CAPS PDF'
        OnClick = btnOfficialClick
        Anchors = [akLeft, akBottom]
      end
      object btnSupportingDocument: TButton
        Left = 199
        Top = 513
        Width = 134
        Height = 34
        Caption = 'Open &local ATP'
        OnClick = btnSupportingDocumentClick
        Anchors = [akLeft, akBottom]
      end
      object btnCircular: TButton
        Left = 342
        Top = 513
        Width = 128
        Height = 34
        Caption = 'DBE ci&rculars'
        OnClick = btnCircularClick
        Anchors = [akLeft, akBottom]
      end
      object btnATPIndex: TButton
        Left = 479
        Top = 513
        Width = 131
        Height = 34
        Caption = 'DBE ATP inde&x'
        OnClick = btnATPIndexClick
        Anchors = [akLeft, akBottom]
      end
      object btnPAT: TButton
        Left = 619
        Top = 513
        Width = 151
        Height = 34
        Caption = 'Grade 12 &PATs'
        OnClick = btnPATClick
        Anchors = [akLeft, akBottom]
      end
    end
    object tabBot: TTabSheet
      Caption = 'Teacher FAQ'
      object lblBotTitle: TLabel
        Left = 24
        Top = 18
        Width = 740
        Height = 34
        Caption = 'Teacher FAQ'
        AutoSize = False
        ParentFont = False
        Font.Height = -24
        Font.Color = $00344853
        Font.Style = [fsBold]
        Anchors = [akLeft, akTop, akRight]
      end
      object lblBotPrompt: TLabel
        Left = 24
        Top = 65
        Width = 740
        Height = 23
        Caption = '&Suggested questions for South African teachers'
        AutoSize = False
        FocusControl = cmbBotPrompt
      end
      object cmbBotPrompt: TComboBox
        Left = 24
        Top = 91
        Width = 746
        Height = 28
        Style = csDropDownList
        Anchors = [akLeft, akTop, akRight]
        OnChange = cmbBotPromptChange
      end
      object lblBotQuestion: TLabel
        Left = 24
        Top = 136
        Width = 635
        Height = 24
        Caption = '&Your question'
        AutoSize = False
        FocusControl = edtBotQuestion
      end
      object edtBotQuestion: TEdit
        Left = 24
        Top = 163
        Width = 599
        Height = 30
        Anchors = [akLeft, akTop, akRight]
        MaxLength = 350
        OnKeyPress = edtBotQuestionKeyPress
      end
      object btnAsk: TButton
        Left = 634
        Top = 160
        Width = 136
        Height = 34
        Caption = '&Find answer'
        OnClick = btnAskClick
        Anchors = [akTop, akRight]
      end
      object memBot: TMemo
        Left = 24
        Top = 214
        Width = 746
        Height = 280
        ReadOnly = True
        ScrollBars = ssVertical
        Anchors = [akLeft, akTop, akRight, akBottom]
      end
      object btnClearBot: TButton
        Left = 24
        Top = 513
        Width = 166
        Height = 34
        Caption = '&Clear search'
        OnClick = btnClearBotClick
        Anchors = [akLeft, akBottom]
      end
    end
    object tabPaper: TTabSheet
      Caption = 'Academic paper'
      object lblPaperTitle: TLabel
        Left = 24
        Top = 22
        Width = 700
        Height = 34
        Caption = 'Academic paper and teaching references'
        Font.Height = -24
        Font.Color = $00344853
        Font.Style = [fsBold]
        ParentFont = False
      end
      object cmbPaper: TComboBox
        Left = 24
        Top = 69
        Width = 746
        Height = 29
        Style = csDropDownList
        Anchors = [akLeft, akTop, akRight]
        OnChange = cmbPaperChange
      end
      object redPaper: TRichEdit
        Left = 24
        Top = 110
        Width = 746
        Height = 371
        PlainText = True
        ReadOnly = True
        ScrollBars = ssVertical
        Anchors = [akLeft, akTop, akRight, akBottom]
      end
      object btnOpenPaper: TButton
        Left = 24
        Top = 509
        Width = 232
        Height = 38
        Caption = '&Open the full paper (.docx)'
        OnClick = btnOpenPaperClick
        Anchors = [akLeft, akBottom]
      end
    end
  end
  object dlgATP: TOpenDialog
    Title = 'Open the applicable ATP PDF'
    Filter = 'PDF files (*.pdf)|*.pdf'
    Options = [ofHideReadOnly, ofPathMustExist, ofFileMustExist, ofNoDereferenceLinks]
    Left = 224
    Top = 44
  end
end
