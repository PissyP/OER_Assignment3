inherited frmIT: TfrmIT
  Caption = 'Beyond the Computer Lab (IT)'
  inherited pnlHeader: TPanel
    inherited lblAudience: TLabel
      Caption = 'Information Technology for novice teachers'
    end
    inherited lblSubjectGrade: TLabel
      Caption = 'IT for Grades 10-12'
    end
  end
end
