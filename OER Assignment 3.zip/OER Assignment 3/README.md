# Beyond the Computer Lab
## Cape Lab Field Guide

A practical guide for Grade 10–12 CAT and IT teachers working in South African school computer labs.

### Open the project

1. Extract all files into one folder.
2. Open **BeyondTheComputerLab_P.dpr** in Delphi 13 on Windows with VCL installed. Press **F9**.
3. Play the **Dino game** using Space or Jump. Select **Continue to sign in** and use the separately supplied reviewer credentials.
4. Choose **CAT** or **IT**. Open a topic, review its CAPS focus and check grade and term placement using the relevant CAPS and ATP.
5. Use the worked example, paired task and individual exit check. The plan can be adapted and exported to a text file.
6. Use **Paper reference** to see the rationale and chapter section. Choose a chapter or the referencing list to read it inside the program. Select **Open the full paper (.docx)** for the original formatted assignment.

To share a built copy, keep **Delphi13.ico** and **CSIE_Assignment3_2026.docx** alongside the executable. The window and taskbar icon loads from the ICO file at startup. The guide pages, quizzes, planner, paper references and FAQ are contained in the program, along with a plain-text reading copy of the paper. Online topic links and DBE documents open in the default browser or reader.

### Teacher workflow

- Adapt the sequence to the grade and skills already taught. Check spreadsheet work in the CAT application. Use Delphi or a paper trace for IT programming tasks.
- Model the worked example, let pairs swap driver and navigator roles, then collect an individual result and explanation.
- For the independent follow-up, ask learners to choose one skill, predict a result, test it and record what they will try next.
- The eight external resources provide further reading and, where supplied by the publisher, screenshots. Use the offline route when the class has limited internet or shared computers.
- The Academic paper tab indexes the supplied three-chapter academic assignment and its referencing list. It links each course activity to its basis in the paper and keeps the classroom directions quick to consult.

### Delphi naming

Variables use type prefixes such as `i` (Integer), `s` (String), `b` (Boolean), `c` (Char), `arr` (array) and `rec` (record). The same prefixes apply to private variables. Form components use names such as `frmLogin`, `btnSignIn`, `edtUsername`, `lblDinoStatus`, `pbxDino`, `tmrDino` and `redPaper`.

### Files and reuse

- The Delphi 13 icon uses the product mark from [Embarcadero’s Delphi 13 release announcement](https://blogs.embarcadero.com/delphi-13-community-edition-is-now-available/). The mark belongs to its owner.

- Delphi Object Pascal source and editable VCL form files implement the application and its design. `Activities_U.pas` holds both subjects’ activities and question banks. `Curriculum_U.pas` holds curriculum links and the teacher FAQ.
- Group academic source: *CSIE Assignment 3 (2026)*, Chapters 1–3, supplied by Percy Pitseng. The classroom notes adapt the group’s teaching, assessment, collaboration and emerging technologies chapters.
- The existing Apache 2.0 notice covers the supplied program code and original additions. Confirm co-author permission and final open-content licensing before publicly distributing the academic paper or adapted group material. Linked sources retain their publishers’ rights.

### Windows release check

1. Build the Win32 Debug target in Delphi 13. Run it and check the Delphi 13 icon on the main window and taskbar.
2. Play a round using Space, continue to sign in, check invalid credentials, then sign in and open both subjects.
3. Search and clear a search in each workspace. Open a topic, take a quiz and load the topic’s paper reference.
4. Generate and export a plan. Edit it and leave the workspace to check the export, discard and cancel options.
5. Check a CAPS PDF, a technology link and the formatted academic paper with the intended Windows document handlers.
