object frmLogin: TfrmLogin
  BorderStyle = bsSingle
  BorderIcons = [biSystemMenu, biMinimize]
  Caption = 'Beyond the Computer Lab'
  ClientWidth = 690
  ClientHeight = 505
  Color = $00E5EDF5
  Font.Name = 'Segoe UI'
  Font.Height = -16
  Position = poScreenCenter
  Scaled = True
  PixelsPerInch = 96
  KeyPreview = True
  OnKeyDown = FormKeyDown
  OnShow = FormShow
  object pnlBanner: TPanel
    Align = alTop
    Height = 115
    ParentBackground = False
    Color = $00273338
    BevelOuter = bvNone
    object lblBrand: TLabel
      Left = 28
      Top = 25
      Width = 550
      Height = 46
      Caption = 'Beyond the Computer Lab'
      AutoSize = False
      ParentFont = False
      Font.Color = clWhite
      Font.Height = -32
      Font.Style = [fsBold]
    end
    object imgDelphi13: TImage
      Left = 594
      Top = 23
      Width = 68
      Height = 68
      Center = True
      Proportional = True
      Stretch = True
    end
    object lblSubtitle: TLabel
      Left = 30
      Top = 76
      Width = 550
      Height = 25
      Caption = 'Cape Lab Field Guide for Grades 10-12'
      AutoSize = False
      ParentFont = False
      Font.Color = $007BCADF
    end
  end
  object pnlSignIn: TPanel
    Left = 27
    Top = 135
    Width = 636
    Height = 343
    BevelOuter = bvNone
    ParentBackground = False
    Color = clWhite
    Visible = False
    object lblSignIn: TLabel
      Left = 22
      Top = 13
      Width = 590
      Height = 36
      Caption = 'Teacher sign-in'
      AutoSize = False
      ParentFont = False
      Font.Height = -24
      Font.Color = $00344853
      Font.Style = [fsBold]
    end
    object lblUsername: TLabel
      Left = 22
      Top = 58
      Width = 500
      Height = 21
      Caption = '&Username'
      AutoSize = False
      FocusControl = edtUsername
    end
    object edtUsername: TEdit
      Left = 22
      Top = 81
      Width = 380
      Height = 28
      MaxLength = 80
    end
    object lblPassword: TLabel
      Left = 22
      Top = 119
      Width = 500
      Height = 21
      Caption = '&Password'
      AutoSize = False
      FocusControl = edtPassword
    end
    object edtPassword: TEdit
      Left = 22
      Top = 142
      Width = 380
      Height = 28
      MaxLength = 80
      PasswordChar = '*'
    end
    object chkShow: TCheckBox
      Left = 22
      Top = 181
      Width = 380
      Height = 24
      Caption = 'Show password'
      OnClick = chkShowClick
    end
    object btnSignIn: TButton
      Left = 22
      Top = 216
      Width = 168
      Height = 38
      Caption = '&Sign in'
      OnClick = btnSignInClick
      Default = True
    end
    object lblLoginStatus: TLabel
      Left = 22
      Top = 266
      Width = 590
      Height = 24
      Caption = ''
      AutoSize = False
      ParentFont = False
      Font.Color = $003333A0
    end
  end
  object pnlSubjects: TPanel
    Left = 27
    Top = 135
    Width = 636
    Height = 343
    BevelOuter = bvNone
    ParentBackground = False
    Color = clWhite
    Visible = False
    object lblChoose: TLabel
      Left = 22
      Top = 25
      Width = 590
      Height = 36
      Caption = 'Choose your teaching subject'
      AutoSize = False
      ParentFont = False
      Font.Height = -24
      Font.Color = $00344853
      Font.Style = [fsBold]
    end
    object lblChooseHelp: TLabel
      Left = 22
      Top = 78
      Width = 590
      Height = 26
      Caption = 'Open a subject for classroom activities, CAPS and lesson plans.'
      AutoSize = False
    end
    object btnCAT: TButton
      Left = 22
      Top = 130
      Width = 590
      Height = 55
      Caption = '&CAT (Computer Applications Technology)'
      OnClick = btnCATClick
    end
    object btnIT: TButton
      Left = 22
      Top = 200
      Width = 590
      Height = 55
      Caption = '&IT (Information Technology)'
      OnClick = btnITClick
    end
    object btnSignOut: TButton
      Left = 22
      Top = 284
      Width = 172
      Height = 34
      Caption = 'Sign &out'
      OnClick = btnSignOutClick
    end
  end
  object pnlDino: TPanel
    Left = 27
    Top = 135
    Width = 636
    Height = 343
    BevelOuter = bvNone
    ParentBackground = False
    Color = clWhite
    object lblDinoTitle: TLabel
      Left = 22
      Top = 18
      Width = 590
      Height = 32
      Caption = 'Dino game'
      Font.Height = -24
      Font.Color = $00344853
      Font.Style = [fsBold]
      ParentFont = False
    end
    object lblDinoStatus: TLabel
      Left = 22
      Top = 58
      Width = 590
      Height = 26
      AutoSize = False
      Caption = 'Press Space or select Jump to start.'
    end
    object pbxDino: TPaintBox
      Left = 22
      Top = 94
      Width = 592
      Height = 153
      OnPaint = pbxDinoPaint
      OnClick = btnJumpClick
    end
    object btnJump: TButton
      Left = 22
      Top = 270
      Width = 142
      Height = 38
      Caption = '&Jump'
      OnClick = btnJumpClick
    end
    object btnContinue: TButton
      Left = 181
      Top = 270
      Width = 192
      Height = 38
      Caption = '&Continue to sign in'
      Hint = 'Continue when you are ready'
      ShowHint = True
      OnClick = btnContinueClick
    end
  end
  object tmrDino: TTimer
    Enabled = False
    Interval = 25
    OnTimer = tmrDinoTimer
    Left = 634
    Top = 32
  end
end
