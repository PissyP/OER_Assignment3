unit Login_U;

interface

uses
  Winapi.Windows, System.Classes, System.SysUtils, System.Types, Vcl.Forms, Vcl.StdCtrls,
  Vcl.ExtCtrls, Vcl.Controls, Vcl.Graphics, Vcl.Dialogs, CAT_U, IT_U, Curriculum_U;

type
  TfrmLogin = class(TForm)
    pnlBanner, pnlSignIn, pnlSubjects, pnlDino: TPanel;
    lblBrand, lblSubtitle, lblSignIn, lblUsername, lblPassword,
      lblLoginStatus, lblChoose, lblChooseHelp, lblDinoTitle,
      lblDinoStatus: TLabel;
    edtUsername, edtPassword: TEdit;
    chkShow: TCheckBox;
    btnSignIn, btnCAT, btnIT, btnSignOut, btnJump, btnContinue: TButton;
    pbxDino: TPaintBox;
    imgDelphi13: TImage;
    tmrDino: TTimer;
    procedure FormShow(Sender: TObject);
    procedure tmrDinoTimer(Sender: TObject);
    procedure FormKeyDown(Sender: TObject; var iKey: Word; setShift: TShiftState);
    procedure pbxDinoPaint(Sender: TObject);
    procedure btnJumpClick(Sender: TObject);
    procedure btnContinueClick(Sender: TObject);
    procedure chkShowClick(Sender: TObject);
    procedure btnSignInClick(Sender: TObject);
    procedure btnCATClick(Sender: TObject);
    procedure btnITClick(Sender: TObject);
    procedure btnSignOutClick(Sender: TObject);
  private
    iJumpHeight, iJumpSpeed, iObstacleX, iDinoScore: Integer;
    bSignedIn: Boolean;
    procedure ResetDino;
    procedure OpenSubject(iSubject: Integer);
  end;

var
  frmLogin: TfrmLogin;

implementation

{$R *.dfm}

const
  iGround = 125;
  iDinoLeft = 66;
  iDinoWidth = 42;
  iObstacleWidth = 22;
  iObstacleHeight = 29;
  sDemoUsername = 'teacher';
  sDemoPassword = 'BeyondLab2026';

procedure TfrmLogin.FormShow(Sender: TObject);
begin
  if pnlDino.Visible then
  begin
    if not Application.Icon.Empty then
      imgDelphi13.Picture.Icon.Assign(Application.Icon);
    ResetDino;
    btnJump.SetFocus;
  end;
end;

procedure TfrmLogin.ResetDino;
begin
  iJumpHeight := 0;
  iJumpSpeed := 0;
  iObstacleX := 570;
  iDinoScore := 0;
  pbxDino.Invalidate;
end;

procedure TfrmLogin.FormKeyDown(Sender: TObject; var iKey: Word;
  setShift: TShiftState);
begin
  if pnlDino.Visible and (iKey = VK_SPACE) and not btnContinue.Focused then
  begin
    iKey := 0;
    btnJumpClick(Sender);
  end;
end;

procedure TfrmLogin.btnJumpClick(Sender: TObject);
begin
  if not tmrDino.Enabled then
  begin
    ResetDino;
    tmrDino.Enabled := True;
  end;
  if iJumpHeight = 0 then
  begin
    iJumpSpeed := 15;
    iJumpHeight := 1;
  end;
  lblDinoStatus.Caption := 'Score ' + IntToStr(iDinoScore);
end;

procedure TfrmLogin.tmrDinoTimer(Sender: TObject);
begin
  if iJumpHeight > 0 then
  begin
    iJumpHeight := iJumpHeight + iJumpSpeed;
    Dec(iJumpSpeed, 2);
    if iJumpHeight < 0 then
      iJumpHeight := 0;
  end;

  Dec(iObstacleX, 9);
  if (iObstacleX < iDinoLeft + iDinoWidth) and
    (iObstacleX + iObstacleWidth > iDinoLeft) and
    (iJumpHeight < iObstacleHeight) then
  begin
    tmrDino.Enabled := False;
    lblDinoStatus.Caption := 'Score ' + IntToStr(iDinoScore) +
      '. Press Space or select Jump to retry.';
  end
  else if iObstacleX + iObstacleWidth < 0 then
  begin
    Inc(iDinoScore);
    iObstacleX := 520 + Random(95);
    lblDinoStatus.Caption := 'Score ' + IntToStr(iDinoScore);
  end;
  pbxDino.Invalidate;
end;

procedure TfrmLogin.pbxDinoPaint(Sender: TObject);
var
  iY: Integer;

  procedure Block(iLeft, iTop, iRight, iBottom: Integer; clFill: TColor);
  begin
    pbxDino.Canvas.Brush.Color := clFill;
    pbxDino.Canvas.FillRect(Rect(MulDiv(iLeft, pbxDino.Width, 592),
      MulDiv(iTop, pbxDino.Height, 153), MulDiv(iRight, pbxDino.Width, 592),
      MulDiv(iBottom, pbxDino.Height, 153)));
  end;

begin
  Block(0, 0, 592, 153, $00E5EDF5);
  Block(0, iGround, 592, iGround + 3, $00344853);
  iY := iGround - iJumpHeight;
  Block(iDinoLeft, iY - 21, iDinoLeft + 30, iY - 8, $00344853);
  Block(iDinoLeft + 21, iY - 34, iDinoLeft + iDinoWidth, iY - 16, $00344853);
  Block(iDinoLeft + 33, iY - 30, iDinoLeft + 37, iY - 26, clWhite);
  Block(iDinoLeft + 8, iY - 10, iDinoLeft + 13, iY, $00344853);
  Block(iDinoLeft + 23, iY - 10, iDinoLeft + 29, iY, $00344853);
  Block(iObstacleX, iGround - iObstacleHeight,
    iObstacleX + iObstacleWidth, iGround, $005389AF);
  Block(iObstacleX + 5, iGround - 21, iObstacleX + 16,
    iGround - 16, $007BCADF);
end;

procedure TfrmLogin.btnContinueClick(Sender: TObject);
begin
  tmrDino.Enabled := False;
  pnlDino.Hide;
  pnlSignIn.Show;
  edtUsername.SetFocus;
end;

procedure TfrmLogin.chkShowClick(Sender: TObject);
begin
  // Let teachers check a typed demo password, then mask it again.
  if chkShow.Checked then
    edtPassword.PasswordChar := #0
  else
    edtPassword.PasswordChar := '*';
end;

procedure TfrmLogin.btnSignInClick(Sender: TObject);
begin
  // The local reviewer login does not create or store personal accounts.
  if Trim(edtUsername.Text) = '' then
  begin
    lblLoginStatus.Caption := 'Enter your username.';
    edtUsername.SetFocus;
    Exit;
  end;
  if edtPassword.Text = '' then
  begin
    lblLoginStatus.Caption := 'Enter your password.';
    edtPassword.SetFocus;
    Exit;
  end;
  if not SameText(Trim(edtUsername.Text), sDemoUsername) or
    (edtPassword.Text <> sDemoPassword) then
  begin
    lblLoginStatus.Caption := 'Check the username and password and try again.';
    edtPassword.SelectAll;
    edtPassword.SetFocus;
    Exit;
  end;
  bSignedIn := True;
  edtPassword.Clear;
  chkShow.Checked := False;
  chkShowClick(nil);
  lblLoginStatus.Caption := '';
  pnlSignIn.Hide;
  pnlSubjects.Show;
  btnCAT.SetFocus;
end;

procedure TfrmLogin.OpenSubject(iSubject: Integer);
var
  frmSubject: TfrmCAT;
begin
  // Create only the workspace requested by a signed-in teacher.
  if not bSignedIn then
    Exit;
  try
    if iSubject = iCAT then
      frmSubject := TfrmCAT.Create(Self)
    else
      frmSubject := TfrmIT.Create(Self);
    try
      frmSubject.Initialize(iSubject);
      frmSubject.ShowModal;
    finally
      frmSubject.Free;
    end;
  except
    on E: Exception do
      MessageDlg('The subject workspace could not open.' + sLineBreak +
        E.Message, mtError, [mbOK], 0);
  end;
end;

procedure TfrmLogin.btnCATClick(Sender: TObject);
begin
  // Open the CAT workspace with CAT resources and knowledge checks.
  OpenSubject(iCAT);
end;

procedure TfrmLogin.btnITClick(Sender: TObject);
begin
  // Open the distinct IT form with the IT resource bank.
  OpenSubject(iIT);
end;

procedure TfrmLogin.btnSignOutClick(Sender: TObject);
begin
  // Clear credentials and return to the sign-in panel.
  bSignedIn := False;
  edtUsername.Clear;
  edtPassword.Clear;
  chkShow.Checked := False;
  chkShowClick(nil);
  lblLoginStatus.Caption := '';
  pnlSubjects.Hide;
  pnlSignIn.Show;
  edtUsername.SetFocus;
end;

end.
