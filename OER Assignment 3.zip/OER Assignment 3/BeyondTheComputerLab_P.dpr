program BeyondTheComputerLab_P;

uses
  System.SysUtils,
  Vcl.Forms,
  Login_U in 'Login_U.pas' {frmLogin},
  CAT_U in 'CAT_U.pas' {frmCAT},
  IT_U in 'IT_U.pas' {frmIT},
  Curriculum_U in 'Curriculum_U.pas',
  Activities_U in 'Activities_U.pas',
  Paper_U in 'Paper_U.pas';

procedure LoadDelphiIcon;
var
  sFolder, sIconPath: string;
begin
  sFolder := ExtractFilePath(ParamStr(0));
  sIconPath := sFolder + 'Delphi13.ico';
  if not FileExists(sIconPath) then
    sIconPath := sFolder + '..\Delphi13.ico';
  if not FileExists(sIconPath) then
    sIconPath := sFolder + '..\..\Delphi13.ico';
  if FileExists(sIconPath) then
  begin
    try
      Application.Icon.LoadFromFile(sIconPath);
    except
      on Exception do
        Application.Icon.Handle := 0;
    end;
  end;
end;

begin
  Randomize;
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.Title := 'Beyond the Computer Lab';
  LoadDelphiIcon;
  Application.CreateForm(TfrmLogin, frmLogin);
  Application.Run;
end.
