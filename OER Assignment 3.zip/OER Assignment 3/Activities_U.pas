﻿unit Activities_U;

interface

type
  TQuestion = record
    sPrompt: string;
    arrChoices: array[0..2] of string;
    iCorrect: Integer;
    sFeedback: string;
  end;
  TQuestionBank = array[0..2] of TQuestion;
  TActivity = record
    sName, sCategory, sPurpose, sLimits, sGuidance: string;
    arrTask, arrImplementation, arrEvidence, arrOffline, arrCAPS, arrExample: array[1..2] of string;
    sResourceName, sResourceURL, sPaperSection, sRationale: string;
    arrQuiz: array[1..2] of TQuestionBank;
  end;

const
  iActivityCount = 8;
  iQuestionCount = 3;
  sTeachingCategory = 'Teaching and assessment';
  sEmergingCategory = 'Emerging technologies';
  arrActivities: array[1..iActivityCount] of TActivity = (
    (sName: 'Microsoft Teams';
     sCategory: 'Teaching and assessment';
     sPurpose: 'Organise lesson resources, discussions, feedback and collaborative work in one class space.';
     sLimits: 'Requires suitable school accounts, devices and connectivity. Too many channels can make work difficult to find.';
     sGuidance: 'Set up a small number of clearly named channels and agree on class communication rules. Use a school-managed class space.';
     arrTask: ('Give pairs a sales workbook. They calculate totals, averages and counts, then submit a screenshot and explain their choices.',
       'Post a Delphi starter project and a testing brief in a dedicated Teams channel. Partners alternate between implementing an event handler and checking expected outputs. Each learner submits a test result and explains one fix.');
     arrImplementation: ('Prepare - Prepare a Teams assignment with a fictional tuck-shop sales workbook. Add columns for item, quantity and unit price, plus a copy for each pair.' + #13#10 +
        'In class - Project one row and model B2*C2. In pairs, learners fill the formula down, then calculate the total and average sale. Swap the keyboard after the first check.' + #13#10 +
        'Collect - Collect the workbook through Teams. Return feedback on one incorrect formula and ask each learner to show what changes when a quantity is edited.',
       'Prepare - Post a Delphi VCL starter project and a brief for classifying interhouse entries by age. Supply an age Edit, a button and an output label.' + #13#10 +
        'In class - Have one learner write the button event using an Integer and IF THEN ELSE. The partner records expected results for 15, 16 and 17. Swap roles before running the tests.' + #13#10 +
        'Collect - Collect the source and test table. Each learner explains the boundary at 16 and demonstrates one test independently.');
     arrEvidence: ('Check the submitted work and ask each learner to explain one decision independently. For spreadsheets, ask how a formula differs from a function.',
       'Review the named test inputs, expected results and observed results. Ask each learner to explain one debugging decision.');
     arrOffline: ('Distribute the workbook or starter code through the lab network or on paper. Collect the result locally and use a written exit slip.',
       'Distribute the same starter project through the lab folder. Partners share the keyboard in turns and submit an individual recorded test case.');
     arrCAPS: ('Solution Development: spreadsheet functions and checking results',
       'Solution Development: selection, testing and debugging');
     arrExample: ('Enter 120, 80, 100 and 60 in B2:B5. Check SUM = 360 and AVERAGE = 90. Change one value and predict the result first.',
       'Athletics signup rule: if iAge >= 16 then sGroup := Senior else sGroup := Junior; Test ages 15, 16 and 17.');
     sResourceName: 'Microsoft Learn: Teams assignments';
     sResourceURL: 'https://learn.microsoft.com/en-us/microsoftteams/expand-teams-across-your-org/assignments-in-teams';
     sPaperSection: 'Chapter 2 / Microsoft Teams / Teaching, learning and assessment strategies';
     sRationale: 'A shared channel supports peer feedback when learners discuss a decision. Keep an individual exit slip so a joint submission does not hide gaps. Transfer skill: collaboration and giving usable feedback.';
     arrQuiz: (((sPrompt: 'Where should a novice teacher post the sales workbook and task instructions?';
          arrChoices: ('In unrelated private chats',
       'In a clearly named class channel',
       'In several channels with different instructions'); iCorrect: 1;
          sFeedback: 'A topic channel keeps the workbook, instructions and class questions together.'),
         (sPrompt: 'What gives you individual evidence after the paired spreadsheet task?';
          arrChoices: ('The number of messages sent',
       'A screenshot with both names on it',
       'An exit slip explaining a formula or function'); iCorrect: 2;
          sFeedback: 'An individual explanation shows what each learner understood.'),
         (sPrompt: 'Which fallback preserves the spreadsheet objective during an internet outage?';
          arrChoices: ('Discuss chat etiquette instead',
       'Distribute the same workbook locally and collect the work in the lab',
       'Cancel all practical work'); iCorrect: 1;
          sFeedback: 'A local workbook preserves the same practical task and lets you assess the result.')),
        ((sPrompt: 'Where should you place the starter project and its testing brief?';
          arrChoices: ('Separate private chats',
       'Three channels with conflicting directions',
       'A clearly named class channel'); iCorrect: 2;
          sFeedback: 'One channel keeps files, task requirements and class questions together.'),
         (sPrompt: 'Which evidence checks individual debugging understanding?';
          arrChoices: ('Accept a shared screenshot as the only evidence',
       'Ask each learner to explain a failed test and the fix',
       'Count the group''s posts'); iCorrect: 1;
          sFeedback: 'An individual explanation reveals the reasoning behind the correction.'),
         (sPrompt: 'Which fallback still assesses the same coding outcome?';
          arrChoices: ('Cancel practical work',
       'Distribute the project locally and collect the same tests',
       'Replace coding with a platform navigation lesson'); iCorrect: 1;
          sFeedback: 'The local handover preserves the practical task and checks.')))),
    (sName: 'Google Classroom';
     sCategory: 'Teaching and assessment';
     sPurpose: 'Distribute structured coursework and return rubric-based feedback.';
     sLimits: 'Depends on suitable accounts and connectivity. Practical support during the lesson still matters.';
     sGuidance: 'Use staged deadlines where access differs and give learners a chance to act on feedback.';
     arrTask: ('Post an assignment with a dataset and a rubric. Learners submit their practical work and explain two choices they made.',
       'Post a small Delphi task, starter files and a rubric in Google Classroom. Learners submit source code and a test log. Return feedback on a failing boundary case and let them resubmit.');
     arrImplementation: ('Prepare - Create a Classroom assignment with a workbook containing numbers, blanks, zero and text. Add a rubric for function choice, accuracy and explanation.' + #13#10 +
        'In class - Ask learners to use COUNT, COUNTA and COUNTBLANK for separate questions. They submit the workbook with a short note explaining why a zero belongs in COUNT.' + #13#10 +
        'Collect - Return one piece of feedback privately. Learners revise the workbook and explain the correction on resubmission.',
       'Prepare - Attach a Delphi ticket-cost starter project and a rubric for input, processing, output and tests. Set a fixed ticket price of R25.' + #13#10 +
        'In class - Have learners read the number of tickets, multiply by the price and display the result. Require a test table for 0, 1 and 4 tickets.' + #13#10 +
        'Collect - Return feedback against one rubric row. Learners resubmit the edited event handler and show that the failing test now passes.');
     arrEvidence: ('Check accuracy, quality of the submitted work, and the reasoning behind two choices. Return one specific improvement.',
       'Use the rubric to check the source and test log. Ask each learner to repeat a boundary test and explain what it checks.');
     arrOffline: ('Provide a local copy of the files and a printed rubric. Collect work in the lab and return feedback on the rubric.',
       'Use a lab submission folder and a printed rubric. Learners save sources and a test log with expected and observed outputs.');
     arrCAPS: ('Solution Development: functions and data checking',
       'Solution Development: input, processing, output and testing');
     arrExample: ('Put 120, blank, 0 and Pending in B2:B5. Explain why COUNT = 2 and COUNTA = 3.',
       'Use iTotal := iEntries * iFee; test 0 and 4 entries at R25 each. Record expected outputs (R0 and R100) before running.');
     sResourceName: 'Google Classroom Help: create an assignment';
     sResourceURL: 'https://support.google.com/edu/classroom/answer/6020265?hl=en-GB';
     sPaperSection: 'Chapter 2 / Google Classroom / Self-Directed Learning opportunities';
     sRationale: 'A clear brief and rubric give learners a way to plan, monitor and improve work. Ask for a revision based on feedback. Transfer skill: managing work and checking quality.';
     arrQuiz: (((sPrompt: 'What should accompany a spreadsheet assignment in Google Classroom?';
          arrChoices: ('A public upload link for anyone',
       'A rubric and clear submission instructions',
       'A list of learners ranked by speed'); iCorrect: 1;
          sFeedback: 'A rubric tells learners what accuracy, presentation and explanation look like.'),
         (sPrompt: 'Which spreadsheet function adds the sales values?';
          arrChoices: ('SUM',
       'AVERAGE',
       'COUNT'); iCorrect: 0;
          sFeedback: 'SUM adds numeric values. COUNT counts numeric entries, and AVERAGE finds the mean.'),
         (sPrompt: 'Which feedback is most actionable after reviewing the work?';
          arrChoices: ('Extend the SUM range to include the final sales row',
       'You are number seven',
       'Try harder next time'); iCorrect: 0;
          sFeedback: 'Specific feedback tells the learner what to change and where to change it.')),
        ((sPrompt: 'What should learners submit for a Delphi assignment?';
          arrChoices: ('Only their final mark',
       'A screenshot of an empty form',
       'Source code and a test log'); iCorrect: 2;
          sFeedback: 'Source and test evidence show how the solution handles the task.'),
         (sPrompt: 'Which rubric criteria best match the task?';
          arrChoices: ('Number of colours in the GUI',
       'Correctness, test coverage and explanation',
       'Upload speed only'); iCorrect: 1;
          sFeedback: 'The criteria check the solution, its behaviour and the learner''s reasoning.'),
         (sPrompt: 'Which feedback is most actionable?';
          arrChoices: ('Try harder',
       'Add more code without checking it',
       'Test the lowest valid value and record the expected result'); iCorrect: 2;
          sFeedback: 'A specific boundary test gives the learner a clear revision task.')))),
    (sName: 'Kahoot!';
     sCategory: 'Teaching and assessment';
     sPurpose: 'Check prior knowledge or diagnose misconceptions in a short live quiz.';
     sLimits: 'Timed responses and rankings can disadvantage some learners. A quiz offers limited evidence of practical competence.';
     sGuidance: 'Allow adequate response time and use response patterns to guide teaching. Follow up with practical work.';
     arrTask: ('Run a short revision quiz. Pause after each item to have learners justify the answer. Reteach the item with the most errors using a worked example.',
       'Use Kahoot! to predict output from short Delphi selection and loop snippets. Pause after each item for a trace. Follow up with a live change to a boundary condition.');
     arrImplementation: ('Prepare - Set up a short Kahoot quiz using a single sample range with blanks, text and zeroes. Give learners thinking time before revealing each answer.' + #13#10 +
        'In class - Ask learners to predict the result of COUNT, COUNTA or COUNTBLANK, then verify each result in the spreadsheet. Pause if learners confuse a zero with a blank.' + #13#10 +
        'Collect - End with a different range. Each learner chooses a function and writes a one-sentence justification independently.',
       'Prepare - Prepare three short Delphi snippets using IF statements and FOR loops. Show each snippet alongside the Kahoot answer choices.' + #13#10 +
        'In class - Give learners time to trace variable values on paper before voting. Discuss the most common wrong answer, then run the snippet in Delphi.' + #13#10 +
        'Collect - Change the loop upper limit or comparison operator. Ask each learner to predict and then verify the new output.');
     arrEvidence: ('Record which items are commonly missed, then ask learners to apply the concept in a new example.',
       'Check the individual trace table and the result after learners change the boundary condition.');
     arrOffline: ('Project or read the questions and use letter cards. Give everyone thinking time before revealing the answers.',
       'Project a snippet or distribute a paper copy. Learners predict the output with response cards and complete a trace table individually.');
     arrCAPS: ('Solution Development: spreadsheet functions',
       'Solution Development: trace selection and repetition');
     arrExample: ('For 8, blank, OK and 0, ask learners to predict COUNTBLANK, then test the result (1) in a workbook.',
       'Set iTotal := 0; then for iCount := 1 to 3 do iTotal := iTotal + iCount; Trace 1, 3, 6 on paper.');
     sResourceName: 'Kahoot Help: build a quiz';
     sResourceURL: 'https://support.kahoot.com/hc/en-us/articles/115002884788-How-to-make-a-kahoot';
     sPaperSection: 'Chapter 2 / Kahoot! / Teaching, learning and assessment strategies';
     sRationale: 'Formative assessment works when the response changes the next teaching step. Pause after a common error and ask learners to defend a correction. Transfer skill: explaining a choice under unfamiliar conditions.';
     arrQuiz: (((sPrompt: 'What is the best use of a short Kahoot! quiz in this lesson?';
          arrChoices: ('Replace the workbook activity',
       'Award a final practical mark based on speed',
       'Diagnose misconceptions before a practical follow-up'); iCorrect: 2;
          sFeedback: 'A short quiz helps identify what to reteach. Practical work gives evidence of application.'),
         (sPrompt: 'Several learners confuse COUNT and COUNTA. What should you do next?';
          arrChoices: ('Compare the two functions on a worked dataset',
       'Skip both functions',
       'Repeat the question with a shorter timer'); iCorrect: 0;
          sFeedback: 'A worked dataset lets learners see that COUNT counts numbers and COUNTA counts non-empty cells.'),
         (sPrompt: 'Which adaptation gives learners time to explain their choice?';
          arrChoices: ('Pause after each question and discuss the reason',
       'Remove thinking time',
       'Use a leaderboard as the mark'); iCorrect: 0;
          sFeedback: 'A reasoning pause lets learners articulate a misconception and hear why the answer fits.')),
        ((sPrompt: 'Why ask learners to predict the output before showing the trace?';
          arrChoices: ('It gives a formal practical mark',
       'It reveals assumptions about how the code runs',
       'It measures typing speed'); iCorrect: 1;
          sFeedback: 'Prediction makes execution misconceptions visible for discussion.'),
         (sPrompt: 'Many learners miss a loop boundary. Which follow-up is useful?';
          arrChoices: ('Skip the question',
       'Shorten the timer',
       'Trace the first and last iterations together'); iCorrect: 2;
          sFeedback: 'Tracing the boundary shows which values the loop visits and why.'),
         (sPrompt: 'What should follow the live quiz?';
          arrChoices: ('A practical Delphi edit and test',
       'A leaderboard as the only evidence',
       'A second leaderboard'); iCorrect: 0;
          sFeedback: 'Practical work verifies that learners can apply the idea in code.')))),
    (sName: 'Padlet';
     sCategory: 'Teaching and assessment';
     sPurpose: 'Structure brainstorming, evidence sharing and peer feedback in a shared board.';
     sLimits: 'Plan for moderation, participant access and limits that may apply to school accounts.';
     sGuidance: 'Use fictional examples, moderate posts and explain what constructive peer feedback should include.';
     arrTask: ('Set up a board with clear prompts. Each group posts one justified recommendation or solution and responds constructively to another group.',
       'Ask groups to post pseudocode for one search problem and to comment on clarity and missing test cases. Each learner submits an individual revision.');
     arrImplementation: ('Prepare - Set up a restricted Padlet board with columns for Publish, Remove and Explain. Post a fictional sports result containing a name, phone number and time.' + #13#10 +
        'In class - Have pairs post a safer version and explain which details the audience needs. Each pair responds to another post with a specific improvement.' + #13#10 +
        'Collect - Collect an individual rewritten post and a sentence explaining what was removed. Use fictional records throughout.',
       'Prepare - Create a restricted Padlet board with columns for Algorithm, Test and Revision. Post a short Delphi ticket-cost problem.' + #13#10 +
        'In class - Pairs share their algorithm and expected results for 0 and 4 tickets. Another pair suggests a boundary case and explains what it checks.' + #13#10 +
        'Collect - Learners amend the Delphi event handler locally. Each learner submits the changed statement and an expected-versus-actual result.');
     arrEvidence: ('Assess the reason behind the group post and collect an individual exit reflection about what the learner would change or do next.',
       'Compare the first pseudocode with an individual revision and ask why the learner added or changed a test.');
     arrOffline: ('Use chart paper or a shared local document with the same headings. Rotate groups to read and annotate responses.',
       'Use chart paper or a local shared document for pseudocode and peer comments. Collect each learner''s revised trace or test individually.');
     arrCAPS: ('Social Implications: privacy and responsible use',
       'Solution Development: algorithm design and testing');
     arrExample: ('Give pairs a fictional interhouse results post containing a full name, a phone number and a time. Ask what belongs in a public result and who can see the original data.',
       'Write a ticket-cost algorithm. Use if iTickets > 0 then iTotal := iTickets * 25; initialise iTotal to zero first. Ask peers to test 0, 1 and 4 tickets.');
     sResourceName: 'Padlet Help: get started';
     sResourceURL: 'https://padlet.help/l/en/article/9j9aadt8tn-kuidas-alustada-padletiga';
     sPaperSection: 'Chapter 2 / Padlet / Teaching, learning and assessment strategies';
     sRationale: 'Social constructivism is reflected in peer dialogue. Require each pair to respond to a specific idea, then revise its own work independently. Transfer skill: collaborative problem-solving.';
     arrQuiz: (((sPrompt: 'Which prompt best suits a collaborative Padlet board?';
          arrChoices: ('Post a real learner''s private messages',
       'Post a mark with no explanation',
       'Post a fictional privacy recommendation and explain it'); iCorrect: 2;
          sFeedback: 'A fictional scenario supports discussion without exposing someone''s information.'),
         (sPrompt: 'What makes a peer comment useful?';
          arrChoices: ('A reasoned suggestion linked to the task',
       'An emoji on every post',
       'A copy of the original post'); iCorrect: 0;
          sFeedback: 'A specific suggestion gives the group something to review or improve.'),
         (sPrompt: 'How can you assess individual understanding after group work?';
          arrChoices: ('Grade all members solely on the group post',
       'Count board views',
       'Collect a short individual exit reflection'); iCorrect: 2;
          sFeedback: 'An exit reflection captures each learner''s understanding of the privacy choice.')),
        ((sPrompt: 'What should a group post to support peer review?';
          arrChoices: ('A private learner record',
       'A score with no explanation',
       'Pseudocode plus the inputs and expected output'); iCorrect: 2;
          sFeedback: 'Inputs and outcomes help peers understand and evaluate the reasoning.'),
         (sPrompt: 'Which comment is most useful?';
          arrChoices: ('Good',
       'Change the font',
       'Add a test where the target is the final item'); iCorrect: 2;
          sFeedback: 'An actionable test suggestion improves the quality of the solution.'),
         (sPrompt: 'Which work checks individual understanding?';
          arrChoices: ('An individual revision with a reason',
       'Page views',
       'The number of emojis on the group post'); iCorrect: 0;
          sFeedback: 'A revision and explanation show what the learner understood and improved.')))),
    (sName: 'Virtual reality (VR)';
     sCategory: 'Emerging technologies';
     sPurpose: 'Explore computer hardware in a simulated environment.';
     sLimits: 'Headsets can be expensive. Some learners experience discomfort and may need an accessible alternative.';
     sGuidance: 'Provide a non-headset option that checks the same learning objective.';
     arrTask: ('Explore a virtual computer. Identify key hardware and explain the function of each component on a worksheet.',
       'Use a virtual hardware environment to trace what happens when a learner runs a program. Ask how CPU, RAM and storage contribute to execution.');
     arrImplementation: ('Prepare - Choose a browser-based virtual computer or prepare three still images that show the CPU, RAM and storage device. Make a simple identification sheet.' + #13#10 +
        'In class - Give pairs a short tour while they record the component, location and function. Ask them to explain which part stores a document after shutdown.' + #13#10 +
        'Collect - Use an unlabelled image as an individual check. Learners label two parts and explain their function in a school computer.',
       'Prepare - Use a virtual computer view alongside a short Delphi program that reads a time, calculates a total and displays it.' + #13#10 +
        'In class - Have learners trace the input value through the Edit, variable and Label. Discuss the CPU instructions and the difference between working memory and saving a file.' + #13#10 +
        'Collect - Have each learner change an input and explain what is held during execution and what persists after they save their work.');
     arrEvidence: ('Check the component labels and explanations. Ask learners to explain one relationship between components.',
       'Check the diagram for the roles of storage, memory and the processor. Ask the learner to trace what happens when the program starts.');
     arrOffline: ('Use a labelled photo, projected stills or a decommissioned machine and give everyone the same worksheet.',
       'Provide a system diagram or a spare computer and have learners trace the same flow on paper.');
     arrCAPS: ('Systems Technologies: hardware and component functions',
       'Systems Technologies: processing, primary memory and storage');
     arrExample: ('Use a labelled lab-PC sketch. Match CPU to processing, RAM to temporary working data, and SSD to persistent storage.',
       'Use a Delphi results-entry app as a trace: read an Edit value, calculate with an Integer variable, show the result, then distinguish work in RAM from a saved result.');
     sResourceName: 'IBM overview: virtual reality in the XR comparison';
     sResourceURL: 'https://www.ibm.com/think/topics/augmented-reality';
     sPaperSection: 'Chapter 3 / Virtual Reality (VR) / Educational purpose';
     sRationale: 'Guided exploration helps learners connect a visual representation to a hardware concept. A still image or labelled sketch supports the same explanation where headsets are unavailable. Transfer skill: interpreting a technical model.';
     arrQuiz: (((sPrompt: 'What should learners do during the virtual hardware tour?';
          arrChoices: ('Identify components and explain what each does',
       'Spend the lesson exploring menus',
       'Rank headsets by price'); iCorrect: 0;
          sFeedback: 'The learning outcome is identifying hardware and explaining its function.'),
         (sPrompt: 'Which alternative checks the same outcome?';
          arrChoices: ('A worksheet about spreadsheet formatting',
       'A list of headset models',
       'A hardware photo or physical example with the same worksheet'); iCorrect: 2;
          sFeedback: 'The same worksheet can be completed with a different representation of the hardware.'),
         (sPrompt: 'Which response best shows understanding of RAM?';
          arrChoices: ('It stores every file permanently',
       'It is beside another component',
       'It holds data and instructions that are currently in use'); iCorrect: 2;
          sFeedback: 'RAM provides working memory while a program runs.')),
        ((sPrompt: 'When an application is running, which component provides working memory?';
          arrChoices: ('A keyboard',
       'A monitor',
       'RAM'); iCorrect: 2;
          sFeedback: 'RAM holds active data and instructions while the processor executes them.'),
         (sPrompt: 'What evidence best shows system understanding?';
          arrChoices: ('The number of items clicked',
       'An annotated trace connecting storage, memory and processor',
       'Time spent in the headset'); iCorrect: 1;
          sFeedback: 'An annotated trace explains interactions between components.'),
         (sPrompt: 'Which accessible alternative checks the same goal?';
          arrChoices: ('A system diagram with the same trace task',
       'An unrelated spreadsheet',
       'A list of headset brands'); iCorrect: 0;
          sFeedback: 'A clear diagram lets learners show the same system knowledge.')))),
    (sName: 'Internet of Things (IoT)';
     sCategory: 'Emerging technologies';
     sPurpose: 'Connect networking concepts to devices and sensors that exchange data.';
     sLimits: 'Physical boards and sensors introduce equipment costs. Connected devices also introduce privacy considerations.';
     sGuidance: 'Start with a diagram or simulation. Use fictional data and discuss who should be able to access it.';
     arrTask: ('Groups design a smart classroom and draw a network diagram showing how selected devices communicate.',
       'Design a fictional smart classroom. Teams identify input sensors, a controller and output devices, then describe the logic and message flow in a diagram.');
     arrImplementation: ('Prepare - Show a picture of a connected temperature sensor and create a fictional table with time and temperature readings. Use a diagram if hardware is unavailable.' + #13#10 +
        'In class - Have groups label the input, network connection and recipient. They inspect sample readings in a spreadsheet and decide which data should appear on a lab dashboard.' + #13#10 +
        'Collect - Each learner explains one benefit, one privacy consideration and why the sensor does not need to collect learner names.',
       'Prepare - Use a Delphi Edit to represent a temperature reading and a Label to represent the fan. Give learners a threshold of 28 degrees.' + #13#10 +
        'In class - Pairs code an IF THEN ELSE rule and test 27, 28 and 29. They annotate a diagram showing how a real sensor would send a reading to a controller.' + #13#10 +
        'Collect - Each learner changes the threshold, predicts one borderline result and runs a test to justify the new outcome.');
     arrEvidence: ('Check the diagram for sources, destinations and direction of data flow. Ask learners to justify one device and its data needs.',
       'Check the sequence from the reading to the controller and output. Ask learners to explain what happens at the threshold.');
     arrOffline: ('Use cards for sensors, devices and the controller. Trace messages between groups on a paper diagram.',
       'Use printed sensor and actuator cards. Simulate threshold decisions with fictional readings and trace each message on a paper network.');
     arrCAPS: ('Network and Internet Technologies and Social Implications: connected devices and privacy',
       'Solution Development: selection; Networks and Internet Technologies: data communication');
     arrExample: ('For a lab temperature sensor, list the value collected, who needs it and where it goes. Explain why a learner name is unnecessary.',
       'Simulate the sensor with iTemp. Use if iTemp >= 28 then sFan := ON else sFan := OFF; Test 27, 28 and 29.');
     sResourceName: 'IBM overview: Internet of Things';
     sResourceURL: 'https://www.ibm.com/think/topics/internet-of-things';
     sPaperSection: 'Chapter 3 / Internet of Things (IoT) / Example classroom activity';
     sRationale: 'An everyday sensor scenario makes input, processing and communication visible. Learners can choose a threshold and test a borderline value. Transfer skill: reasoning about data and connected systems.';
     arrQuiz: (((sPrompt: 'What is the initial role of a temperature sensor in a smart classroom?';
          arrChoices: ('Collect and send temperature readings',
       'Turn the light on by itself in every design',
       'Act as a spreadsheet formula'); iCorrect: 0;
          sFeedback: 'The sensor supplies data that the controller can use to decide whether to act.'),
         (sPrompt: 'What should arrows on an IoT network diagram show?';
          arrChoices: ('The direction of messages between devices',
       'The colours of connected equipment',
       'The size of the classroom'); iCorrect: 0;
          sFeedback: 'Directional arrows show where data originates and where it goes.'),
         (sPrompt: 'Which classroom dataset is appropriate for the first simulation?';
          arrChoices: ('Fictional readings with a discussion of who needs access',
       'Real footage with identifiable learners',
       'Real private contact details'); iCorrect: 0;
          sFeedback: 'Fictional readings support the design task and make room to discuss privacy.')),
        ((sPrompt: 'Which component applies the decision rule to a reading?';
          arrChoices: ('The sensor label',
       'The controller',
       'The classroom chair'); iCorrect: 1;
          sFeedback: 'A controller evaluates input and decides whether to send an output command.'),
         (sPrompt: 'What should learners include in a useful data-flow diagram?';
          arrChoices: ('Sources, destinations and the direction of messages',
       'Only device colours',
       'A screenshot with no labels'); iCorrect: 0;
          sFeedback: 'The diagram should let a reader trace messages between devices.'),
         (sPrompt: 'Which data is suitable for a classroom simulation?';
          arrChoices: ('Real identifiable learner footage',
       'Private contact details',
       'Fictional readings with clearly documented access'); iCorrect: 2;
          sFeedback: 'Fictional readings teach the system design without exposing personal data.')))),
    (sName: 'Robotics and automation';
     sCategory: 'Emerging technologies';
     sPurpose: 'Develop algorithmic thinking by planning, testing and debugging a robot route.';
     sLimits: 'Physical robots require equipment and maintenance. Online simulators require access.';
     sGuidance: 'Begin with a short route and assign rotating driver and navigator roles.';
     arrTask: ('Use Open Roberta Lab to program a simulated robot to move, turn and stop at a target. Test and revise the instructions.',
       'Use a simulator to design, implement and debug a sequence of moves, turns and a stopping condition. Submit the flawed and corrected instructions with a trace.');
     arrImplementation: ('Prepare - Prepare a paper floor grid and cards for Move, Turn and Stop. Mark one blocked square and provide a route from a start square to a target.' + #13#10 +
        'In class - One learner acts as the controller while another records inputs, processing rules and outputs. Swap roles and change the obstacle location.' + #13#10 +
        'Collect - Ask each learner to identify the blocked-square input, describe the action taken and explain where a different instruction would change the result.',
       'Prepare - Provide a floor grid and a Delphi starter form with a button and output memo. Represent the position and obstacle using Integer variables.' + #13#10 +
        'In class - Have pairs use a FOR loop to simulate movement. Add an IF condition that prevents entering the blocked position. Record each position in a trace table.' + #13#10 +
        'Collect - Each learner changes the obstacle location, predicts the positions printed and checks the result in Delphi.');
     arrEvidence: ('Collect original and corrected instructions. Ask learners to explain which change allowed the robot to reach the target.',
       'Compare the original and corrected commands and check the explanation of the first divergence.');
     arrOffline: ('Draw a grid. One learner writes commands and another follows them exactly as the robot. Swap roles for the next test.',
       'Draw a grid. One learner writes commands, another executes them literally, and each pair explains the first divergence and corrected route.');
     arrCAPS: ('Systems Technologies: input, processing and output',
       'Solution Development: sequencing, selection and trace tables');
     arrExample: ('On a desk grid, treat a blocked square as an input, a turn rule as processing and a turn as output. Log one failed route and correct it.',
       'Start iX at 0. Use for iStep := 1 to 3 do Inc(iX); Trace each position, then revise the task so the robot stops before a marked obstacle.');
     sResourceName: 'NASA Robotics: examples and applications';
     sResourceURL: 'https://www.nasa.gov/robotics/';
     sPaperSection: 'Chapter 3 / Robotics and Automation / Example classroom activity';
     sRationale: 'A visible route gives immediate feedback on an algorithm. Each learner should diagnose one failed move and revise the instructions. Transfer skill: debugging and computational thinking.';
     arrQuiz: (((sPrompt: 'What reveals an error in a robot route?';
          arrChoices: ('Change all turns before testing',
       'Run or trace the commands and compare the final position to the target',
       'Count how many commands were written'); iCorrect: 1;
          sFeedback: 'Tracing the route shows where movement first differs from the intended sequence.'),
         (sPrompt: 'What does the learner playing the robot do in the offline activity?';
          arrChoices: ('Move directly to the target',
       'Follow the written instructions exactly',
       'Fill in missing steps without telling the programmer'); iCorrect: 1;
          sFeedback: 'Exact execution exposes ambiguities, missing steps and wrong turns.'),
         (sPrompt: 'What is useful evidence of debugging?';
          arrChoices: ('Original commands, revised commands and an explanation of the fix',
       'A route with no record of changes',
       'The simulator''s title'); iCorrect: 0;
          sFeedback: 'Comparing both versions shows what changed and why it worked.')),
        ((sPrompt: 'How do you locate the first error in a route?';
          arrChoices: ('Rewrite all instructions at once',
       'Count the words only',
       'Trace commands one at a time against the expected path'); iCorrect: 2;
          sFeedback: 'Tracing isolates the first difference between predicted and actual movement.'),
         (sPrompt: 'What should the learner acting as a robot do?';
          arrChoices: ('Guess missing instructions',
       'Jump to the target',
       'Execute each instruction literally'); iCorrect: 2;
          sFeedback: 'Literal execution makes ambiguity and logic faults visible.'),
         (sPrompt: 'Which evidence shows genuine debugging?';
          arrChoices: ('The date of the lesson',
       'The original route, corrected route and a reason for the change',
       'The robot''s name only'); iCorrect: 1;
          sFeedback: 'The comparison shows the fault, the fix and the reasoning.')))),
    (sName: 'Cloud computing';
     sCategory: 'Emerging technologies';
     sPurpose: 'Teach shared access, storage and collaboration through a cloud-based task.';
     sLimits: 'Plan for connectivity, data costs, access permissions and the protection of personal information.';
     sGuidance: 'Use sample data and restrict sharing to the intended class group. Check permissions before giving access.';
     arrTask: ('Groups create a shared online spreadsheet. Each member adds data, formats a section or adds formulas while the teacher monitors progress.',
       'Share a fictional test log or design specification with a small group. Assign permissions by role and compare version history to a local change log.');
     arrImplementation: ('Prepare - Share a fictional equipment inventory workbook in OneDrive. Give pairs edit access and set up a view-only reviewer.' + #13#10 +
        'In class - One learner enters quantities while the other verifies the totals and changes in version history. Swap roles and confirm that the reviewer cannot edit.' + #13#10 +
        'Collect - Have each learner save a local copy and explain when a view-only link is appropriate. Inspect the workbook total and sharing permissions.',
       'Prepare - Provide two copies of a small Delphi project in a managed folder and a separate local work folder. Give reviewers read access to the shared copy.' + #13#10 +
        'In class - Learners make a simple display change locally and test it before sharing a named revision. Ask them to compare the local and synced copies after reconnection.' + #13#10 +
        'Collect - Each learner describes which version ran, identifies a risk of both partners editing one project file and explains how the pair kept versions traceable.');
     arrEvidence: ('Check individual contributions and formula accuracy. Ask learners to explain a sensible sharing permission.',
       'Review the change log and ask each learner to justify who needs viewing or editing access.');
     arrOffline: ('Use a local spreadsheet in groups with rotating roles and a written change log. Discuss how the same workflow would differ in the cloud.',
       'Use a local file with a change-log template and rotating roles. Have learners explain which permissions a cloud version would need.');
     arrCAPS: ('Solution Development and Social Implications: collaboration, spreadsheet formulas and access control',
       'Systems Technologies and Social Implications: storage, synchronisation and access control');
     arrExample: ('Use a fictional equipment inventory. One partner enters 4 and 6 in B2:B3; the other checks SUM = 10 and verifies view-only access for a reviewer.',
       'Save a fictional Delphi project locally, then compare a shared copy with view or edit access. Explain what happens to a local change while offline and how to check the synced version.');
     sResourceName: 'Microsoft Support: collaborate in OneDrive';
     sResourceURL: 'https://support.microsoft.com/en-us/onedrive/collaborate-in-microsoft-onedrive-sharing-editing-and-managing-files';
     sPaperSection: 'Chapter 3 / Cloud Computing / Opportunities for Self-Directed Learning';
     sRationale: 'A shared file enables peer review when permissions and roles are clear. Learners can check what changed and explain who should have access. Transfer skill: responsible digital collaboration.';
     arrQuiz: (((sPrompt: 'Which permissions suit a shared spreadsheet task?';
          arrChoices: ('Owner access for every internet user',
       'Public edit access for everyone',
       'Edit access for assigned group members'); iCorrect: 2;
          sFeedback: 'Restricted edit access supports collaboration while limiting unintended changes.'),
         (sPrompt: 'Which evidence shows both group and individual work?';
          arrChoices: ('The filename only',
       'The number of sheets alone',
       'The spreadsheet plus a record of contributions and accurate formulas'); iCorrect: 2;
          sFeedback: 'Checking formulas and contributions captures the group product and individual participation.'),
         (sPrompt: 'Which fallback preserves collaboration when cloud access drops?';
          arrChoices: ('Use a public account later',
       'Rotate roles in a local workbook and record changes in a log',
       'Stop tracking contributions'); iCorrect: 1;
          sFeedback: 'A local workbook and change log keep the task collaborative and traceable.')),
        ((sPrompt: 'What access should a group member editing a shared test log receive?';
          arrChoices: ('No access at all',
       'Edit access limited to the group workspace',
       'Public ownership privileges'); iCorrect: 1;
          sFeedback: 'Role-based access supports the task while restricting unnecessary access.'),
         (sPrompt: 'Why compare version history with a change log?';
          arrChoices: ('To measure typing speed',
       'To rank devices',
       'To explain how an earlier state can be traced and recovered'); iCorrect: 2;
          sFeedback: 'Both records help identify what changed and when.'),
         (sPrompt: 'Which fallback preserves the collaboration objective?';
          arrChoices: ('A private file nobody shares',
       'A public upload without review',
       'A local file with rotating roles and a change log'); iCorrect: 2;
          sFeedback: 'The offline workflow still makes contribution and revision visible.')))));

implementation

end.
