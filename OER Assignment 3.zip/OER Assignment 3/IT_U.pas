unit IT_U;

interface

uses
  CAT_U;

type
  // This visual form inherits the CAT layout and shared event handlers.
  // Its curriculum, activity adaptations and quiz bank are selected as IT.
  TfrmIT = class(TfrmCAT)
  end;

var
  frmIT: TfrmIT;  // Form Designer reference.

implementation

{$R *.dfm}

end.
