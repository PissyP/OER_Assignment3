﻿unit Paper_U;

interface

uses System.Classes;

procedure LoadPaperSection(iSection: Integer; lstLines: TStrings);

implementation

procedure AddSection1(lstLines: TStrings);
begin
  lstLines.Add('Chapter 1: Artificial Intelligence for Teaching and Learning in CAT and IT Education');
  lstLines.Add('');
  lstLines.Add('Introduction');
  lstLines.Add('');
  lstLines.Add('Artificial intelligence (AI) has become an increasingly visible part of everyday life, workplaces an' +
    'd education. Generative AI systems can produce explanations, summaries, images, questions and comput' +
    'er code in response to natural-language instructions. Other AI-supported systems can guide learners ' +
    'through problems, recommend learning resources or help teachers prepare lessons and assessment mater' +
    'ials. These developments are important in Computer Science Education because CAT and IT learners are' +
    ' expected not only to use digital technologies, but also to understand how information systems work,' +
    ' evaluate digital information, solve problems and use technology responsibly. The growth of AI there' +
    'fore creates both new learning opportunities and new responsibilities for teachers and learners.');
  lstLines.Add('');
  lstLines.Add('In CAT, AI may support research, information management, spreadsheet interpretation, document produc' +
    'tion, presentations and the study of the social implications of technology. In IT, it may support al' +
    'gorithmic reasoning, programming, debugging, database planning and technical research. These applica' +
    'tions connect with the CAPS emphasis on practical digital competence, problem-solving, information p' +
    'rocessing and responsible use of technology (Department of Basic Education, 2011a; 2011b). However, ' +
    'AI-generated answers can be inaccurate, biased, incomplete or fabricated. Learners must therefore be' +
    ' taught to question outputs, test suggestions and consult reliable sources rather than treating an A' +
    'I response as automatically correct.');
  lstLines.Add('');
  lstLines.Add('The educational value of AI depends on the relationship between technology, pedagogy and subject con' +
    'tent. Mishra and Koehler’s (2006) Technological Pedagogical Content Knowledge framework is useful be' +
    'cause it reminds teachers that knowing how to operate a tool is not enough: teachers must decide whe' +
    'ther it supports the specific concept, learning outcome and teaching strategy. Vygotsky’s (1978) con' +
    'cept of scaffolding is also relevant. An AI assistant may offer hints, examples or alternative expla' +
    'nations within a learner’s zone of proximal development, but the teacher must ensure that support is' +
    ' gradually reduced as learners become more capable of working independently. In this way, AI should ' +
    'extend teaching rather than replace teacher–learner interaction.');
  lstLines.Add('');
  lstLines.Add('This chapter evaluates six AI technologies that may be relevant to beginning CAT and IT teachers: Ch' +
    'atGPT, Microsoft Copilot, Google Gemini, Khanmigo, MagicSchool AI and Perplexity AI. The tools are n' +
    'ot identical. Some are general-purpose conversational assistants, some are designed around guided tu' +
    'toring, some support teacher planning, and others combine AI responses with source discovery. The ch' +
    'apter considers their educational purposes, access models, strengths, limitations and classroom uses' +
    '. Particular attention is given to self-directed learning (SDL), which involves learners taking an a' +
    'ctive role in identifying learning needs, setting goals, selecting strategies, monitoring progress a' +
    'nd evaluating outcomes (Knowles, Holton and Swanson, 2020).');
  lstLines.Add('');
  lstLines.Add('AI integration must also be considered in the South African context. Unequal access to devices, reli' +
    'able connectivity and affordable data can limit participation. Schools may also differ in their poli' +
    'cies, technical support and readiness to use AI. For this reason, the chapter does not assume that e' +
    'very learner can access every platform or that a paid feature is suitable for classroom use. The cen' +
    'tral argument is that AI should be selected only when it advances a clear CAPS-aligned learning purp' +
    'ose, is accessible to the class, and is supported by explicit guidance on accuracy, privacy, academi' +
    'c honesty and responsible use.');
  lstLines.Add('');
  lstLines.Add('Theoretical and pedagogical foundations');
  lstLines.Add('');
  lstLines.Add('Self-directed learning');
  lstLines.Add('');
  lstLines.Add('Self-directed learning refers to a process in which learners take initiative in diagnosing their lea' +
    'rning needs, formulating goals, identifying resources, choosing strategies and evaluating their prog' +
    'ress (Knowles, Holton and Swanson, 2020). AI can support this process by making explanations and pra' +
    'ctice opportunities available when a learner encounters difficulty. For example, a CAT learner who d' +
    'oes not understand the difference between COUNT, COUNTA and COUNTBLANK can ask for an explanation, r' +
    'equest a new example and then test the functions in a spreadsheet. The learner demonstrates SDL only' +
    ' when they evaluate the explanation, practise independently and reflect on whether their understandi' +
    'ng has improved. Copying the generated explanation is not evidence of self-direction.');
  lstLines.Add('');
  lstLines.Add('Constructivism and social constructivism');
  lstLines.Add('');
  lstLines.Add('Constructivist learning emphasises active engagement with problems and the development of understand' +
    'ing through experience. Social constructivism adds the importance of dialogue, guidance and interact' +
    'ion with others (Vygotsky, 1978). AI can act as a source of prompts or alternative explanations, but' +
    ' learners should still discuss ideas, compare solutions and demonstrate understanding. In an IT less' +
    'on, for example, learners can compare two AI-suggested algorithms, test each algorithm with sample i' +
    'nputs and explain why one is more efficient or appropriate.');
  lstLines.Add('');
  lstLines.Add('Scaffolding and gradual release');
  lstLines.Add('');
  lstLines.Add('Scaffolding is temporary support that helps a learner complete a task that they could not yet manage' +
    ' independently. In an AI-supported lesson, scaffolding may take the form of a hint, a worked example' +
    ', a sequence of questions or feedback on an attempted solution. Teachers should move from modelling ' +
    'to guided practice, to independent application. If AI provides the complete answer before the learne' +
    'r has attempted the task, it may remove the thinking that the lesson is intended to develop.');
  lstLines.Add('');
  lstLines.Add('Technological Pedagogical Content Knowledge');
  lstLines.Add('');
  lstLines.Add('Mishra and Koehler (2006) argue that effective technology integration requires teachers to consider ' +
    'technology, pedagogy and content together. A CAT teacher should therefore ask whether an AI tool hel' +
    'ps learners understand and apply spreadsheet concepts, rather than simply whether it can generate sp' +
    'readsheet formulas. An IT teacher should ask whether code suggestions strengthen algorithmic reasoni' +
    'ng or allow learners to bypass it. The teacher’s professional judgement remains central.');
  lstLines.Add('');
  lstLines.Add('Connectivism and information literacy');
  lstLines.Add('');
  lstLines.Add('Digital learning involves navigating networks of information, people and resources. Siemens (2005) h' +
    'ighlights the importance of making connections and evaluating knowledge in a changing information en' +
    'vironment. AI tools can help learners locate ideas and possible sources, but they can also produce u' +
    'nsupported claims. Learners therefore need to trace claims to original sources, assess credibility a' +
    'nd distinguish evidence from generated text.');
  lstLines.Add('');
  lstLines.Add('Critical evaluation of AI technologies');
  lstLines.Add('');
  lstLines.Add('The following six technologies are evaluated using a consistent structure, following the detailed pl' +
    'atform-by-platform approach used in the Specialist 2 example. Website addresses and cost description' +
    's are included as a starting point; access, product names, age requirements, regional availability a' +
    'nd free-plan limits can change. Teachers should confirm current conditions before using a platform w' +
    'ith learners.');
  lstLines.Add('');
  lstLines.Add('3.1 ChatGPT');
  lstLines.Add('');
  lstLines.Add('Website    https://chatgpt.com/');
  lstLines.Add('');
  lstLines.Add('Cost/access    Freemium. A free level is available, while paid plans may provide higher usage limit' +
    's or additional models and tools. Availability and limits can vary by account, country and time.');
  lstLines.Add('');
  lstLines.Add('Overview    ChatGPT is a conversational generative AI assistant that responds to natural-language p' +
    'rompts. It can explain concepts, generate examples, summarise text, help plan tasks and provide supp' +
    'ort with coding and problem-solving. In education, it can function as a supplementary learning assis' +
    'tant and teacher-planning aid.');
  lstLines.Add('');
  lstLines.Add('Educational purpose    To support explanation, guided practice, brainstorming, feedback, revision a' +
    'nd problem-solving while encouraging learners to ask questions and evaluate information.');
  lstLines.Add('');
  lstLines.Add('Key features    Conversational question-and-answer interaction; follow-up prompts; text generation ' +
    'and summarisation; alternative explanations and examples; coding and debugging guidance; generation ' +
    'of practice questions and lesson resources. Specific tools and capabilities depend on the account.');
  lstLines.Add('');
  lstLines.Add('Advantages');
  lstLines.Add('');
  lstLines.Add('It allows learners to ask follow-up questions when an initial explanation is unclear. A learner can ' +
    'request a simpler explanation, a worked example or a new practice question, which can support differ' +
    'entiated learning.');
  lstLines.Add('');
  lstLines.Add('It can help teachers prepare lesson introductions, examples, formative questions, scenarios and draf' +
    't rubrics. This may reduce routine preparation time, allowing teachers to devote more attention to l' +
    'earner feedback and practical support.');
  lstLines.Add('');
  lstLines.Add('It can support comparison of alternative approaches. In IT, learners can request two possible algori' +
    'thms and then test and evaluate them rather than accepting the first suggestion.');
  lstLines.Add('');
  lstLines.Add('Limitations and risks');
  lstLines.Add('');
  lstLines.Add('ChatGPT may produce confident but inaccurate information, incorrect formulas or code that does not w' +
    'ork. All outputs must be checked against subject knowledge, CAPS requirements and practical testing.');
  lstLines.Add('');
  lstLines.Add('Learners may copy generated answers, submit work they do not understand or become dependent on immed' +
    'iate responses. Assessment must therefore require explanation, process evidence and independent appl' +
    'ication.');
  lstLines.Add('');
  lstLines.Add('Output quality depends on the clarity and context of the prompt. Learners need explicit instruction ' +
    'in asking useful questions and checking the response.');
  lstLines.Add('');
  lstLines.Add('Internet access, account requirements, usage limits and age-related rules may restrict classroom use' +
    '. Teachers should check current terms and school policy.');
  lstLines.Add('');
  lstLines.Add('CAT classroom applications');
  lstLines.Add('');
  lstLines.Add('In CAT, learners can ask ChatGPT to explain spreadsheet functions such as SUMIF, AVERAGE and COUNTIF' +
    ' using a small-business dataset. They should then enter the formulas in Excel or another approved sp' +
    'readsheet application, compare the actual results with the explanation and correct errors. In inform' +
    'ation management, learners may use it to brainstorm research questions, but must locate and cite ori' +
    'ginal sources. In word processing and presentations, it can provide planning feedback while learners' +
    ' create and format the final artefact themselves.');
  lstLines.Add('');
  lstLines.Add('IT classroom applications');
  lstLines.Add('');
  lstLines.Add('In IT, learners can ask for an explanation of a programming concept, request hints about an error me' +
    'ssage or compare possible algorithms. They must run the code, test normal and boundary inputs, ident' +
    'ify errors and explain the logic. For database design, learners can discuss possible entities and re' +
    'lationships but must justify their own data model and implement it in the database application.');
  lstLines.Add('');
  lstLines.Add('Teaching, learning and assessment strategies');
  lstLines.Add('');
  lstLines.Add('Use guided inquiry, think-pair-share, worked examples, debugging workshops, formative questioning an' +
    'd peer review. The teacher can ask learners to submit the original prompt, AI response, corrections ' +
    'and final solution. Assessment should reward reasoning, testing and explanation, not merely a polish' +
    'ed AI-generated product.');
  lstLines.Add('');
  lstLines.Add('Self-Directed Learning opportunities');
  lstLines.Add('');
  lstLines.Add('Learners can identify a difficulty, formulate a precise question, evaluate the answer, practise the ' +
    'skill in the relevant application and record what remains unclear. A reflection log can ask: What di' +
    'd I ask? Which part was useful? What did I verify? What can I now do without assistance?');
  lstLines.Add('');
  lstLines.Add('AI integration opportunities');
  lstLines.Add('');
  lstLines.Add('The tool itself provides a direct opportunity to teach AI literacy. Learners can examine hallucinati' +
    'ons, compare responses to reliable sources, improve prompts, discuss bias and identify tasks where A' +
    'I assistance is inappropriate.');
  lstLines.Add('');
  lstLines.Add('Authentic classroom activity');
  lstLines.Add('');
  lstLines.Add('Grade 10 CAT spreadsheet investigation: learners receive a sales dataset containing product names, q' +
    'uantities and prices. They first attempt to calculate total sales and count transactions. They then ' +
    'ask ChatGPT for an explanation of an appropriate function, verify the suggested formula in the sprea' +
    'dsheet, test it with a second dataset and write a short explanation of why the formula works. The te' +
    'acher assesses the workbook, the testing evidence and the learner’s explanation.');
  lstLines.Add('');
  lstLines.Add('Professional recommendation');
  lstLines.Add('');
  lstLines.Add('Strongly recommended as a supplementary assistant for CAT and IT when the teacher establishes clear ' +
    'boundaries. It is particularly useful for explanations, practice and comparing approaches. It should' +
    ' not be used to complete practical tasks on behalf of learners or replace verified sources and teach' +
    'er feedback.');
  lstLines.Add('');
  lstLines.Add('3.2 Microsoft Copilot');
  lstLines.Add('');
  lstLines.Add('Website    https://copilot.microsoft.com/');
  lstLines.Add('');
  lstLines.Add('Cost/access    Freemium. Basic access may be available without payment; advanced capabilities and d' +
    'eeper integration with Microsoft 365 applications can require eligible paid or institutional licence' +
    's. Features differ by account and product.');
  lstLines.Add('');
  lstLines.Add('Overview    Microsoft Copilot is an AI assistant within Microsoft’s product ecosystem. Depending on' +
    ' the version and licence, it can support conversational information exploration, drafting, summarisi' +
    'ng and selected workflows involving Word, Excel, PowerPoint and other Microsoft services.');
  lstLines.Add('');
  lstLines.Add('Educational purpose    To support productivity, information interpretation, drafting and the effect' +
    'ive use of digital productivity applications, especially in contexts where schools already use Micro' +
    'soft tools.');
  lstLines.Add('');
  lstLines.Add('Key features    Conversational assistance; drafting and summarising; support for planning and inter' +
    'preting information; selected Microsoft 365 integrations; assistance with document, spreadsheet or p' +
    'resentation workflows where enabled by the licence.');
  lstLines.Add('');
  lstLines.Add('Advantages');
  lstLines.Add('');
  lstLines.Add('Its relationship with Microsoft applications makes it relevant to CAT, where learners work with word' +
    ' processing, spreadsheets, presentations and information management.');
  lstLines.Add('');
  lstLines.Add('It can help learners plan a report, interpret a dataset or consider ways to communicate findings. Th' +
    'ese suggestions can be compared with learners’ own calculations and decisions.');
  lstLines.Add('');
  lstLines.Add('It can help teachers draft instructions, exemplars and differentiated explanations. It can also intr' +
    'oduce learners to AI-supported productivity practices increasingly encountered in workplaces.');
  lstLines.Add('');
  lstLines.Add('Limitations and risks');
  lstLines.Add('');
  lstLines.Add('Advanced Microsoft 365 integration may require a paid or institutional licence, so teachers should n' +
    'ot assume that all learners have the same features.');
  lstLines.Add('');
  lstLines.Add('AI-generated summaries or analysis may be wrong or may overlook important details. Learners must che' +
    'ck results against the original document or dataset.');
  lstLines.Add('');
  lstLines.Add('If Copilot performs the spreadsheet, document or presentation operations that learners are expected ' +
    'to demonstrate, it can undermine the assessment of practical skills.');
  lstLines.Add('');
  lstLines.Add('Features and data handling arrangements vary across products and accounts. Schools should check priv' +
    'acy settings and institutional approval.');
  lstLines.Add('');
  lstLines.Add('CAT classroom applications');
  lstLines.Add('');
  lstLines.Add('CAT learners can use Copilot as a planning assistant for a Word report, a presentation outline or an' +
    ' Excel data investigation. For example, it may suggest trends in a survey dataset; learners must cal' +
    'culate the relevant statistics independently, create charts and decide whether the suggested interpr' +
    'etation is supported by the data. Teachers can also use it to draft spreadsheet scenarios and questi' +
    'on sets.');
  lstLines.Add('');
  lstLines.Add('IT classroom applications');
  lstLines.Add('');
  lstLines.Add('IT learners may use Copilot to help plan technical documentation, clarify terminology or outline sta' +
    'ges of a software project. If code assistance is used, learners must understand, run and test the co' +
    'de, explain each important section and acknowledge assistance according to the teacher’s instruction' +
    's.');
  lstLines.Add('');
  lstLines.Add('Teaching, learning and assessment strategies');
  lstLines.Add('');
  lstLines.Add('Use demonstration followed by independent practice, problem-based learning, comparison of AI suggest' +
    'ions with actual application results and formative feedback. A useful assessment method is to requir' +
    'e both the completed digital file and a short process commentary identifying which suggestions were ' +
    'accepted, adapted or rejected.');
  lstLines.Add('');
  lstLines.Add('Self-Directed Learning opportunities');
  lstLines.Add('');
  lstLines.Add('Learners should attempt the task before requesting AI help. They can then ask a targeted question, v' +
    'erify the suggestion in the relevant application and record the steps they used to solve the problem' +
    '. This sequence supports persistence and reflection rather than automatic reliance.');
  lstLines.Add('');
  lstLines.Add('AI integration opportunities');
  lstLines.Add('');
  lstLines.Add('Learners can investigate how AI is embedded in productivity software, what data may be processed and' +
    ' how automated suggestions influence decisions. A class can compare a human interpretation of a data' +
    'set with an AI-generated interpretation and identify omissions or unsupported conclusions.');
  lstLines.Add('');
  lstLines.Add('Authentic classroom activity');
  lstLines.Add('');
  lstLines.Add('Grade 11 CAT data analysis: learners receive a survey dataset about learners’ study habits. They ask' +
    ' Copilot to suggest two possible trends, then use Excel functions and charts to test those claims. T' +
    'hey prepare a short report explaining which claims are supported by the data, which are not, and why' +
    '. The teacher assesses spreadsheet accuracy, chart selection and critical interpretation.');
  lstLines.Add('');
  lstLines.Add('Professional recommendation');
  lstLines.Add('');
  lstLines.Add('Highly recommended where a school already uses Microsoft applications and has suitable access. It ha' +
    's strong relevance to CAT productivity skills, but teachers must protect opportunities for learners ' +
    'to perform the practical operations themselves.');
  lstLines.Add('');
  lstLines.Add('3.3 Google Gemini');
  lstLines.Add('');
  lstLines.Add('Website    https://gemini.google.com/');
  lstLines.Add('');
  lstLines.Add('Cost/access    Freemium. Basic access may be available at no cost; higher usage limits and addition' +
    'al features may require a paid Google AI plan. Availability depends on region, account type, age req' +
    'uirements and current product arrangements.');
  lstLines.Add('');
  lstLines.Add('Overview    Google Gemini is a generative AI assistant that supports conversational exploration, dr' +
    'afting, explanation and, in supported versions, interaction with different forms of content. It can ' +
    'help users explore a topic and develop initial ideas or questions.');
  lstLines.Add('');
  lstLines.Add('Educational purpose    To support research preparation, conceptual understanding, idea development ' +
    'and the exploration of information through conversational AI.');
  lstLines.Add('');
  lstLines.Add('Key features    Conversational explanations and follow-up questions; summarising and drafting; idea' +
    ' generation; interaction with images or other content in supported versions; integration with select' +
    'ed Google services where enabled.');
  lstLines.Add('');
  lstLines.Add('Advantages');
  lstLines.Add('');
  lstLines.Add('It can provide alternative explanations and examples, which may help learners approach difficult tec' +
    'hnology concepts from different perspectives.');
  lstLines.Add('');
  lstLines.Add('It can assist teachers in preparing discussion prompts, lesson examples and research activities. Lea' +
    'rners can use it to develop questions before consulting textbooks and credible sources.');
  lstLines.Add('');
  lstLines.Add('Where multimodal functions are available, learners may explore how AI interprets visual or other con' +
    'tent, creating opportunities to discuss the strengths and limitations of AI systems.');
  lstLines.Add('');
  lstLines.Add('Limitations and risks');
  lstLines.Add('');
  lstLines.Add('Responses may contain inaccuracies, bias or incomplete explanations. Learners must compare important' +
    ' claims with textbooks, official documentation and other credible sources.');
  lstLines.Add('');
  lstLines.Add('Features can differ according to account, region, age requirements and subscription. A teacher shoul' +
    'd not build a compulsory assessment around a feature that some learners cannot access.');
  lstLines.Add('');
  lstLines.Add('Generated summaries may encourage learners to skim rather than read original material. Teachers shou' +
    'ld require source inspection, note-taking and evidence-based conclusions.');
  lstLines.Add('');
  lstLines.Add('Privacy and institutional requirements must be considered before learners enter personal information' +
    ', school data or unpublished work.');
  lstLines.Add('');
  lstLines.Add('CAT classroom applications');
  lstLines.Add('');
  lstLines.Add('CAT learners can use Gemini to explore the social implications of AI, develop research questions abo' +
    'ut digital citizenship or obtain an initial explanation of spreadsheet concepts. They should produce' +
    ' their own report or presentation and verify claims using original sources. Teachers may use it to c' +
    'reate contrasting scenarios about responsible and irresponsible technology use.');
  lstLines.Add('');
  lstLines.Add('IT classroom applications');
  lstLines.Add('');
  lstLines.Add('IT learners can use Gemini to explore programming concepts, interpret technical terminology or discu' +
    'ss emerging technologies. Any code or technical claim must be tested against a working environment o' +
    'r authoritative documentation. Learners can compare AI explanations with their actual program output' +
    '.');
  lstLines.Add('');
  lstLines.Add('Teaching, learning and assessment strategies');
  lstLines.Add('');
  lstLines.Add('Use inquiry-based learning, source comparison, concept mapping, discussion and practical verificatio' +
    'n. Ask learners to label statements as verified, uncertain or unsupported, then provide evidence for' +
    ' their decisions.');
  lstLines.Add('');
  lstLines.Add('Self-Directed Learning opportunities');
  lstLines.Add('');
  lstLines.Add('Learners can set a research or understanding goal, ask Gemini focused questions, identify what they ' +
    'still do not understand and follow up using independent resources. They should evaluate their own pr' +
    'ogress rather than treating a fluent response as proof of mastery.');
  lstLines.Add('');
  lstLines.Add('AI integration opportunities');
  lstLines.Add('');
  lstLines.Add('Gemini can be used to introduce multimodal AI and discuss how systems interpret prompts and content.' +
    ' Learners can compare AI-generated interpretations with their own observations and discuss bias, unc' +
    'ertainty and data privacy.');
  lstLines.Add('');
  lstLines.Add('Authentic classroom activity');
  lstLines.Add('');
  lstLines.Add('Grade 10 CAT technology research: learners investigate how AI is used in education. They ask Gemini ' +
    'to suggest key benefits and concerns, then verify at least three claims using credible sources such ' +
    'as government, university or recognised research publications. They create a short presentation that' +
    ' separates verified evidence from AI-generated suggestions.');
  lstLines.Add('');
  lstLines.Add('Professional recommendation');
  lstLines.Add('');
  lstLines.Add('Recommended as a supplementary general-purpose assistant, especially in schools using Google service' +
    's. It is most educationally useful when paired with source evaluation, learner discussion and practi' +
    'cal verification.');
  lstLines.Add('');
  lstLines.Add('3.4 Khanmigo');
  lstLines.Add('');
  lstLines.Add('Website    https://www.khanacademy.org/khan-labs');
  lstLines.Add('');
  lstLines.Add('Cost/access    Availability and cost depend on Khan Academy’s current product arrangements. Some ac' +
    'cess has been subscription- or institution-dependent. South African regional availability, supported' +
    ' subjects and age/account requirements must be checked before adoption.');
  lstLines.Add('');
  lstLines.Add('Overview    Khanmigo is an AI-supported tutoring and teaching assistant associated with Khan Academ' +
    'y. Its tutoring approach is designed to guide learners through reasoning with prompts and hints rath' +
    'er than simply supplying completed answers. Its suitability for a particular CAT or IT topic depends' +
    ' on current subject coverage.');
  lstLines.Add('');
  lstLines.Add('Educational purpose    To provide guided practice, questioning and feedback that encourage learners' +
    ' to explain their reasoning and work through a problem step by step.');
  lstLines.Add('');
  lstLines.Add('Key features    Tutoring-style dialogue; hints and guiding questions; prompts that ask learners to ' +
    'explain their thinking; links with Khan Academy learning content where available; teacher-support fu' +
    'nctions subject to the current offering.');
  lstLines.Add('');
  lstLines.Add('Advantages');
  lstLines.Add('');
  lstLines.Add('A guided-questioning approach can encourage learners to think through a problem instead of receiving' +
    ' an immediate final answer.');
  lstLines.Add('');
  lstLines.Add('Questions and hints may reveal misconceptions, giving the learner and teacher information about wher' +
    'e understanding breaks down.');
  lstLines.Add('');
  lstLines.Add('The approach is consistent with scaffolding and metacognition when learners are asked to explain why' +
    ' they selected a step or strategy.');
  lstLines.Add('');
  lstLines.Add('It may offer additional practice where the relevant content is supported and accessible.');
  lstLines.Add('');
  lstLines.Add('Limitations and risks');
  lstLines.Add('');
  lstLines.Add('Regional availability and affordability may limit use in South African schools. Teachers must verify' +
    ' access rather than assume that the service is available to every learner.');
  lstLines.Add('');
  lstLines.Add('Not all CAT and IT topics may be covered directly. The platform should not be presented as a special' +
    'ist CAT or IT tutor unless the relevant content is confirmed.');
  lstLines.Add('');
  lstLines.Add('Product features, supported content and account arrangements may change. Teacher oversight is still ' +
    'required to ensure curriculum relevance.');
  lstLines.Add('');
  lstLines.Add('AI tutoring can still make mistakes or provide hints that do not fit the exact classroom task.');
  lstLines.Add('');
  lstLines.Add('CAT classroom applications');
  lstLines.Add('');
  lstLines.Add('A CAT teacher can adapt the guided-questioning approach to spreadsheet reasoning. For example, learn' +
    'ers can be asked what information a question requires, which function might be suitable and how they' +
    ' will test the result. If the platform does not directly cover the relevant CAT function, the teache' +
    'r can use its tutoring style as a model for classroom questioning rather than requiring learners to ' +
    'use the platform.');
  lstLines.Add('');
  lstLines.Add('IT classroom applications');
  lstLines.Add('');
  lstLines.Add('Where relevant content is available, IT learners may use guided questions to reason through computat' +
    'ional or mathematical problems. For an algorithm task, learners should trace the steps, predict outp' +
    'uts, identify a point of failure and explain a correction. The teacher should confirm that the platf' +
    'orm’s content matches the intended concept.');
  lstLines.Add('');
  lstLines.Add('Teaching, learning and assessment strategies');
  lstLines.Add('');
  lstLines.Add('Use guided discovery, scaffolding, metacognitive questioning and formative assessment. The teacher c' +
    'an ask learners to show the steps they took and explain how a hint changed their thinking. The final' +
    ' task should be completed independently.');
  lstLines.Add('');
  lstLines.Add('Self-Directed Learning opportunities');
  lstLines.Add('');
  lstLines.Add('The tool may help learners identify what they know, what they do not know and what step to attempt n' +
    'ext. Learners can reflect on which hints were useful and whether they can now solve a similar proble' +
    'm without help. This is especially valuable when the teacher gradually reduces support.');
  lstLines.Add('');
  lstLines.Add('AI integration opportunities');
  lstLines.Add('');
  lstLines.Add('Khanmigo provides a useful contrast for teaching the difference between answer-generating AI and tut' +
    'oring-oriented AI. Learners can discuss why hints and questions may support deeper reasoning more ef' +
    'fectively than simply receiving a finished solution.');
  lstLines.Add('');
  lstLines.Add('Authentic classroom activity');
  lstLines.Add('');
  lstLines.Add('IT algorithm tracing activity: learners are given a short algorithm and a set of input values. They ' +
    'predict the output, work through the steps and identify an intentional logic error. Where Khanmigo s' +
    'upports the relevant topic, learners compare its hints with their own reasoning, then correct and ex' +
    'plain the algorithm without copying a completed solution.');
  lstLines.Add('');
  lstLines.Add('Professional recommendation');
  lstLines.Add('');
  lstLines.Add('Potentially valuable for guided tutoring and metacognition, but recommend conditionally. Confirm Sou' +
    'th African access, cost, age requirements and subject coverage before including it as a required lea' +
    'rner platform. Its questioning approach can still inform teacher-designed scaffolding.');
  lstLines.Add('');
  lstLines.Add('3.5 MagicSchool AI');
  lstLines.Add('');
  lstLines.Add('Website    https://www.magicschool.ai/');
  lstLines.Add('');
  lstLines.Add('Cost/access    Freemium. A free level and paid or institutional options may be available; tool acce' +
    'ss, usage limits and features can change. Teachers should confirm the current plan and privacy terms' +
    '.');
  lstLines.Add('');
  lstLines.Add('Overview    MagicSchool AI is primarily an educator-facing platform that offers AI tools for instru' +
    'ctional planning and resource development. It can assist teachers with drafting lesson plans, questi' +
    'ons, rubrics, differentiated materials and other classroom resources.');
  lstLines.Add('');
  lstLines.Add('Educational purpose    To support teacher preparation, instructional design, differentiation and as' +
    'sessment planning, thereby helping teachers develop resources that respond to varied learner needs.');
  lstLines.Add('');
  lstLines.Add('Key features    Teacher-oriented tools for lesson planning and resource drafting; question and quiz' +
    ' generation; rubric and assessment support; differentiated explanations and activities; other educat' +
    'or workflows depending on current account access.');
  lstLines.Add('');
  lstLines.Add('Advantages');
  lstLines.Add('');
  lstLines.Add('It may reduce the time needed to produce first drafts of routine teaching materials, such as lesson ' +
    'outlines, practice questions and assessment rubrics.');
  lstLines.Add('');
  lstLines.Add('It can help teachers prepare alternative explanations or activities at different levels of difficult' +
    'y, which may support inclusive teaching when the materials are carefully adapted.');
  lstLines.Add('');
  lstLines.Add('It can support assessment planning by generating draft criteria and questions that the teacher can r' +
    'eview, improve and align with the intended outcomes.');
  lstLines.Add('');
  lstLines.Add('Its main value is teacher support: it can help educators focus more time on professional judgement, ' +
    'classroom interaction and feedback.');
  lstLines.Add('');
  lstLines.Add('Limitations and risks');
  lstLines.Add('');
  lstLines.Add('Its direct effect on learner SDL is indirect when the teacher is the main user. A resource generated' +
    ' by AI does not automatically make learners independent.');
  lstLines.Add('');
  lstLines.Add('Generated questions, examples and rubrics may contain errors or may not align with CAPS terminology,' +
    ' grade expectations or the actual level of the class.');
  lstLines.Add('');
  lstLines.Add('Generic resources may not reflect the language, context, device access or prior knowledge of a parti' +
    'cular South African classroom.');
  lstLines.Add('');
  lstLines.Add('Teachers must check current access arrangements and privacy terms, especially before entering learne' +
    'r information or assessment records.');
  lstLines.Add('');
  lstLines.Add('CAT classroom applications');
  lstLines.Add('');
  lstLines.Add('A CAT teacher can draft spreadsheet exercises on formulas and functions, create differentiated pract' +
    'ice questions, prepare a digital citizenship scenario or develop a rubric for a Word report or Power' +
    'Point presentation. The teacher must check every formula, answer and instruction before distributing' +
    ' the material.');
  lstLines.Add('');
  lstLines.Add('IT classroom applications');
  lstLines.Add('');
  lstLines.Add('An IT teacher can draft programming exercises, project briefs, debugging scenarios and assessment cr' +
    'iteria. Technical examples must be compiled or tested, and rubrics must assess the actual programmin' +
    'g or problem-solving outcomes rather than presentation alone.');
  lstLines.Add('');
  lstLines.Add('Teaching, learning and assessment strategies');
  lstLines.Add('');
  lstLines.Add('Use differentiated instruction, formative assessment, explicit teaching and gradual release. Teacher' +
    's can generate a first draft, moderate it against CAPS and learner needs, pilot the task and revise ' +
    'it using evidence from learner performance.');
  lstLines.Add('');
  lstLines.Add('Self-Directed Learning opportunities');
  lstLines.Add('');
  lstLines.Add('MagicSchool AI supports SDL mainly through teacher-created resources. A well-designed worksheet or s' +
    'elf-check activity can help learners set targets, practise at an appropriate level and assess their ' +
    'progress. Teachers should include answer explanations, reflection questions and clear next steps.');
  lstLines.Add('');
  lstLines.Add('AI integration opportunities');
  lstLines.Add('');
  lstLines.Add('The platform can support professional learning about prompt design, AI-assisted resource creation an' +
    'd teacher responsibility for reviewing outputs. Teachers can compare an AI-generated lesson activity' +
    ' with their own version and identify what needs contextual adaptation.');
  lstLines.Add('');
  lstLines.Add('Authentic classroom activity');
  lstLines.Add('');
  lstLines.Add('Grade 10 CAT differentiated spreadsheet practice: the teacher uses MagicSchool AI to draft three lev' +
    'els of questions on SUM, AVERAGE and COUNTIF. The teacher checks all questions and answers, aligns t' +
    'hem with the lesson objective and prepares a self-check rubric. Learners select a starting level, co' +
    'mplete the task and reflect on whether they are ready for a more challenging problem.');
  lstLines.Add('');
  lstLines.Add('Professional recommendation');
  lstLines.Add('');
  lstLines.Add('Recommended mainly as a teacher productivity and planning assistant. It should not be treated as a r' +
    'eplacement for curriculum knowledge or assessment expertise. Its value depends on careful moderation' +
    ', contextual adaptation and protection of learner information.');
  lstLines.Add('');
  lstLines.Add('3.6 Perplexity AI');
  lstLines.Add('');
  lstLines.Add('Website    https://www.perplexity.ai/');
  lstLines.Add('');
  lstLines.Add('Cost/access    Freemium. Basic search and answer functions may be available at no cost; advanced fe' +
    'atures and higher usage limits may require a paid plan. Access and features should be checked before' +
    ' classroom use.');
  lstLines.Add('');
  lstLines.Add('Overview    Perplexity AI is an AI-supported search and answer tool that combines generated respons' +
    'es with links or references to online sources. It can help learners explore a topic, identify search' +
    ' directions and locate material for further investigation.');
  lstLines.Add('');
  lstLines.Add('Educational purpose    To support research exploration, information literacy, source discovery and ' +
    'critical evaluation of digital information.');
  lstLines.Add('');
  lstLines.Add('Key features    Conversational search; follow-up questions; generated summaries with source links o' +
    'r references; topic exploration; some research, file and advanced functions depending on plan.');
  lstLines.Add('');
  lstLines.Add('Advantages');
  lstLines.Add('');
  lstLines.Add('It can help learners move from a broad topic to more focused research questions and possible search ' +
    'terms.');
  lstLines.Add('');
  lstLines.Add('Source links provide a route to original material, creating an opportunity to teach learners to insp' +
    'ect evidence rather than rely only on a generated summary.');
  lstLines.Add('');
  lstLines.Add('It is relevant to CAT research tasks involving the social implications of technology, digital citize' +
    'nship, privacy and emerging technologies.');
  lstLines.Add('');
  lstLines.Add('It can prompt useful classroom discussion about source credibility, currency, relevance and the diff' +
    'erence between a claim and supporting evidence.');
  lstLines.Add('');
  lstLines.Add('Limitations and risks');
  lstLines.Add('');
  lstLines.Add('Displayed citations do not guarantee that a source exists, is authoritative or directly supports the' +
    ' generated claim. Learners must open and read the source.');
  lstLines.Add('');
  lstLines.Add('Generated summaries may omit context or simplify complex issues. Learners should not cite the AI-gen' +
    'erated summary as if it were the original research.');
  lstLines.Add('');
  lstLines.Add('Search results can vary in quality, currency and relevance. Teachers need to model how to distinguis' +
    'h scholarly, official, commercial and opinion-based sources.');
  lstLines.Add('');
  lstLines.Add('Advanced research functions may require payment, and internet access is essential.');
  lstLines.Add('');
  lstLines.Add('CAT classroom applications');
  lstLines.Add('');
  lstLines.Add('CAT learners can use Perplexity to begin research on the social implications of technology, AI in ed' +
    'ucation, cybersecurity or digital citizenship. They should inspect original sources, record publicat' +
    'ion details and prepare a referenced report using their own synthesis. The teacher can assess the qu' +
    'ality of the sources and the accuracy of the conclusions.');
  lstLines.Add('');
  lstLines.Add('IT classroom applications');
  lstLines.Add('');
  lstLines.Add('IT learners can investigate emerging technologies, cybersecurity concepts, programming tools or tech' +
    'nical standards. They should prioritise official documentation, academic publications and reputable ' +
    'technical sources, then compare claims before applying them to a technical problem.');
  lstLines.Add('');
  lstLines.Add('Teaching, learning and assessment strategies');
  lstLines.Add('');
  lstLines.Add('Use inquiry-based learning, research projects, source evaluation, jigsaw reading and evidence-based ' +
    'writing. A source-evaluation checklist can ask who produced the information, when it was published, ' +
    'what evidence is offered and whether the source supports the claim.');
  lstLines.Add('');
  lstLines.Add('Self-Directed Learning opportunities');
  lstLines.Add('');
  lstLines.Add('Learners can formulate a research question, identify possible sources, follow links, compare evidenc' +
    'e and decide what further information is needed. They can maintain a research log documenting search' +
    ' decisions and changes to their understanding.');
  lstLines.Add('');
  lstLines.Add('AI integration opportunities');
  lstLines.Add('');
  lstLines.Add('The platform is useful for teaching the limits of AI citations. Learners can compare a generated ans' +
    'wer with the linked source, identify unsupported statements and discuss why source verification is e' +
    'ssential in an AI-mediated information environment.');
  lstLines.Add('');
  lstLines.Add('Authentic classroom activity');
  lstLines.Add('');
  lstLines.Add('Grade 12 CAT research task: learners investigate the impact of AI on employment and education. They ' +
    'use Perplexity to identify possible sources, open and evaluate at least three original sources, comp' +
    'are claims and prepare a referenced report. Each learner highlights one claim that the AI answer sim' +
    'plified or misrepresented and explains the correction using evidence.');
  lstLines.Add('');
  lstLines.Add('Professional recommendation');
  lstLines.Add('');
  lstLines.Add('Strongly recommended for guided research and information-literacy activities. Its source links are u' +
    'seful starting points, not a guarantee of truth. Teachers should assess learners’ source evaluation ' +
    'and synthesis rather than the speed with which they obtain an answer.');
  lstLines.Add('');
  lstLines.Add('Comparative analysis and professional recommendations');
  lstLines.Add('');
  lstLines.Add('The six tools serve different purposes and should not be treated as interchangeable. ChatGPT and Gem' +
    'ini are broad conversational assistants that can support explanations, idea development and practice' +
    '. Copilot is especially relevant to productivity tasks in a Microsoft environment. Khanmigo is disti' +
    'nctive for its tutoring-oriented questioning, although its local availability and subject coverage m' +
    'ust be confirmed. MagicSchool AI is most directly useful to teachers preparing resources and assessm' +
    'ent materials. Perplexity is particularly useful for research exploration and information literacy b' +
    'ecause it directs learners towards sources that they must inspect.');
  lstLines.Add('');
  lstLines.Add('Technology    Strongest educational contribution    Best CAT/IT use    Main caution');
  lstLines.Add('');
  lstLines.Add('ChatGPT    Interactive explanations, practice and coding discussion    Spreadsheet explanations; a' +
    'lgorithm comparison; debugging support    Hallucinations and answer-copying');
  lstLines.Add('');
  lstLines.Add('Microsoft Copilot    Productivity support in Microsoft ecosystem    Excel data interpretation; Wor' +
    'd reports; presentations    Licence variation and over-automation');
  lstLines.Add('');
  lstLines.Add('Google Gemini    General exploration and alternative explanations    Technology research; concept ' +
    'explanation; multimodal exploration    Accuracy, account restrictions and privacy');
  lstLines.Add('');
  lstLines.Add('Khanmigo    Guided tutoring and metacognitive questioning    Step-by-step reasoning where relevant' +
    ' content is supported    Regional access and subject coverage');
  lstLines.Add('');
  lstLines.Add('MagicSchool AI    Teacher planning and resource development    Differentiated CAT/IT activities, q' +
    'uestions and rubrics    Teacher moderation and indirect learner benefit');
  lstLines.Add('');
  lstLines.Add('Perplexity AI    Research exploration and source discovery    CAT research reports; IT technical i' +
    'nvestigations    Citations still require verification');
  lstLines.Add('');
  lstLines.Add('Strongest recommendations');
  lstLines.Add('');
  lstLines.Add('For a beginning CAT or IT teacher, ChatGPT is a flexible supplementary assistant for explanation, pr' +
    'actice and problem-solving, provided that learners are required to test and explain outputs. Microso' +
    'ft Copilot is a strong option for CAT when the school already uses Microsoft 365 and the teacher wan' +
    'ts to connect AI literacy with Word, Excel and PowerPoint. Perplexity is particularly valuable for r' +
    'esearch tasks because it creates an opportunity to teach source evaluation. MagicSchool AI is most a' +
    'ppropriate for teacher preparation rather than direct learner tutoring. Gemini can serve as another ' +
    'general-purpose assistant, while Khanmigo should be adopted only after confirming that its access an' +
    'd content are suitable for the South African setting.');
  lstLines.Add('');
  lstLines.Add('4.2 Justification through educational theory');
  lstLines.Add('');
  lstLines.Add('These recommendations are consistent with scaffolding and social constructivist learning. AI can pro' +
    'vide a hint, alternative explanation or prompt, but meaningful learning occurs when learners engage ' +
    'with the task, explain their decisions and apply feedback. They are also consistent with SDL when le' +
    'arners set goals, select resources, monitor their progress and evaluate the result. Formative assess' +
    'ment is strengthened when teachers use evidence from learner work to decide what to reteach or exten' +
    'd. The platform itself does not create learning; the teacher’s instructional design determines wheth' +
    'er its use is educationally worthwhile.');
  lstLines.Add('');
  lstLines.Add('Choosing tools for different classroom contexts');
  lstLines.Add('');
  lstLines.Add('For spreadsheet, word-processing and presentation activities in a Microsoft-based school, consider C' +
    'opilot alongside direct teaching and independent application practice.');
  lstLines.Add('');
  lstLines.Add('For conceptual explanations, practice questions and programming discussions, consider ChatGPT or Gem' +
    'ini, with explicit requirements for verification and explanation.');
  lstLines.Add('');
  lstLines.Add('For research assignments and digital information-literacy lessons, consider Perplexity, but assess o' +
    'riginal source quality and learner synthesis.');
  lstLines.Add('');
  lstLines.Add('For teacher preparation, differentiated worksheets and draft rubrics, consider MagicSchool AI, with ' +
    'careful CAPS moderation.');
  lstLines.Add('');
  lstLines.Add('For tutoring-style practice, consider Khanmigo only when access, age requirements and relevant subje' +
    'ct coverage are confirmed.');
  lstLines.Add('');
  lstLines.Add('Do not require learners to use several AI platforms for the same task. Select the simplest accessibl' +
    'e tool that serves the learning outcome.');
  lstLines.Add('');
  lstLines.Add('Alignment with the CAPS curriculum');
  lstLines.Add('');
  lstLines.Add('Computer Applications Technology');
  lstLines.Add('');
  lstLines.Add('AI can support CAT learning when it is used to deepen, rather than bypass, the practical application' +
    ' of digital skills. In spreadsheets, learners may use AI to clarify the purpose of a function, but t' +
    'hey must construct and test the formula in the spreadsheet application. In word processing and prese' +
    'ntations, AI may support planning or feedback, while learners remain responsible for document struct' +
    'ure, formatting, source acknowledgement and communication. In information management, AI can help le' +
    'arners formulate research questions, but the quality of the final report depends on credible sources' +
    ', accurate referencing and the learner’s own synthesis. In the social implications of technology, AI' +
    ' can provide contrasting scenarios for discussion about privacy, bias, misinformation, employment an' +
    'd digital citizenship.');
  lstLines.Add('');
  lstLines.Add('Information Technology');
  lstLines.Add('');
  lstLines.Add('In IT, AI can support conceptual explanation, algorithm discussion, debugging and technical research' +
    '. However, programming competence requires learners to design, implement, test and explain solutions' +
    '. An AI-generated code fragment should be treated as a hypothesis to investigate, not as a finished ' +
    'answer. Learners should test code with normal, boundary and invalid inputs, explain the logic and id' +
    'entify any errors. For databases, AI may help learners brainstorm entities or query logic, but learn' +
    'ers must justify relationships, data types, keys and query results. These practices maintain the foc' +
    'us on computational thinking and independent problem-solving.');
  lstLines.Add('');
  lstLines.Add('Teaching, learning and assessment strategies');
  lstLines.Add('');
  lstLines.Add('AI should be integrated through a planned sequence rather than introduced as an unrestricted activit' +
    'y. A useful approach is to begin with a clear learning outcome, explain the task and model responsib' +
    'le AI use. Learners then attempt the problem independently or in pairs before using AI for a specifi' +
    'c form of support. They verify the response, apply the learning in the relevant software and explain' +
    ' the decisions they made. The teacher uses the resulting evidence to provide feedback and plan the n' +
    'ext learning step.');
  lstLines.Add('');
  lstLines.Add('Guided inquiry: learners use AI to generate questions or possible explanations, then investigate the' +
    ' issue using practical work and credible sources.');
  lstLines.Add('');
  lstLines.Add('Think-pair-share: learners compare an AI response with a peer’s reasoning and agree on what must be ' +
    'tested or verified.');
  lstLines.Add('');
  lstLines.Add('Problem-based learning: learners use AI as one resource while solving an authentic spreadsheet, data' +
    'base, programming or digital citizenship problem.');
  lstLines.Add('');
  lstLines.Add('Formative assessment: learners submit drafts, tests, prompts and reflections so the teacher can iden' +
    'tify misconceptions and give targeted feedback.');
  lstLines.Add('');
  lstLines.Add('Peer assessment: learners review one another’s AI-supported work against criteria for accuracy, evid' +
    'ence, originality and clarity.');
  lstLines.Add('');
  lstLines.Add('Gradual release: the teacher models a responsible process, supports guided practice and then require' +
    's learners to complete a similar task independently.');
  lstLines.Add('');
  lstLines.Add('Assessment should not rely only on the final written answer or AI-generated product. Stronger eviden' +
    'ce includes the learner’s practical file, working code, test cases, research notes, source evaluatio' +
    'ns, explanation of decisions and ability to complete a similar task without AI assistance. This appr' +
    'oach helps distinguish genuine understanding from work that has merely been generated or copied.');
  lstLines.Add('');
  lstLines.Add('Self-Directed Learning through AI');
  lstLines.Add('');
  lstLines.Add('AI can contribute to SDL when it is used as a resource within a learner-managed process. A learner m' +
    'ay identify a gap in understanding, set a goal, ask a focused question, compare the answer with othe' +
    'r resources, practise the skill and reflect on progress. For example, a learner who struggles with C' +
    'OUNTIF can set a goal to understand the criteria argument, request a simple explanation, practise wi' +
    'th a new dataset and check the result against a teacher-provided success criterion. The learner then' +
    ' records whether they can use the function independently.');
  lstLines.Add('');
  lstLines.Add('Teachers can strengthen SDL by providing a short AI-use learning log. The log may ask learners to re' +
    'cord the task they attempted, the question they asked, the assistance they received, how they checke' +
    'd the answer and what they can now do independently. This makes the learner’s thinking visible and d' +
    'iscourages passive copying. It also helps teachers identify whether the AI tool is supporting unders' +
    'tanding or creating dependency.');
  lstLines.Add('');
  lstLines.Add('Ethical, practical and professional considerations');
  lstLines.Add('');
  lstLines.Add('Accuracy, bias and misinformation');
  lstLines.Add('');
  lstLines.Add('AI-generated information should be treated as provisional. It may contain false facts, biased langua' +
    'ge, outdated information or invented references. Teachers should model verification by checking clai' +
    'ms against textbooks, official documentation, scholarly sources and practical results. In programmin' +
    'g, code must be executed and tested. In spreadsheet work, formulas must be checked against known res' +
    'ults.');
  lstLines.Add('');
  lstLines.Add('Academic integrity and learner responsibility');
  lstLines.Add('');
  lstLines.Add('Schools and teachers should communicate when AI use is permitted, what forms of assistance are accep' +
    'table and how learners should acknowledge that assistance. Learners should not submit generated work' +
    ' as if it were entirely their own. Assessment design can reduce misuse by requiring drafts, process ' +
    'records, oral explanations, practical demonstrations and reflection on AI contributions.');
  lstLines.Add('');
  lstLines.Add('Privacy and data protection');
  lstLines.Add('');
  lstLines.Add('Learners and teachers should not enter personal information, confidential school records, marks, con' +
    'tact details or identifiable learner data into public AI systems unless the school has explicitly ap' +
    'proved the service and data arrangements. Teachers should check account settings, platform terms and' +
    ' institutional policies. Classroom examples should use fictional or anonymised data.');
  lstLines.Add('');
  lstLines.Add('Equity of access in South Africa');
  lstLines.Add('');
  lstLines.Add('Differences in device ownership, connectivity, data affordability and digital confidence may prevent' +
    ' equal participation. Teachers should avoid making paid AI subscriptions a compulsory condition for ' +
    'demonstrating CAPS outcomes. Where access is limited, learners can work in pairs, use a teacher-cont' +
    'rolled demonstration, complete printed prompt-analysis tasks or use offline resources. The learning ' +
    'outcome should remain achievable without requiring every learner to hold a personal subscription.');
  lstLines.Add('');
  lstLines.Add('Teacher professional judgement');
  lstLines.Add('');
  lstLines.Add('AI does not assume responsibility for curriculum alignment, learner wellbeing, assessment fairness o' +
    'r the quality of teaching. Teachers must select appropriate tools, review generated content, explain' +
    ' responsible use and decide when AI is unsuitable. AI should augment professional judgement rather t' +
    'han replace it.');
  lstLines.Add('');
  lstLines.Add('Comparative conclusion and final recommendation');
  lstLines.Add('');
  lstLines.Add('The six technologies offer different forms of support for CAT and IT education. ChatGPT and Gemini c' +
    'an support explanations and exploration; Copilot can connect AI with productivity applications; Khan' +
    'migo can model guided tutoring where its content is available; MagicSchool AI can assist teacher pla' +
    'nning; and Perplexity can support research and source evaluation. Their educational value depends on' +
    ' the learning purpose, accessibility, teacher preparation and the quality of learner engagement.');
  lstLines.Add('');
  lstLines.Add('For South African CAT and IT classrooms, the most defensible approach is selective and purposeful in' +
    'tegration. Teachers should begin with a small number of accessible tools, align activities with CAPS' +
    ' outcomes and provide non-digital alternatives where needed. Learners should be expected to question' +
    ' AI outputs, verify information, protect personal data and demonstrate their own practical competenc' +
    'e. Used in this way, AI can support self-directed learning, critical thinking and future-ready digit' +
    'al skills without replacing the teacher or the learner’s responsibility to think.');
  lstLines.Add('');
end;

procedure AddSection2(lstLines: TStrings);
begin
  lstLines.Add('Chapter 2. Teaching, Assessment and Collaboration Technologies');
  lstLines.Add('');
  lstLines.Add('Introduction');
  lstLines.Add('');
  lstLines.Add('The integration of digital technologies into education has become increasingly important in preparin' +
    'g learners for the demands of the Fourth Industrial Revolution (4IR) and the rapidly evolving digita' +
    'l environment. In Computer Science Education, particularly Computer Applications Technology (CAT) an' +
    'd Information Technology (IT), digital technologies provide opportunities to create learner-centred,' +
    ' interactive and collaborative learning environments. These technologies can transform traditional t' +
    'eaching approaches by enabling learners to participate actively in knowledge construction, develop p' +
    'roblem-solving abilities and take greater responsibility for their learning (Mthembu, 2025; Huang et' +
    ' al., 2024). However, the educational value of technology does not depend simply on its availability' +
    ' but on how effectively teachers integrate it into meaningful pedagogical practices.');
  lstLines.Add('');
  lstLines.Add('Teaching, assessment and collaboration technologies serve different but complementary purposes in th' +
    'e teaching and learning process. Teaching technologies support the presentation of content and organ' +
    'isation of learning activities, while assessment technologies provide opportunities to monitor learn' +
    'er understanding, identify misconceptions and deliver feedback. Collaboration technologies create op' +
    'portunities for learners to exchange ideas, share knowledge and develop solutions collectively. Thes' +
    'e approaches are particularly relevant to CAT and IT, where learners are expected to develop both th' +
    'eoretical knowledge and practical digital competencies. Tomasik et al. (2018) highlight the value of' +
    ' computer-based formative assessment in providing information that can support teaching decisions an' +
    'd improve learner understanding. Similarly, Van Zyl and Bailey (2025) demonstrate the potential of t' +
    'echnology-supported cooperative learning to promote deeper self-directed learning in Computer Scienc' +
    'e Education.');
  lstLines.Add('');
  lstLines.Add('The pedagogical integration of these technologies can also be understood through social constructivi' +
    'st learning principles, which emphasize the importance of interaction, collaboration and active part' +
    'icipation in the construction of knowledge. Through structured digital activities, learners can disc' +
    'uss problems, compare different approaches, provide peer feedback and develop a deeper understanding' +
    ' of concepts. Technology-supported assessment can contribute to Self-Directed Learning (SDL) by prov' +
    'iding opportunities for learners to assess their understanding, identify learning gaps, set personal' +
    ' learning goals and monitor their progress. Nevertheless, access to digital platforms alone does not' +
    ' guarantee learner independence. Teachers must provide appropriate scaffolding, clear learning objec' +
    'tives and constructive feedback while gradually encouraging learners to take greater responsibility ' +
    'for managing their own learning (Van Zyl & Bailey, 2025).');
  lstLines.Add('');
  lstLines.Add('The integration of these technologies is also important in developing future-ready skills required i' +
    'n contemporary educational and workplace environments. Skills such as digital literacy, critical thi' +
    'nking, communication, collaboration, creativity and problem-solving can be developed through meaning' +
    'ful technology-supported learning activities. In CAT, learners can apply these skills when working w' +
    'ith spreadsheets, databases, networks and digital citizenship activities. In IT, learners can develo' +
    'p similar competencies through programming, algorithm development, database design and problem-solvi' +
    'ng tasks. The selection and implementation of digital technologies should therefore be guided by the' +
    ' Curriculum and Assessment Policy Statement (CAPS) requirements, ensuring that technology-supported ' +
    'activities contribute to the intended subject knowledge, practical competencies and assessment outco' +
    'mes rather than becoming activities focused only on entertainment or participation.');
  lstLines.Add('');
  lstLines.Add('This assignment critically examines six digital technologies that can support teaching, assessment a' +
    'nd collaboration in CAT and IT classrooms: Microsoft Teams, Google Classroom, Kahoot!, Wayground (fo' +
    'rmerly Quizizz), Mentimeter and Padlet. The technologies are evaluated according to their educationa' +
    'l purposes, key features, advantages, limitations and potential classroom applications. Particular a' +
    'ttention is given to how each platform can support Self-Directed Learning, collaborative knowledge c' +
    'onstruction, formative assessment and the development of future-ready skills. The discussion also co' +
    'nsiders the pedagogical conditions required for their effective implementation, recognizing that dif' +
    'ferent technologies serve different learning purposes and should be selected according to the intend' +
    'ed learning outcomes.');
  lstLines.Add('');
  lstLines.Add('Despite their educational potential, the successful integration of digital technologies in South Afr' +
    'ican classrooms is influenced by practical challenges, including internet connectivity, data costs, ' +
    'access to digital devices and teachers'' technological competencies. Padayachee (2017) highlights con' +
    'tinuing challenges associated with ICT integration in South African schools. These challenges demons' +
    'trate the importance of selecting technologies that are appropriate to the educational context and p' +
    'roviding alternative learning opportunities for learners with limited digital access. Consequently, ' +
    'this assignment does not assume that technology automatically improves educational outcomes. Instead' +
    ', it critically considers how the selected technologies can be integrated with sound pedagogical pri' +
    'nciples, curriculum requirements and inclusive teaching practices to promote meaningful learning in ' +
    'CAT and IT education.');
  lstLines.Add('');
  lstLines.Add('Microsoft Teams');
  lstLines.Add('');
  lstLines.Add('Website    https://teams.live.com/free');
  lstLines.Add('');
  lstLines.Add('Cost/access    Free access to Teams for Education is advertised for eligible users with a valid, ac' +
    'tive school email address; additional Microsoft 365 education services and institutional licensing m' +
    'ay depend on the school’s eligibility and plan.');
  lstLines.Add('');
  lstLines.Add('Overview    Microsoft Teams for Education is a communication and collaboration environment that bri' +
    'ngs together class teams, chat, video meetings, shared files, assignments and class materials. It ca' +
    'n provide a central digital space in which teachers and learners communicate and access learning res' +
    'ources.');
  lstLines.Add('');
  lstLines.Add('Educational purpose    To support communication, blended learning, group collaboration, resource sh' +
    'aring and the organization of learning activities. It can be useful when a class needs a structured ' +
    'space to continue practical work, ask questions and submit evidence of learning.');
  lstLines.Add('');
  lstLines.Add('Key features    Class teams and channels; announcements and chat; video meetings; file sharing; col' +
    'laborative work with Microsoft 365 applications; assignment and class-material functions where enabl' +
    'ed by the school’s account. Feature availability is affected by the school’s licence and configurati' +
    'on.');
  lstLines.Add('');
  lstLines.Add('Advantages');
  lstLines.Add('');
  lstLines.Add('Microsoft Teams can bring communication, resource sharing and collaborative work into one digital en' +
    'vironment. Channels can organize learning by topic or project, while shared files and documents allo' +
    'w learners to contribute to a common task. This can reduce fragmentation when teachers already use M' +
    'icrosoft 365. Its educational value, however, lies not in the number of features but in whether the ' +
    'teacher uses the platform to support purposeful interaction, feedback and access to learning materia' +
    'ls. For example, a channel dedicated to a spreadsheet task can preserve instructions, worked example' +
    's, learner questions and feedback in one place. This can help learners revisit explanations and cont' +
    'inue learning beyond the face-to-face lesson.');
  lstLines.Add('');
  lstLines.Add('Limitations and risks');
  lstLines.Add('');
  lstLines.Add('Teams requires suitable devices, reliable connectivity and sufficient teacher and learner familiarit' +
    'y. Notifications and numerous channels can distract learners if the platform is not organized carefu' +
    'lly. Some education features depend on institutional accounts, licenses and administrator settings, ' +
    'so teachers should confirm availability before planning an activity. Online collaboration also creat' +
    'es responsibilities relating to respectful communication, file permissions and the protection of per' +
    'sonal information. In schools with limited connectivity or no suitable accounts, Teams may be imprac' +
    'tical as the main learning platform. A printed task, shared offline file or teacher-led alternative ' +
    'should be available so that the curriculum outcome remains accessible.');
  lstLines.Add('');
  lstLines.Add('CAT and IT classroom applications');
  lstLines.Add('');
  lstLines.Add('In CAT, a teacher can create a channel for spreadsheet activities and share an Excel practice file. ' +
    'Learners can work in pairs to develop formulas, post screenshots of results and ask questions about ' +
    'errors such as incorrect cell references. A separate channel can be used for digital citizenship dis' +
    'cussions or for sharing research on the social implications of technology. In IT, learners can use a' +
    ' project channel to plan a small programming or database task. They can share design documents, disc' +
    'uss errors, divide responsibilities, and present progress during a group meeting. The teacher can pr' +
    'ovide a common location for project instructions, milestones and feedback.');
  lstLines.Add('');
  lstLines.Add('Teaching, learning and assessment strategies');
  lstLines.Add('');
  lstLines.Add('Teams can support direct instruction through shared resources, collaborative learning through group ' +
    'tasks, peer feedback through shared documents and formative assessment through questioning and revie' +
    'w of submitted work. A teacher should establish clear roles and individual evidence requirements so ' +
    'that group participation is visible. Assessment should focus on the quality of the work and learning' +
    ' evidence, not simply on online activity.');
  lstLines.Add('');
  lstLines.Add('Self-Directed Learning opportunities');
  lstLines.Add('');
  lstLines.Add('Teams can support SDL when learners use posted resources, task instructions, milestones and feedback' +
    ' to plan and monitor their work. A project channel can include a progress checklist and reflection p' +
    'rompts such as: What can I complete independently? Which concept do I still find difficult? What res' +
    'ource or strategy will I use next? Learners can revisit explanations, compare their work with succes' +
    's criteria and request help when needed. These activities support planning, monitoring and reflectio' +
    'n, but the platform itself does not guarantee autonomy. Teachers should initially model how to plan ' +
    'a task and use feedback, then gradually reduce prompts as learners become more confident in managing' +
    ' their work.');
  lstLines.Add('');
  lstLines.Add('AI integration opportunities');
  lstLines.Add('');
  lstLines.Add('Where enabled by the school’s Microsoft 365 licence, AI-supported tools may help teachers prepare dr' +
    'aft explanations, generate differentiated question ideas or support learners with planning and langu' +
    'age. AI outputs must be checked for accuracy, curriculum alignment and age appropriateness. Learners' +
    ' should disclose AI assistance where required and must not upload confidential learner information o' +
    'r personal data into public AI systems. AI is an optional enhancement, not a necessary condition for' +
    ' using Teams.');
  lstLines.Add('');
  lstLines.Add('Authentic classroom activity');
  lstLines.Add('');
  lstLines.Add('The teacher posts a workbook containing a small-business sales dataset and instructions to calculate' +
    ' totals, averages, and counts. Pairs discuss which function is appropriate, complete the workbook, a' +
    'nd upload evidence of their results with a brief explanation. The teacher uses common errors to plan' +
    ' further instruction. Each learner then answers an individual exit question explaining the differenc' +
    'e between a formula and a function. This activity promotes practical spreadsheet skills, communicati' +
    'on, collaborative problem-solving and individual accountability. It also provides evidence of whethe' +
    'r learners can independently explain and apply the concepts.');
  lstLines.Add('');
  lstLines.Add('Professional recommendation');
  lstLines.Add('');
  lstLines.Add('Microsoft Teams is recommended for schools that already use Microsoft 365 and can provide appropriat' +
    'e accounts, devices and connectivity. Its strongest contribution is the integration of communication' +
    ', resources and collaborative work. It is less suitable as the sole learning solution where learners' +
    ' cannot access the internet or where the school lacks the necessary account infrastructure. Teachers' +
    ' should begin with a small number of channels and explicit communication rules.');
  lstLines.Add('');
  lstLines.Add('Google Classroom');
  lstLines.Add('');
  lstLines.Add('Website    https://edu.google.com/intl/ALL_za/workspace-for-education/products/classroom/');
  lstLines.Add('');
  lstLines.Add('Cost/access    Google Workspace for Education Fundamentals is available at no cost to qualifying ed' +
    'ucational institutions. Other editions and enhanced features may be paid or institution-dependent; s' +
    'chools should verify eligibility and edition features.');
  lstLines.Add('');
  lstLines.Add('Overview    Google Classroom is a learning management platform that helps teachers create classes, ' +
    'distribute learning materials, assign work, collect submissions, provide feedback and organise class' +
    ' communication. It connects with Google tools such as Docs, Drive, Forms and Calendar.');
  lstLines.Add('');
  lstLines.Add('Educational purpose    To organise classroom learning and make the assignment cycle more manageable' +
    ': communicate the task, provide resources, receive learner work, return feedback and monitor complet' +
    'ion.');
  lstLines.Add('');
  lstLines.Add('Key features    Class creation and enrolment; announcements; assignments and due dates; attaching d' +
    'ocuments, videos and Forms; learner submissions; grading and feedback; integration with Google Drive' +
    ' and other Workspace tools. Some advanced functions depend on the institution’s edition.');
  lstLines.Add('');
  lstLines.Add('Advantages');
  lstLines.Add('');
  lstLines.Add('Teachers can post lecture notes, create assignments, make announcements, and set due dates for assig' +
    'nments (Iftakhar, 2016). Teachers can create different groups within one classroom and assign each g' +
    'roup a different assignment, making the class active and interesting. Teachers can easily identify s' +
    'tudents who miss class assignments and those who submit their assignments late. It is flexible, enab' +
    'ling teachers to extend due dates so that all students can submit their assignments, and it also all' +
    'ows teachers to update or review students’ grades. Previous posts made by teachers can be reused and' +
    ' posted to the same group or to a different group. Teachers can also be added to the classroom, and ' +
    'they can grade students’ assignments (Hussaini, 2020).');
  lstLines.Add('');
  lstLines.Add('Limitations and risks');
  lstLines.Add('');
  lstLines.Add('Google Classroom is not a substitute for teaching or a carefully sequenced curriculum. Learners need' +
    ' suitable devices, accounts and connectivity, and teachers may need to provide support with file man' +
    'agement and digital submission. Features such as advanced grading, originality checking and analytic' +
    's vary by edition and institutional configuration. Clear file-naming conventions, submission instruc' +
    'tions and deadlines are necessary. Teachers should also avoid making access to a particular device o' +
    'r paid application a hidden requirement where the same CAPS outcome can be demonstrated through an a' +
    'ccessible alternative.');
  lstLines.Add('');
  lstLines.Add('CAT and IT classroom applications');
  lstLines.Add('');
  lstLines.Add('In CAT, a teacher can post a spreadsheet assignment with a dataset, instructions and a marking rubri' +
    'c. Learners can complete the task in a spreadsheet application, submit the workbook and explain sele' +
    'cted formula choices. A short quiz can check understanding of spreadsheet functions or safe internet' +
    ' practices. In IT, the teacher can distribute programming exercises, database design briefs or resea' +
    'rch tasks and collect code files, flowcharts, screenshots and written explanations. Discussion promp' +
    'ts can ask learners to compare alternative solutions and justify which is more appropriate. These ta' +
    'sks connect digital assignment management to practical subject learning.');
  lstLines.Add('');
  lstLines.Add('Teaching, learning and assessment strategies');
  lstLines.Add('');
  lstLines.Add('Classroom can support diagnostic assessment through an initial quiz, formative assessment through dr' +
    'afts and feedback, and summative assessment through structured tasks where appropriate. Rubrics and ' +
    'success criteria should make expectations transparent before learners begin. Feedback should identif' +
    'y what has been achieved, what needs improvement and what the learner can do next. Peer review can b' +
    'e included when learners are taught to give specific, respectful comments linked to criteria. The te' +
    'acher should combine digital submissions with observation and practical evidence, particularly where' +
    ' the learning outcome involves operating software or developing a working solution.');
  lstLines.Add('');
  lstLines.Add('Self-Directed Learning opportunities');
  lstLines.Add('');
  lstLines.Add('Learners can use Classroom to revisit instructions, access resources, track outstanding tasks and ap' +
    'ply returned comments to later submissions. Teachers can divide a larger task into milestones so tha' +
    't learners monitor progress rather than completing the work at the last moment. To develop autonomy,' +
    ' learners can set a target before beginning, check their work against a rubric and write a brief ref' +
    'lection after submission. For example, a learner may identify formula accuracy as a personal improve' +
    'ment goal and use feedback to correct errors in a later spreadsheet task. This approach makes learne' +
    'r responsibility explicit while retaining teacher guidance.');
  lstLines.Add('');
  lstLines.Add('AI integration opportunities');
  lstLines.Add('');
  lstLines.Add('Google Workspace for Education includes AI-enabled features in some editions and settings, but acces' +
    's is not identical across all accounts. Where available and permitted, AI can help teachers draft le' +
    'sson resources, question prompts or study guides. Any AI-generated content should be checked for cor' +
    'rectness, bias and alignment with the CAPS curriculum. Learners should be taught to acknowledge AI a' +
    'ssistance and verify information rather than copying generated responses.');
  lstLines.Add('');
  lstLines.Add('Authentic classroom activity');
  lstLines.Add('');
  lstLines.Add('Grade 10 CAT task: The teacher creates a Classroom assignment called ''Spreadsheet Functions in a Sma' +
    'll Business''. Learners download a dataset, calculate total sales using SUM, find the average using A' +
    'VERAGE and count entries using COUNT or COUNTA. They submit the completed workbook and a short expla' +
    'nation of two decisions they made. The teacher uses a rubric to assess accuracy, presentation and ex' +
    'planation, then returns targeted feedback.');
  lstLines.Add('');
  lstLines.Add('Professional recommendation');
  lstLines.Add('');
  lstLines.Add('Google Classroom is recommended where the school has access to Google Workspace for Education and te' +
    'achers need a straightforward way to manage resources, assignments and feedback. It is particularly ' +
    'useful for structured coursework and ongoing assessment. It should be combined with direct teaching ' +
    'and practical classroom support, and a non-digital alternative should be available when learners can' +
    'not reliably connect.');
  lstLines.Add('');
  lstLines.Add('Kahoot!');
  lstLines.Add('');
  lstLines.Add('Website    https://kahoot.com/schools/');
  lstLines.Add('');
  lstLines.Add('Cost/access    Freemium. Kahoot! offers a free entry-level option, while premium plans provide addi' +
    'tional question types, content and larger participant limits. The free live participant limit varies' +
    ' by account type; verify the current limit before a class session.');
  lstLines.Add('');
  lstLines.Add('Overview    Kahoot! is a game-based learning and assessment platform in which teachers create or se' +
    'lect quizzes and learners respond using their own devices or shared devices. Questions are commonly ' +
    'displayed on a main screen, while learners submit answers through a browser or app.');
  lstLines.Add('');
  lstLines.Add('Educational purpose    To make revision and formative assessment interactive, encourage participati' +
    'on and provide teachers with a quick indication of which concepts learners understand and which requ' +
    'ire reteaching.');
  lstLines.Add('');
  lstLines.Add('Key features    Quiz creation; multiple-choice questions and other supported question formats depen' +
    'ding on plan; live games; challenge or self-paced modes; game PIN joining; results and reports. Part' +
    'icipants can generally join a hosted game without creating an account, subject to the platform’s cur' +
    'rent rules.');
  lstLines.Add('');
  lstLines.Add('Advantages');
  lstLines.Add('');
  lstLines.Add('Kahoot! can create an energetic revision activity and make it easier for teachers to gather response' +
    's from many learners in a short period. The game format may increase participation and provide immed' +
    'iate feedback.');
  lstLines.Add('');
  lstLines.Add('Limitations and risks');
  lstLines.Add('');
  lstLines.Add('Competition and speed-based scoring may disadvantage learners who read more slowly, have limited dev' +
    'ice access or feel anxious about public rankings. Learners may guess quickly rather than explain the' +
    'ir thinking. Connectivity problems can interrupt the activity, and free-plan participant limits can ' +
    'restrict use with larger classes. The teacher should avoid treating a Kahoot! score as sufficient ev' +
    'idence of deep understanding.');
  lstLines.Add('');
  lstLines.Add('CAT and IT classroom applications');
  lstLines.Add('');
  lstLines.Add('In CAT, Kahoot! can review spreadsheet vocabulary, formula syntax, network devices, file management,' +
    ' digital citizenship and the differences between COUNT, COUNTA and COUNTBLANK. Questions can include' +
    ' short scenarios that ask learners to select the most appropriate function or safe online behaviour.' +
    ' In IT, Kahoot! can be used to revise programming concepts, data types, flowchart symbols, database ' +
    'terminology, algorithms and cybersecurity principles. Teachers can include code snippets or diagrams' +
    ' where the question format supports them, then discuss why the correct answer is appropriate.');
  lstLines.Add('');
  lstLines.Add('Teaching, learning and assessment strategies');
  lstLines.Add('');
  lstLines.Add('Kahoot! is most appropriate as a formative check, retrieval-practice activity or lesson starter/clos' +
    'er. Teachers should pause after selected questions to ask learners to justify answers and explain mi' +
    'sconceptions. A balanced approach includes untimed discussion questions and written explanations so ' +
    'that assessment does not reward speed alone.');
  lstLines.Add('');
  lstLines.Add('Self-Directed Learning opportunities');
  lstLines.Add('');
  lstLines.Add('Kahoot! can promote Self-Directed Learning by allowing learners to take an active role in identifyin' +
    'g their knowledge gaps and improving their understanding. Through individual challenges, learners ca' +
    'n assess their own knowledge, monitor their performance and recognise areas that require further att' +
    'ention. The immediate feedback provided after answering questions helps learners understand their mi' +
    'stakes and make informed decisions about what they need to revise. Learners can also take responsibi' +
    'lity for setting personal learning goals, practising difficult concepts and evaluating their progres' +
    's. For example, in a CAT lesson on spreadsheet functions, learners who struggle with COUNTIF or SUMI' +
    'F can identify these weaknesses through their quiz results and independently practise the relevant f' +
    'unctions until they improve their understanding.');
  lstLines.Add('');
  lstLines.Add('AI integration opportunities');
  lstLines.Add('');
  lstLines.Add('AI-supported question-generation features may be available in certain Kahoot! plans or workflows. Te' +
    'achers may use AI to draft question ideas from a topic outline, but they must check that answers are' +
    ' accurate, unambiguous and appropriate for the learners’ grade. AI should not be used to create ques' +
    'tions that expose learner personal information or reproduce copyrighted material without permission.');
  lstLines.Add('');
  lstLines.Add('Authentic classroom activity');
  lstLines.Add('');
  lstLines.Add('Grade 10 CAT revision: At the end of a lesson on spreadsheet functions, the teacher runs a short Kah' +
    'oot! containing questions about SUM, AVERAGE, COUNT, COUNTA and COUNTBLANK. After each question, lea' +
    'rners discuss the reason for the correct answer. The teacher notes the questions with the highest er' +
    'ror rates and reteaches those concepts using a worked spreadsheet example.');
  lstLines.Add('');
  lstLines.Add('Professional recommendation');
  lstLines.Add('');
  lstLines.Add('Kahoot! is recommended as a supplementary formative assessment tool, particularly for revision and c' +
    'hecking prior knowledge. It should not replace practical spreadsheet, database or programming tasks,' +
    ' nor should its leaderboard be used as the only measure of learner ability. For inclusive use, teach' +
    'ers should provide adequate response time, avoid excessive competition and prepare a paper-based or ' +
    'oral alternative if devices or connectivity fail.');
  lstLines.Add('');
  lstLines.Add('Wayground (formerly Quizizz)');
  lstLines.Add('');
  lstLines.Add('Website    https://wayground.com/');
  lstLines.Add('');
  lstLines.Add('Cost/access    Freemium. The Starter (Basic) plan is free and provides essential activity creation ' +
    'and delivery features, with limits on storage, question types and participant numbers. The platform’' +
    's published plan information indicates up to 100 participants per session on Starter, but regional a' +
    'vailability and features may differ.');
  lstLines.Add('');
  lstLines.Add('Overview    Wayground, formerly known as Quizizz, is an AI-supported instructional and assessment p' +
    'latform for creating quizzes, lessons, flashcards, interactive videos and other learning activities.' +
    ' Teachers can deliver activities live or assign them for independent completion.');
  lstLines.Add('');
  lstLines.Add('Educational purpose    To support formative assessment, independent practice, differentiated learni' +
    'ng and feedback through interactive learning resources that can be completed during or outside lesso' +
    'n time.');
  lstLines.Add('');
  lstLines.Add('Key features    Creation and delivery of assessments/quizzes; lessons; flashcards; interactive vide' +
    'os and passages; multiple question types; live or assigned activities; learner performance reports. ' +
    'The range of tools and question types depends on the account plan and region.');
  lstLines.Add('');
  lstLines.Add('Advantages');
  lstLines.Add('');
  lstLines.Add('Wayground offers more than a simple live quiz: teachers can combine instruction, practice and assess' +
    'ment. Self-paced assignments can accommodate different working speeds, while reports can help teache' +
    'rs identify topics that require further explanation. The platform’s Starter plan provides basic acti' +
    'vity creation and delivery, although advanced features are plan-dependent (Wayground, 2026a; Waygrou' +
    'nd, 2026b).');
  lstLines.Add('');
  lstLines.Add('Limitations and risks');
  lstLines.Add('');
  lstLines.Add('The free plan has limits and may not include every question type, premium library resource or advanc' +
    'ed reporting function. Learners still need access to a suitable device and connectivity. Game-like f' +
    'eatures can distract from the learning objective if overused. Teachers should also review automatica' +
    'lly generated questions and ensure that the content matches the level and terminology used in the cu' +
    'rriculum.');
  lstLines.Add('');
  lstLines.Add('CAT classroom applications');
  lstLines.Add('');
  lstLines.Add('In CAT, a teacher can assign a self-paced activity on spreadsheet functions, file formats, network c' +
    'oncepts or the social implications of ICT. Learners can complete questions at their own pace and use' +
    ' the feedback to revisit topics. A teacher can use the report to identify which spreadsheet function' +
    ' requires further practice.');
  lstLines.Add('');
  lstLines.Add('IT classroom applications');
  lstLines.Add('');
  lstLines.Add('In IT, learners can practise programming logic, algorithms, database concepts, hardware and software' +
    ' terminology or cybersecurity. Interactive videos can be used to pause a demonstration and ask learn' +
    'ers to predict what a code segment or system process will do.');
  lstLines.Add('');
  lstLines.Add('Teaching, learning and assessment strategies');
  lstLines.Add('');
  lstLines.Add('Wayground can support diagnostic assessment before a topic, formative checks during instruction and ' +
    'revision after a topic. Teachers should use reports as one source of evidence alongside practical wo' +
    'rk, observation and learner explanations. Differentiated tasks can be created at different levels, b' +
    'ut learners should still work towards common curriculum outcomes.');
  lstLines.Add('');
  lstLines.Add('Self-Directed Learning opportunities');
  lstLines.Add('');
  lstLines.Add('Self-paced activities allow learners to practise, receive feedback and repeat concepts. Teachers can' +
    ' assign a revision pathway and ask learners to select the topic they need to strengthen. Learners ca' +
    'n monitor their own progress through results and reflect on errors. This promotes autonomy when lear' +
    'ners are taught how to interpret feedback and choose an appropriate next step.');
  lstLines.Add('');
  lstLines.Add('AI integration opportunities');
  lstLines.Add('');
  lstLines.Add('Wayground describes itself as an AI-supported platform and offers AI-related creation and instructio' +
    'nal functions, subject to plan and regional availability. Teachers may use such functions to draft q' +
    'uestions or adapt learning materials, but must review all generated content for accuracy, bias, lang' +
    'uage level and alignment with CAT or IT outcomes. Learners should be guided to use AI as a source of' +
    ' practice and feedback, not as a replacement for independent reasoning.');
  lstLines.Add('');
  lstLines.Add('Authentic classroom activity');
  lstLines.Add('');
  lstLines.Add('Grade 10 CAT differentiated practice: After teaching COUNT, COUNTA and COUNTBLANK, the teacher assig' +
    'ns a Wayground activity with three levels. The first level asks learners to identify what each funct' +
    'ion counts; the second requires selecting a function for a scenario; the third asks learners to inte' +
    'rpret a small dataset and justify the best function. Learners complete the activity independently, a' +
    'nd the teacher reviews the results to plan a follow-up lesson.');
  lstLines.Add('');
  lstLines.Add('Professional recommendation');
  lstLines.Add('');
  lstLines.Add('Wayground is recommended when teachers want more flexible practice and assessment than a short live ' +
    'quiz can provide. It is particularly useful for revision and self-paced learning. Its value depends ' +
    'on careful teacher review of content, sensible use of reports and realistic planning for the free-pl' +
    'an limits and connectivity needs.');
  lstLines.Add('');
  lstLines.Add('Mentimeter');
  lstLines.Add('');
  lstLines.Add('Website    https://www.mentimeter.com/');
  lstLines.Add('');
  lstLines.Add('Cost/access    Freemium. The free account allows unlimited presentations and many question types bu' +
    't is limited to 50 participants per month for live presentations. Paid plans provide higher or unlim' +
    'ited audience capacity and additional features; check current terms.');
  lstLines.Add('');
  lstLines.Add('Overview    Mentimeter is an interactive presentation platform that allows presenters to gather aud' +
    'ience responses through polls, word clouds, quizzes, scales and question slides. Learners use a code' +
    ' or link to respond, and results can be displayed during the lesson.');
  lstLines.Add('');
  lstLines.Add('Educational purpose    To increase learner voice and participation, activate prior knowledge, gathe' +
    'r opinions, check understanding and encourage reflection during presentations.');
  lstLines.Add('');
  lstLines.Add('Key features    Interactive polls; word clouds; quiz slides; scales and question slides; live respo' +
    'nse visualisation; presentation content slides. The free plan supports unlimited presentations but h' +
    'as a monthly live participant limit of 50.');
  lstLines.Add('');
  lstLines.Add('Advantages');
  lstLines.Add('');
  lstLines.Add('Mentimeter can make a presentation more interactive and give teachers a quick picture of learner thi' +
    'nking. Anonymous or low-pressure responses may encourage participation from learners who are relucta' +
    'nt to speak publicly. Word clouds can reveal prior knowledge and misconceptions, while polls can hel' +
    'p a teacher decide whether to move on or explain a concept again.');
  lstLines.Add('');
  lstLines.Add('Limitations and risks');
  lstLines.Add('');
  lstLines.Add('The free plan’s 50-participant monthly limit can be restrictive for frequent use or large classes. I' +
    't also depends on learners having access to devices and connectivity. Responses may show opinions or' +
    ' recognition rather than deep understanding, so teachers need follow-up questions and practical task' +
    's. Anonymity can encourage honest participation but may make it harder to identify individual suppor' +
    't needs.');
  lstLines.Add('');
  lstLines.Add('CAT classroom applications');
  lstLines.Add('');
  lstLines.Add('In CAT, a teacher can use a word cloud to ask learners what they associate with digital citizenship,' +
    ' cybersecurity or spreadsheet functions. A poll can ask which function learners find most difficult,' +
    ' helping the teacher decide which concept to revisit.');
  lstLines.Add('');
  lstLines.Add('IT classroom applications');
  lstLines.Add('');
  lstLines.Add('In IT, Mentimeter can be used to gather predictions about how an algorithm will behave, compare data' +
    'base design choices or identify learners’ prior understanding of programming concepts. A scale quest' +
    'ion can ask learners to rate their confidence before and after a lesson.');
  lstLines.Add('');
  lstLines.Add('Teaching, learning and assessment strategies');
  lstLines.Add('');
  lstLines.Add('Mentimeter is useful for activating prior knowledge, formative questioning, checking confidence and ' +
    'facilitating discussion. Teachers should not equate a high response rate with mastery. After display' +
    'ing results, ask learners to explain their reasoning, compare viewpoints and apply the concept in a ' +
    'practical task.');
  lstLines.Add('');
  lstLines.Add('Self-Directed Learning opportunities');
  lstLines.Add('');
  lstLines.Add('Mentimeter can promote Self-Directed Learning by encouraging learners to reflect on their understand' +
    'ing, assess their knowledge and take responsibility for identifying their learning needs. Through in' +
    'teractive polls, quizzes, word clouds and open-ended questions, learners can express what they under' +
    'stand, identify concepts they find challenging and ask questions about areas that require further ex' +
    'planation. For example, in a CAT lesson on spreadsheet functions, learners can use a confidence-scal' +
    'e poll to indicate how confident they are in applying functions such as SUM, AVERAGE and COUNTIF. Ba' +
    'sed on their responses, learners can identify which functions they need to practise further and enga' +
    'ge in independent revision. This encourages self-assessment, reflection, goal-setting and active par' +
    'ticipation in managing their own learning.');
  lstLines.Add('');
  lstLines.Add('AI integration opportunities');
  lstLines.Add('');
  lstLines.Add('AI may be used by the teacher outside the platform to draft poll questions, create discussion prompt' +
    's or suggest misconceptions to probe. Any AI-generated prompts should be checked for bias, clarity a' +
    'nd age appropriateness. Where AI features are available in a particular account or integration, teac' +
    'hers should verify their availability and data terms rather than assume that all free users have acc' +
    'ess.');
  lstLines.Add('');
  lstLines.Add('Authentic classroom activity');
  lstLines.Add('');
  lstLines.Add('Grade 10 CAT lesson introduction: Before teaching spreadsheet functions, the teacher asks learners t' +
    'o submit a word cloud answering ''What can a spreadsheet help a small business do?'' The teacher then ' +
    'runs a poll on which function learners already know. Responses guide the introduction. At the end, l' +
    'earners rate their confidence and submit one question about a function they still find difficult.');
  lstLines.Add('');
  lstLines.Add('Professional recommendation');
  lstLines.Add('');
  lstLines.Add('Mentimeter is recommended for short interactive moments within a lesson, especially when the teacher' +
    ' wants to hear from a broad range of learners. It is not a full learning management system or a repl' +
    'acement for formal assessment. Its participant limit and connectivity requirements should be conside' +
    'red, and teachers can use show-of-hands, paper cards or group responses as alternatives.');
  lstLines.Add('');
  lstLines.Add('Padlet');
  lstLines.Add('');
  lstLines.Add('Website    https://padlet.com/');
  lstLines.Add('');
  lstLines.Add('Cost/access    Freemium. The free plan currently allows up to three Padlets, with a 20 MB file uplo' +
    'ad limit and limits on audio and video recording duration. Paid classroom and school plans provide a' +
    'dditional capacity and management features.');
  lstLines.Add('');
  lstLines.Add('Overview    Padlet is a digital noticeboard and collaborative workspace where users can post text, ' +
    'links, images, files, audio and video in a shared space. Boards can be organised in different layout' +
    's, such as wall, grid, columns or timeline.');
  lstLines.Add('');
  lstLines.Add('Educational purpose    To support collaborative knowledge construction, brainstorming, sharing reso' +
    'urces, peer feedback, project planning and the presentation of learner-created work.');
  lstLines.Add('');
  lstLines.Add('Key features    Shared boards; text and multimedia posts; comments and reactions; different layouts' +
    '; links and file attachments; real-time collaboration; slideshow presentation from board content. Th' +
    'e free plan is limited to three active Padlets and has file-size and media-duration limits.');
  lstLines.Add('');
  lstLines.Add('Advantages');
  lstLines.Add('');
  lstLines.Add('Padlet offers several advantages for teaching and learning because it provides an interactive and co' +
    'llaborative online environment where learners and teachers can share information in different format' +
    's (Deni, 2018). One of its main advantages is that it allows multiple users to contribute to the sam' +
    'e virtual wall simultaneously, promoting teamwork, communication and the exchange of ideas. Learners' +
    ' can upload documents, images, videos, audio recordings and links, making learning more engaging and' +
    ' accommodating different ways of presenting information. The real-time display of posts enables lear' +
    'ners to view one another''s contributions immediately, encouraging discussion, peer learning and cons' +
    'tructive feedback. Also, teachers have control over the design, layout and privacy settings of their' +
    ' walls, allowing them to create an organised and secure learning space that suits the needs of their' +
    ' classroom (Deni, 2018). The ability to moderate posts also helps teachers maintain appropriate cont' +
    'ent and encourage responsible digital participation. Padlet can therefore support learner-centred te' +
    'aching by giving learners opportunities to actively participate, express their understanding, share ' +
    'resources and learn from their classmates. In CAT and IT classrooms, it can be particularly useful f' +
    'or collaborative projects, brainstorming, sharing practical work and discussing solutions to problem' +
    's.');
  lstLines.Add('');
  lstLines.Add('Limitations and risks');
  lstLines.Add('');
  lstLines.Add('The free plan allows only three Padlets, which may be insufficient for teachers who need separate bo' +
    'ards for many classes or topics. Learners need devices and connectivity to contribute in real time. ' +
    'Boards can become disorganised or contain irrelevant posts unless teachers provide clear headings, p' +
    'osting rules and moderation. Teachers must manage permissions carefully and avoid sharing sensitive ' +
    'learner information.');
  lstLines.Add('');
  lstLines.Add('CAT and IT classroom applications');
  lstLines.Add('');
  lstLines.Add('In CAT, groups can use a Padlet board to compare spreadsheet solutions, post screenshots of charts, ' +
    'share safe internet-use recommendations or build a glossary of technology terms. A teacher can creat' +
    'e columns for ''What we know'', ''Questions'', ''Examples'' and ''Further research''. In IT, learners can co' +
    'llaboratively map stages of the software development life cycle, share flowchart drafts, compare dat' +
    'abase designs or post explanations of programming errors and possible solutions. A timeline layout c' +
    'an help groups organise project milestones and reflect on progress.');
  lstLines.Add('');
  lstLines.Add('Teaching, learning and assessment strategies');
  lstLines.Add('');
  lstLines.Add('Padlet supports brainstorming, jigsaw learning, gallery walks, peer feedback and collaborative proje' +
    'ct work. To ensure meaningful learning, each post should respond to a task or criterion. Teachers ca' +
    'n assess both the quality of the shared product and individual contributions through brief reflectio' +
    'ns or oral explanations. Moderation and respectful digital communication should be taught explicitly' +
    '.');
  lstLines.Add('');
  lstLines.Add('Self-Directed Learning opportunities');
  lstLines.Add('');
  lstLines.Add('Learners can use a board to collect resources, record questions, organise project ideas and reflect ' +
    'on what they have learned. A structured board can encourage learners to identify gaps in their knowl' +
    'edge and request support. Teachers can include prompts such as ''What did I contribute?'', ''What evide' +
    'nce supports my idea?'' and ''What will I investigate next?''');
  lstLines.Add('');
  lstLines.Add('AI integration opportunities');
  lstLines.Add('');
  lstLines.Add('AI is not essential to Padlet’s core collaborative function. Teachers may use external AI tools to b' +
    'rainstorm board prompts, generate sample scenarios or help organise a lesson sequence, but must revi' +
    'ew the material. If learners use AI to draft posts or summaries, they should identify that assistanc' +
    'e and verify the content. The teacher should ensure that learner data and unpublished work are not e' +
    'ntered into public AI tools without appropriate safeguards.');
  lstLines.Add('');
  lstLines.Add('Authentic classroom activity');
  lstLines.Add('');
  lstLines.Add('Grade 10 CAT digital citizenship board: The teacher creates columns titled ''Safe practice'', ''Unsafe ' +
    'practice'', ''POPI Act and privacy'' and ''Questions''. Small groups analyse a short online scenario and ' +
    'post one recommendation with a reason. Each group comments constructively on another group’s recomme' +
    'ndation. Learners then write an individual exit reflection explaining one action they will take to p' +
    'rotect personal information online.');
  lstLines.Add('');
  lstLines.Add('Professional recommendation');
  lstLines.Add('');
  lstLines.Add('Padlet is recommended for collaborative activities that require learners to contribute ideas, resour' +
    'ces or multimedia evidence in a shared space. It is especially useful for brainstorming and displayi' +
    'ng group work. It should be structured and moderated, and teachers should plan around the free-plan ' +
    'limit of three Padlets. It is not a substitute for a formal learning management system or individual' +
    ' assessment');
  lstLines.Add('');
  lstLines.Add('Comparative analysis and professional recommendations');
  lstLines.Add('');
  lstLines.Add('The six platforms overlap in some functions, but they are not interchangeable. Microsoft Teams and G' +
    'oogle Classroom are strongest when the teacher needs an organised environment for communication, res' +
    'ources and assignment management. Kahoot! and Wayground are primarily useful for interactive practic' +
    'e and formative assessment, although Wayground offers a wider range of self-paced instructional form' +
    'ats. Mentimeter is most effective for gathering learner responses during a presentation, while Padle' +
    't is particularly useful for collaborative idea development and sharing learner-created content.');
  lstLines.Add('');
  lstLines.Add('Technology    Strongest use    Best CAT/IT examples    Main caution');
  lstLines.Add('');
  lstLines.Add('Microsoft Teams    Communication and group project coordination    Shared spreadsheet/database/pro' +
    'gramming project files    Account, connectivity and notification management');
  lstLines.Add('');
  lstLines.Add('Google Classroom    Assignments, resources and feedback    Practical task distribution and submiss' +
    'ion    Requires accounts/connectivity; advanced tools vary by edition');
  lstLines.Add('');
  lstLines.Add('Kahoot!    Fast formative review and retrieval practice    Spreadsheet functions, networks, progra' +
    'mming vocabulary    Speed and competition may create anxiety');
  lstLines.Add('');
  lstLines.Add('Wayground    Self-paced practice and differentiated assessment    Multi-level function, algorithm ' +
    'and database practice    Free-plan limits and teacher review of generated content');
  lstLines.Add('');
  lstLines.Add('Mentimeter    Live participation and prior-knowledge checks    Confidence polls, word clouds and c' +
    'oncept checks    50 participants/month on free live presentations');
  lstLines.Add('');
  lstLines.Add('Padlet    Collaborative brainstorming and sharing    Digital citizenship, project planning and sol' +
    'ution galleries    Three active Padlets on free plan; moderation needed');
  lstLines.Add('');
  lstLines.Add('Most strongly recommended technologies');
  lstLines.Add('');
  lstLines.Add('For a beginning CAT or IT teacher who needs to establish a consistent digital workflow, Google Class' +
    'room or Microsoft Teams should be considered first, depending on the school’s existing digital ecosy' +
    'stem. A school already using Microsoft 365 may find Teams more practical, while a qualifying institu' +
    'tion using Google Workspace for Education may find Classroom easier to adopt. Selecting one main pla' +
    'tform can reduce confusion and avoid requiring learners to manage multiple accounts.');
  lstLines.Add('');
  lstLines.Add('For ongoing formative assessment, Wayground is recommended where teachers want self-paced practice, ' +
    'varied activity formats and reports that can inform follow-up teaching. Kahoot! remains valuable for' +
    ' short revision activities and retrieval practice, provided that speed and competition do not domina' +
    'te the learning purpose. Mentimeter is recommended as a complementary tool for learner voice and qui' +
    'ck checks during a lesson. Padlet is recommended for group brainstorming, collaborative research and' +
    ' sharing practical outputs.');
  lstLines.Add('');
  lstLines.Add('Educational theory and justification');
  lstLines.Add('');
  lstLines.Add('The recommendations are consistent with formative assessment principles. Black and Wiliam (1998) arg' +
    'ue that assessment can improve learning when evidence is used to adjust teaching and provide informa' +
    'tion that helps learners move forward. Therefore, teachers should use quiz reports, polls and submit' +
    'ted work to decide what to reteach, what to extend and which learners need support. Merely collectin' +
    'g scores without responding to the evidence limits the educational value of the tools.');
  lstLines.Add('');
  lstLines.Add('The recommendations also align with social constructivist perspectives in which learners develop und' +
    'erstanding through interaction, dialogue and engagement with tasks. Shared documents, discussion cha' +
    'nnels and collaborative boards can provide opportunities for learners to explain ideas and compare s' +
    'olutions. However, collaboration must be deliberately structured. Roles, group goals, success criter' +
    'ia and individual accountability help ensure that every learner participates rather than allowing on' +
    'e learner to complete the task for the group.');
  lstLines.Add('');
  lstLines.Add('Self-directed learning is supported when learners are able to set goals, select strategies, monitor ' +
    'progress and evaluate outcomes. Self-paced activities, feedback and progress records can create oppo' +
    'rtunities for these behaviours. Nevertheless, autonomy develops progressively. Teachers should model' +
    ' how to interpret feedback, plan revision and seek help when needed rather than assuming that access' +
    ' to an online platform automatically makes learners self-directed.');
  lstLines.Add('');
  lstLines.Add('Selection according to classroom context');
  lstLines.Add('');
  lstLines.Add('For a school with Microsoft 365 accounts and a need for integrated communication and group projects:' +
    ' prioritise Microsoft Teams.');
  lstLines.Add('');
  lstLines.Add('For a school using Google Workspace for Education and needing assignment management: prioritise Goog' +
    'le Classroom.');
  lstLines.Add('');
  lstLines.Add('For short, lively retrieval practice and revision: use Kahoot!, with inclusive timing and discussion' +
    '.');
  lstLines.Add('');
  lstLines.Add('For independent practice, differentiated tasks and follow-up assessment: use Wayground.');
  lstLines.Add('');
  lstLines.Add('For gathering responses and activating prior knowledge during a lesson: use Mentimeter.');
  lstLines.Add('');
  lstLines.Add('For group brainstorming, project planning and sharing work: use Padlet.');
  lstLines.Add('');
  lstLines.Add('Teachers do not need to use all six platforms in every lesson. The most appropriate choice is the si' +
    'mplest tool that meets the learning purpose and can be accessed by the learners. A coherent approach' +
    ' may use one main classroom platform and one additional tool for a specific activity.');
  lstLines.Add('');
  lstLines.Add('Implementation considerations for South African CAT and IT classrooms');
  lstLines.Add('');
  lstLines.Add('Connectivity, devices and affordability');
  lstLines.Add('');
  lstLines.Add('Teachers should establish what devices and connectivity learners can realistically access before pla' +
    'nning an online activity. In classes where devices are limited, learners can work in pairs or small ' +
    'groups, rotate through stations or use a teacher-controlled display with group response cards. Activ' +
    'ities should be designed to minimise unnecessary data use. Where possible, teachers can download or ' +
    'prepare resources in advance and provide printed instructions or offline files. These approaches are' +
    ' important because research identifies unequal technical access and the digital divide as continuing' +
    ' challenges in South African education (Hart, 2023; Chomunorwa, Mashonganyika and Marevesa, 2023).');
  lstLines.Add('');
  lstLines.Add('Teacher readiness and curriculum alignment');
  lstLines.Add('');
  lstLines.Add('A digital tool should be selected after the teacher identifies the curriculum outcome and the eviden' +
    'ce that will show whether learners have achieved it. Teachers should practise the platform before us' +
    'ing it with a class, prepare clear instructions and establish a backup plan. Professional developmen' +
    't and technical support are important for sustainable integration; Rasool and Naidoo (2024) identify' +
    ' weaknesses in teacher development and technical support as barriers in the Gauteng schools included' +
    ' in their study.');
  lstLines.Add('');
  lstLines.Add('Privacy, security and responsible AI');
  lstLines.Add('');
  lstLines.Add('Teachers should use approved school accounts where possible, apply suitable access settings and avoi' +
    'd publishing learner names, marks, contact details or other personal information unnecessarily. Lear' +
    'ners should be taught to communicate respectfully, protect passwords, check links and report inappro' +
    'priate content. When AI is used, teachers should explain its limitations, verify generated informati' +
    'on and set transparent expectations for acknowledgement. AI should support planning, feedback and ex' +
    'ploration without replacing learner thinking or the teacher’s professional judgement.');
  lstLines.Add('');
  lstLines.Add('Inclusion and assessment fairness');
  lstLines.Add('');
  lstLines.Add('Not every learner is equally comfortable with public competition, rapid reading or speaking in front' +
    ' of peers. Teachers should provide sufficient response time, use accessible language, offer alternat' +
    'ive response methods and avoid relying exclusively on leaderboards or automated scores. Learners who' +
    ' cannot access a device should still have a fair way to demonstrate the same learning outcome. Digit' +
    'al participation should never be confused with actual understanding.');
  lstLines.Add('');
  lstLines.Add('Conclusion');
  lstLines.Add('');
  lstLines.Add('Teaching, assessment and collaboration technologies can strengthen CAT and IT education when they ar' +
    'e selected according to clear learning purposes and integrated with effective pedagogy. Microsoft Te' +
    'ams and Google Classroom can support the organisation of teaching, resources and assignments. Kahoot' +
    '! and Wayground can make formative assessment and revision more interactive, while Mentimeter can in' +
    'crease learner participation and Padlet can support collaborative knowledge sharing. Each platform a' +
    'lso has limitations, particularly in relation to connectivity, free-plan restrictions, learner acces' +
    's, privacy and the risk of focusing on engagement rather than learning.');
  lstLines.Add('');
  lstLines.Add('The central recommendation is that teachers should use technology purposefully rather than use multi' +
    'ple platforms simply because they are available. They should begin with the tools supported by their' +
    ' school, teach learners how to use them responsibly and evaluate whether the technology improves par' +
    'ticipation, feedback, collaboration or learner independence. In South African classrooms, flexible p' +
    'lanning and equitable alternatives are essential. When these conditions are considered, digital tech' +
    'nologies can contribute to more engaging, collaborative and future-ready CAT and IT learning.');
  lstLines.Add('');
end;

procedure AddSection3(lstLines: TStrings);
begin
  lstLines.Add('Chapter 3: Emerging Technologies and Future Trends in Computer Science Education');
  lstLines.Add('');
  lstLines.Add('Introduction');
  lstLines.Add('');
  lstLines.Add('Emerging technologies are changing how people communicate, access information, and do everyday tasks' +
    ' Graham & Dutton (2019). These developments are also influencing education, particularly Computer Ap' +
    'plications Technology (CAT) and Information Technology (IT). Teachers are no longer limited to using' +
    ' textbooks, traditional presentations, and computer laboratories Shahid et al. (2019). New technolog' +
    'ies give learners opportunities to explore concepts, solve problems, create digital products, and ga' +
    'in practical experience. As a result, teachers need to understand these developments and consider ho' +
    'w they can be used to improve teaching and learning.');
  lstLines.Add('');
  lstLines.Add('Some of the technologies receiving increasing attention in education include Virtual Reality (VR), A' +
    'ugmented Reality (AR), the Internet of Things (IoT), robotics and automation, 3D printing and cloud ' +
    'computing. These technologies provide different opportunities for learners to engage with digital en' +
    'vironments and understand how technology is used in real-life situations. For example, VR allows lea' +
    'rners to explore computer-generated environments Asad et al. (2021), while AR combines digital infor' +
    'mation with the physical world Dargan et al. (2023). IoT introduces learners to connected devices, s' +
    'ensors and data communication Abdel‐Basset et al. (2019). Robotics and 3D printing also encourage pr' +
    'actical learning, creativity and problem-solving (Pakman et al., 2023).');
  lstLines.Add('');
  lstLines.Add('Research has highlighted the educational potential of these technologies. Lin and Yu (2023), for exa' +
    'mple, found that augmented reality can improve learning effectiveness, learner engagement and knowle' +
    'dge acquisition. Similarly, Ching and Hsu (2023) identified the contribution of educational robotics' +
    ' to the development of computational thinking skills. Marougkas et al. (2024) also examined how VR c' +
    'an create interactive and immersive learning experiences. These developments show that emerging tech' +
    'nologies can provide learning opportunities beyond traditional classroom methods.');
  lstLines.Add('');
  lstLines.Add('However, introducing new technologies into South African schools also comes with challenges. These i' +
    'nclude limited access to computers, internet connectivity, electricity, equipment and teacher traini' +
    'ng. Therefore, teachers should not introduce technologies simply because they are new. They should c' +
    'onsider their educational value, affordability, accessibility and relevance to the curriculum.');
  lstLines.Add('');
  lstLines.Add('This chapter explores six emerging technologies and evaluates how they can support CAT and IT teachi' +
    'ng and learning. It also considers their advantages, limitations, classroom applications and opportu' +
    'nities for promoting Self-Directed Learning (SDL).');
  lstLines.Add('');
  lstLines.Add('Evaluation of emerging technologies');
  lstLines.Add('');
  lstLines.Add('Virtual Reality (VR)');
  lstLines.Add('');
  lstLines.Add('Website: https://www.delightex.com/edu]');
  lstLines.Add('');
  lstLines.Add('Cost: Freemium. Basic creation features are available free, while additional features require a paid' +
    ' plan. VR hardware may also involve additional costs.');
  lstLines.Add('');
  lstLines.Add('Brief overview');
  lstLines.Add('');
  lstLines.Add('Asad et al. (2021) defines Virtual Reality (VR) as a technology that allows users to experience a co' +
    'mputer-generated environment. Instead of only looking at information on a screen, learners can explo' +
    're a virtual environment and interact with objects. VR experiences can be accessed through specialis' +
    'ed headsets or, in some cases, smartphones and computers.');
  lstLines.Add('');
  lstLines.Add('Educational purpose');
  lstLines.Add('');
  lstLines.Add('The educational purpose of VR is to provide learners with opportunities to explore concepts through ' +
    'simulated experiences. In CAT and IT education, VR can be used to demonstrate computer hardware, exp' +
    'lore virtual computer laboratories and investigate how technological systems work. This is useful wh' +
    'en learners cannot physically access certain equipment or when a concept is difficult to demonstrate' +
    ' using ordinary classroom resources. From a constructivist perspective, learners can develop underst' +
    'anding by actively exploring and interacting with the virtual environment. Experiential learning is ' +
    'also relevant because learners gain experience through an activity and can reflect on what they have' +
    ' observed. Conrad et al. (2024) discuss the potential of immersive VR for action-oriented learning a' +
    'nd practical application. However, the effectiveness of VR depends on the learning objectives and ho' +
    'w the activity is designed. Simply allowing learners to explore a virtual environment without a clea' +
    'r task may not lead to meaningful learning.');
  lstLines.Add('');
  lstLines.Add('Advantages');
  lstLines.Add('');
  lstLines.Add('Makes learning more interactive and interesting.');
  lstLines.Add('');
  lstLines.Add('Allows learners to explore environments that may not be available at school.');
  lstLines.Add('');
  lstLines.Add('Supports visual and experiential learning.');
  lstLines.Add('');
  lstLines.Add('Can help learners understand complex concepts through simulation.');
  lstLines.Add('');
  lstLines.Add('Limitations');
  lstLines.Add('');
  lstLines.Add('VR headsets can be expensive.');
  lstLines.Add('');
  lstLines.Add('Some learners may experience discomfort or motion sickness.');
  lstLines.Add('');
  lstLines.Add('Requires suitable devices and sometimes reliable internet.');
  lstLines.Add('');
  lstLines.Add('Teachers need training to use VR effectively.');
  lstLines.Add('');
  lstLines.Add('Research by Marougkas et al. (2024) discussed the educational benefits and limitations of immersive ' +
    'VR. Research on immersive technologies reports promising educational possibilities, but effects on l' +
    'earning performance and motivation are not always consistent. This suggests that VR should not be in' +
    'troduced simply because it is innovative. Teachers need to consider whether it is suitable for the c' +
    'oncept being taught and whether it offers an advantage over more accessible resources (Poupard et al' +
    '., 2025).');
  lstLines.Add('');
  lstLines.Add('CAT classroom applications');
  lstLines.Add('');
  lstLines.Add('VR can support the CAPS Systems Technologies focus area, particularly the understanding of computer ' +
    'hardware, components and the functions of a computer system. Learners can explore a virtual computer' +
    ' and identify the motherboard, CPU, RAM and storage devices; teachers can demonstrate how components' +
    ' fit together; and learners can investigate computer systems and compare component functions. The CA' +
    'T CAPS also addresses new trends and developments in technology and how they may be integrated into ' +
    'equipment (Department of Basic Education, 2011).');
  lstLines.Add('');
  lstLines.Add('IT classroom applications');
  lstLines.Add('');
  lstLines.Add('IT learners can explore virtual representations of computer hardware and system components, investig' +
    'ate simulated network environments and discuss how devices are connected. VR can enrich understandin' +
    'g of IT concepts, but it does not replace practical programming activities.');
  lstLines.Add('');
  lstLines.Add('Teaching and learning strategies supported');
  lstLines.Add('');
  lstLines.Add('VR can support experiential learning, inquiry-based learning and problem-based learning. Learners ca' +
    'n explore an environment, investigate a question and use their observations to solve a problem. The ' +
    'teacher should provide guiding questions and a clear task so that learners remain focused on the int' +
    'ended outcomes.');
  lstLines.Add('');
  lstLines.Add('Opportunities for Self-Directed Learning');
  lstLines.Add('');
  lstLines.Add('VR can support SDL by allowing learners to explore virtual environments, repeat demonstrations and i' +
    'nvestigate concepts they find difficult. Learners can be given a goal, such as identifying computer ' +
    'components and explaining their functions. They can explore the environment, record observations and' +
    ' assess whether they have achieved the goal. Teachers should provide instructions and reflection que' +
    'stions, particularly when learners are new to VR (Knowles, 1975; Garrison, 1997).');
  lstLines.Add('');
  lstLines.Add('AI integration opportunities');
  lstLines.Add('');
  lstLines.Add('AI tools such as ChatGPT can be used alongside VR to support teaching and learning. For example, tea' +
    'chers can use AI to prepare questions, explanations and activities related to the virtual environmen' +
    't learners are exploring. Learners can also use AI to clarify concepts they find difficult to unders' +
    'tand after completing a VR activity. This can help them develop a better understanding of the conten' +
    't.');
  lstLines.Add('');
  lstLines.Add('Example classroom activity');
  lstLines.Add('');
  lstLines.Add('Learners use a VR environment to explore different computer hardware components. They identify the m' +
    'otherboard, CPU, RAM, storage devices and other components. They then complete a worksheet explainin' +
    'g the purpose of each component.');
  lstLines.Add('');
  lstLines.Add('Professional recommendation');
  lstLines.Add('');
  lstLines.Add('VR is recommended as an additional teaching resource, particularly when explaining concepts that are' +
    ' difficult to demonstrate physically. However, teachers should consider the cost of equipment and en' +
    'sure that learners who do not have access to VR devices can still participate through alternative le' +
    'arning materials.');
  lstLines.Add('');
  lstLines.Add('Augmented Reality (AR)');
  lstLines.Add('');
  lstLines.Add('Website: https://merge3d.ai/');
  lstLines.Add('');
  lstLines.Add('Cost: Varies. Some AR applications offer free access, while others require subscriptions or addition' +
    'al equipment.');
  lstLines.Add('');
  lstLines.Add('Brief overview');
  lstLines.Add('');
  lstLines.Add('According to Dargan et al. (2023) Augmented Reality (AR) is a technology that adds digital informati' +
    'on, images and 3D objects to the real-world environment. Unlike VR, which creates a completely virtu' +
    'al environment Marougkas et al. (2024)  , AR allows learners to see digital objects through a smartp' +
    'hone, tablet or other compatible device while still viewing their surroundings.');
  lstLines.Add('');
  lstLines.Add('Educational purpose');
  lstLines.Add('');
  lstLines.Add('The educational purpose of AR is to help learners visualise information and understand concepts thro' +
    'ugh digital objects placed within their real environment. In CAT and IT education, AR can be used to' +
    ' display three-dimensional representations of computer hardware, network devices and other technolog' +
    'ical components. It is useful when components are small, hidden inside a computer case or difficult ' +
    'to explain using textbook pictures. Learners can examine a digital representation and identify diffe' +
    'rent parts. Lin and Yu (2023) found that AR can improve learning effectiveness, knowledge acquisitio' +
    'n and practical skills. However, their findings did not show improvements in every learning outcome.' +
    ' Teachers should therefore include discussion and collaborative tasks rather than assume that AR aut' +
    'omatically develops all skills.');
  lstLines.Add('');
  lstLines.Add('Advantages');
  lstLines.Add('');
  lstLines.Add('Makes learning more visual and interactive.');
  lstLines.Add('');
  lstLines.Add('Can be accessed through compatible smartphones and tablets.');
  lstLines.Add('');
  lstLines.Add('Helps learners understand complex concepts.');
  lstLines.Add('');
  lstLines.Add('Encourages exploration and active participation.');
  lstLines.Add('');
  lstLines.Add('Limitations');
  lstLines.Add('');
  lstLines.Add('Some applications require modern devices.');
  lstLines.Add('');
  lstLines.Add('Not all learners have access to smartphones or tablets.');
  lstLines.Add('');
  lstLines.Add('Certain applications require internet connectivity.');
  lstLines.Add('');
  lstLines.Add('Digital objects may distract learners if activities are not properly structured.');
  lstLines.Add('');
  lstLines.Add('Lin and Yu (2023) conducted a meta-analysis of 70 empirical studies and found that AR can improve le' +
    'arning effectiveness, motivation, knowledge acquisition and practical skills. However, their finding' +
    's did not show significant improvements in every area, including collaboration and communication.');
  lstLines.Add('');
  lstLines.Add('CAT classroom applications');
  lstLines.Add('');
  lstLines.Add('AR can support the CAT Systems Technologies focus area by helping learners understand computer hardw' +
    'are and the functions of components. It can also support the study of new technological developments' +
    '. Learners can view 3D computer hardware, identify components, explore digital representations of ne' +
    'twork devices and compare digital models with textbook diagrams. (Department of Basic Education, 201' +
    '1).');
  lstLines.Add('');
  lstLines.Add('IT classroom applications');
  lstLines.Add('');
  lstLines.Add('IT learners can explore digital models of computer components, investigate technological devices and' +
    ' explain their functions. AR can support visual understanding of system architecture, but it does no' +
    't replace programming and problem-solving activities.');
  lstLines.Add('');
  lstLines.Add('Teaching and learning strategies supported');
  lstLines.Add('');
  lstLines.Add('AR supports inquiry-based learning, visual learning, experiential learning and collaborative learnin' +
    'g. Learners can investigate digital objects, answer questions and discuss observations with classmat' +
    'es. Teachers can use guided discovery by providing questions that encourage learners to examine the ' +
    'objects rather than simply view them.');
  lstLines.Add('');
  lstLines.Add('Opportunities for Self-Directed Learning');
  lstLines.Add('');
  lstLines.Add('Learners can use AR to explore digital objects independently and repeat demonstrations when they nee' +
    'd more time. A learner who struggles to identify computer hardware can revisit the digital model and' +
    ' use additional resources to research unfamiliar components. Learners can set goals, such as identif' +
    'ying and explaining the functions of different components. Teachers should ensure that learners eval' +
    'uate what they have learned (Knowles, 1975; Garrison, 1997).');
  lstLines.Add('');
  lstLines.Add('AI integration opportunities');
  lstLines.Add('');
  lstLines.Add('Teachers can use AI tools such as ChatGPT alongside AR activities to provide additional explanations' +
    ' and support learners'' understanding. For example, after exploring 3D computer hardware components u' +
    'sing AR, learners can ask ChatGPT to explain the functions of the motherboard, CPU and RAM. AI can a' +
    'lso help teachers prepare questions and short activities based on the AR lesson. This allows learner' +
    's to gain further information and clarify concepts they may not have understood during the activity.');
  lstLines.Add('');
  lstLines.Add('Example classroom activity');
  lstLines.Add('');
  lstLines.Add('Learners use an AR application to explore a 3D computer motherboard. They identify different compone' +
    'nts and explain their functions. Each learner creates a short digital explanation of three component' +
    's.');
  lstLines.Add('');
  lstLines.Add('Professional recommendation');
  lstLines.Add('');
  lstLines.Add('AR is recommended because it can help learners understand computer hardware through visual demonstra' +
    'tions. It may also be more practical than VR because some AR activities can be accessed using smartp' +
    'hones or tablets. However, teachers must consider whether learners have access to compatible devices' +
    '.');
  lstLines.Add('');
  lstLines.Add('2.3 Internet of Things (IoT)');
  lstLines.Add('');
  lstLines.Add('Website: https://www.arduino.cc/');
  lstLines.Add('');
  lstLines.Add('Cost: Freemium/open-source software. Arduino IDE is open-source, but physical boards, sensors and ot' +
    'her components must generally be purchased.');
  lstLines.Add('');
  lstLines.Add('Brief overview');
  lstLines.Add('');
  lstLines.Add('The Internet of Things (IoT) refers to physical devices connected to the internet that collect and e' +
    'xchange data. These devices can include smartwatches, security cameras, smart televisions, sensors a' +
    'nd other connected equipment. IoT allows devices to communicate and share information without requir' +
    'ing constant human involvement (Abdel‐Basset et al., 2019).');
  lstLines.Add('');
  lstLines.Add('Educational purpose');
  lstLines.Add('');
  lstLines.Add('The educational purpose of IoT is to help learners understand how everyday devices connect to networ' +
    'ks, collect information and communicate with other devices. In CAT and IT education, IoT provides op' +
    'portunities to explore networking, data communication, sensors and connected systems. It connects th' +
    'eoretical knowledge about networks to familiar devices. For example, learners may use a smartphone t' +
    'o monitor a security camera or control a smart light. Investigating these examples can help them und' +
    'erstand that connected devices rely on networks to exchange information. From a constructivist persp' +
    'ective, learners build understanding by investigating familiar devices. Inquiry-based learning is al' +
    'so suitable because learners can ask questions, investigate how devices communicate and develop poss' +
    'ible solutions to real-world problems.');
  lstLines.Add('');
  lstLines.Add('Advantages');
  lstLines.Add('');
  lstLines.Add('Connects classroom learning to real-life technology.');
  lstLines.Add('');
  lstLines.Add('Encourages practical activities and problem-solving.');
  lstLines.Add('');
  lstLines.Add('Helps learners understand networks and data communication.');
  lstLines.Add('');
  lstLines.Add('Develops awareness of smart devices and digital systems.');
  lstLines.Add('');
  lstLines.Add('Limitations');
  lstLines.Add('');
  lstLines.Add('Physical equipment and sensors can be expensive.');
  lstLines.Add('');
  lstLines.Add('Some activities require internet connectivity.');
  lstLines.Add('');
  lstLines.Add('Devices may create security and privacy risks.');
  lstLines.Add('');
  lstLines.Add('Teachers may need additional technical knowledge.');
  lstLines.Add('');
  lstLines.Add('Abichandani et al. (2022) reviewed research articles on IoT curriculum, teaching approaches and asse' +
    'ssment in STEM education. Their findings highlight the value of low-cost hardware, open-source softw' +
    'are and active learning approaches when introducing IoT into education.');
  lstLines.Add('');
  lstLines.Add('CAT classroom applications');
  lstLines.Add('');
  lstLines.Add('IoT has a strong connection to CAT Internet and Network Technologies and Systems Technologies. It ca' +
    'n help learners understand networks, connected devices, hardware and new technological developments.' +
    ' Learners can investigate how smart devices connect to networks, explain how devices collect and sha' +
    're information, discuss the benefits and risks of smart security systems, and identify the role of r' +
    'outers and wireless connections.');
  lstLines.Add('');
  lstLines.Add('IT classroom applications');
  lstLines.Add('');
  lstLines.Add('IT learners can investigate sensors and microcontrollers, explore how data is collected and transmit' +
    'ted, and examine basic IoT system structures and device communication.');
  lstLines.Add('');
  lstLines.Add('Teaching and learning strategies supported');
  lstLines.Add('');
  lstLines.Add('IoT can support inquiry-based learning, project-based learning and collaborative learning. Learners ' +
    'can investigate a real-world problem, identify devices needed to address it and design a possible so' +
    'lution. This encourages them to apply theoretical knowledge and work together.');
  lstLines.Add('');
  lstLines.Add('Opportunities for Self-Directed Learning');
  lstLines.Add('');
  lstLines.Add('IoT provides opportunities for learners to research connected devices and investigate how they work.' +
    ' Learners can select a device, identify its purpose and explore how it communicates with other devic' +
    'es. For example, they can investigate how a smart security camera works, identify the information it' +
    ' collects and explain how that information is transmitted. Teachers guide learners towards reliable ' +
    'resources and help them identify incorrect information (Knowles, 1975; Garrison, 1997).');
  lstLines.Add('');
  lstLines.Add('AI integration opportunities');
  lstLines.Add('');
  lstLines.Add('AI can analyse information collected by IoT devices and identify patterns. For example, learners can' +
    ' investigate how a smart system uses collected data to make decisions.');
  lstLines.Add('');
  lstLines.Add('Example classroom activity');
  lstLines.Add('');
  lstLines.Add('Learners work in groups to design a smart classroom using IoT concepts. They identify devices such a' +
    's temperature sensors, smart lights and security cameras. They then draw a network diagram showing h' +
    'ow the devices communicate.');
  lstLines.Add('');
  lstLines.Add('Professional recommendation');
  lstLines.Add('');
  lstLines.Add('IoT is strongly recommended for CAT and IT because it connects networking concepts with real-life ap' +
    'plications. Teachers can begin with diagrams and simulations before introducing physical equipment. ' +
    'This makes the technology more accessible to schools with limited resources.');
  lstLines.Add('');
  lstLines.Add('Robotics and Automation');
  lstLines.Add('');
  lstLines.Add('Website: https://lab.open-roberta.org/');
  lstLines.Add('');
  lstLines.Add('Cost: Free online programming and simulation environment. Physical robots may require purchasing.');
  lstLines.Add('');
  lstLines.Add('Brief overview');
  lstLines.Add('');
  lstLines.Add('Robotics involves designing, building and using machines that can perform tasks. Automation refers t' +
    'o using technology to perform tasks with limited human involvement. Robots can be programmed to foll' +
    'ow instructions, respond to their surroundings and complete specific activities.');
  lstLines.Add('');
  lstLines.Add('Open Roberta Lab provides a free, browser-based environment where learners can program and simulate ' +
    'robots without necessarily owning physical equipment.');
  lstLines.Add('');
  lstLines.Add('Educational purpose');
  lstLines.Add('');
  lstLines.Add('The educational purpose of robotics and automation is to help learners develop practical problem-sol' +
    'ving, logical thinking and creativity. In CAT and IT education, robotics can be used to demonstrate ' +
    'how hardware and software work together to perform specific tasks. Learners can also develop an unde' +
    'rstanding of how machines follow programmed instructions and complete tasks automatically. This prov' +
    'ides opportunities for learners to apply theoretical knowledge to practical situations while develop' +
    'ing their technological skills.');
  lstLines.Add('');
  lstLines.Add('Advantages');
  lstLines.Add('');
  lstLines.Add('Encourages creativity and innovation.');
  lstLines.Add('');
  lstLines.Add('Develops problem-solving skills.');
  lstLines.Add('');
  lstLines.Add('Provides practical learning opportunities.');
  lstLines.Add('');
  lstLines.Add('Encourages learners to work together.');
  lstLines.Add('');
  lstLines.Add('Introduces learners to real-world automation.');
  lstLines.Add('');
  lstLines.Add('Limitations');
  lstLines.Add('');
  lstLines.Add('Physical robots can be expensive.');
  lstLines.Add('');
  lstLines.Add('Some activities require technical knowledge.');
  lstLines.Add('');
  lstLines.Add('Equipment may need maintenance.');
  lstLines.Add('');
  lstLines.Add('Limited resources can affect learner participation.');
  lstLines.Add('');
  lstLines.Add('Ching and Hsu (2023) identified skills such as sequencing, loops, conditionals, debugging and algori' +
    'thmic thinking as important areas developed through robotics activities.');
  lstLines.Add('');
  lstLines.Add('CAT classroom applications');
  lstLines.Add('');
  lstLines.Add('In CAT, robotics and automation can support the study of ICTs in everyday life, new technology and t' +
    'he social implications of technological developments. Learners can investigate automation in workpla' +
    'ces, discuss how robots affect everyday activities, research advantages and disadvantages, and consi' +
    'der possible effects on employment and society.');
  lstLines.Add('');
  lstLines.Add('IT classroom applications');
  lstLines.Add('');
  lstLines.Add('Robotics has a more direct connection to IT programming and problem-solving concepts. Learners can c' +
    'reate instructions for a simulated robot, practise sequencing and logical instructions, investigate ' +
    'sensors and programmed instructions, and test programmes to identify and correct errors. These activ' +
    'ities support relevant programming and algorithmic thinking outcomes, but do not replace prescribed ' +
    'programming content.');
  lstLines.Add('');
  lstLines.Add('Teaching and learning strategies supported');
  lstLines.Add('');
  lstLines.Add('Robotics supports problem-based learning, project-based learning and collaborative learning. Learner' +
    's are given a task or problem and develop instructions to achieve a particular outcome. They test th' +
    'eir work, identify errors and make improvements. This creates opportunities for learning through exp' +
    'erimentation and reflection.');
  lstLines.Add('');
  lstLines.Add('Opportunities for Self-Directed Learning');
  lstLines.Add('');
  lstLines.Add('Learners can experiment with different instructions, test programmes and correct errors independentl' +
    'y. They can use online tutorials and simulations to develop understanding. For example, learners can' +
    ' set a goal to programme a robot to move forward, turn and stop at a specific point. They test diffe' +
    'rent instructions until the robot performs the task correctly. This encourages learners to take resp' +
    'onsibility for progress and learn from mistakes.');
  lstLines.Add('');
  lstLines.Add('AI integration opportunities');
  lstLines.Add('');
  lstLines.Add('Robotics can develop computational thinking, problem-solving, creativity, collaboration and adaptabi' +
    'lity. AI can be connected to robotics through technologies that allow machines to recognise objects,' +
    ' process information and respond to their surroundings. AI tools can assist learners in understandin' +
    'g programming instructions, but learners should still write, test and explain their own programmes.');
  lstLines.Add('');
  lstLines.Add('Example classroom activity');
  lstLines.Add('');
  lstLines.Add('Learners use Open Roberta Lab to create a simple programme that instructs a simulated robot to move ' +
    'forward, turn and stop at a specific point. They test their instructions and correct errors.');
  lstLines.Add('');
  lstLines.Add('Professional recommendation');
  lstLines.Add('');
  lstLines.Add('Robotics and automation are recommended because they provide practical opportunities for developing ' +
    'problem-solving and technological skills. Teachers can begin with free simulations before introducin' +
    'g physical robots, reducing the financial burden on schools.');
  lstLines.Add('');
  lstLines.Add('3D Printing');
  lstLines.Add('');
  lstLines.Add('Website: https://www.tinkercad.com');
  lstLines.Add('');
  lstLines.Add('Cost: Tinkercad is free to use as a web application. However, purchasing a 3D printer and printing m' +
    'aterials involves additional costs.');
  lstLines.Add('');
  lstLines.Add('Brief overview');
  lstLines.Add('');
  lstLines.Add('3D printing is a technology that creates physical objects from digital designs. Users first create a' +
    ' 3D model using design software. The model is then sent to a 3D printer, which produces the object l' +
    'ayer by layer.');
  lstLines.Add('');
  lstLines.Add('Tinkercad allows learners to create 3D designs online and develop an understanding of digital modell' +
    'ing.');
  lstLines.Add('');
  lstLines.Add('Educational purpose');
  lstLines.Add('');
  lstLines.Add('The educational purpose of 3D printing is to give learners opportunities to turn ideas into digital ' +
    'designs and, where resources are available, physical products. It supports creativity, design thinki' +
    'ng, problem-solving and the ability to improve a product through repeated testing. From a constructi' +
    'vist perspective, learners actively develop understanding by creating and modifying their own design' +
    's. Design-based learning is also relevant because learners identify a need, plan a solution, create ' +
    'a design and evaluate the final product. Tejera et al. (2025) discuss opportunities and implementati' +
    'on challenges associated with 3D modelling and printing in teacher education, including resource ava' +
    'ilability, time and school integration');
  lstLines.Add('');
  lstLines.Add('Advantages');
  lstLines.Add('');
  lstLines.Add('Encourages creativity and innovation.');
  lstLines.Add('');
  lstLines.Add('Helps learners develop digital design skills.');
  lstLines.Add('');
  lstLines.Add('Makes abstract ideas easier to visualise.');
  lstLines.Add('');
  lstLines.Add('Supports practical and project-based learning.');
  lstLines.Add('');
  lstLines.Add('Limitations');
  lstLines.Add('');
  lstLines.Add('3D printers can be expensive.');
  lstLines.Add('');
  lstLines.Add('Printing materials create additional costs.');
  lstLines.Add('');
  lstLines.Add('Printing can take time.');
  lstLines.Add('');
  lstLines.Add('Teachers and learners need training in 3D design.');
  lstLines.Add('');
  lstLines.Add('Barrón-Hernández et al. (2025) reviewed the use of 3D printing in science education. Their findings ' +
    'identified benefits for conceptual understanding, spatial reasoning and modelling. However, they als' +
    'o noted that more evidence is needed regarding long-term learning outcomes and equitable implementat' +
    'ion.');
  lstLines.Add('');
  lstLines.Add('CAT classroom applications');
  lstLines.Add('');
  lstLines.Add('3D printing is not a separate prescribed CAT topic in CAPS. However, it can enrich Systems Technolog' +
    'ies and support the study of new technological developments, hardware and technology in everyday lif' +
    'e. Learners can create digital models of computer-related accessories, investigate how 3D printing i' +
    's used in different industries and discuss its benefits and limitations.');
  lstLines.Add('');
  lstLines.Add('IT classroom applications');
  lstLines.Add('');
  lstLines.Add('3D modelling can support problem-solving and the development of digital products. Learners can desig' +
    'n a simple computer-related object, investigate the relationship between digital models and physical' +
    ' products, and explain the design decisions they made. These activities enrich learning but do not r' +
    'eplace prescribed programming and software development content.');
  lstLines.Add('');
  lstLines.Add('Teaching and learning strategies supported');
  lstLines.Add('');
  lstLines.Add('3D printing supports design-based learning, project-based learning and experiential learning. Learne' +
    'rs identify a problem, design a possible solution, test their designs and make improvements. This en' +
    'courages learning through creating and evaluating their work.');
  lstLines.Add('');
  lstLines.Add('Opportunities for Self-Directed Learning');
  lstLines.Add('');
  lstLines.Add('Learners can explore Tinkercad tutorials, experiment with different designs and improve their models' +
    ' independently. For example, a learner designing a headphone stand can explore different shapes, tes' +
    't stability, and make changes. This allows the learner to take responsibility for the design process' +
    ' and evaluate the final product.');
  lstLines.Add('');
  lstLines.Add('AI integration opportunities');
  lstLines.Add('');
  lstLines.Add('Teachers and learners can use AI tools such as ChatGPT to generate ideas for 3D designs and suggest ' +
    'ways to improve their designs. For example, learners can ask AI for ideas when designing a computer ' +
    'accessory. AI can also help explain basic design concepts and guide learners when they experience di' +
    'fficulties during the design process. However, learners should still create, edit and make their own' +
    ' decisions about the final design.');
  lstLines.Add('');
  lstLines.Add('Example classroom activity');
  lstLines.Add('');
  lstLines.Add('Learners use Tinkercad to design a simple computer accessory, such as a headphone stand or USB cable' +
    ' holder. They create a digital model and explain the design choices they made. If a school has a 3D ' +
    'printer, selected designs can be printed.');
  lstLines.Add('');
  lstLines.Add('Professional recommendation');
  lstLines.Add('');
  lstLines.Add('3D printing is recommended because it gives learners opportunities to apply digital design skills to' +
    ' real-world problems. However, schools do not need to purchase a 3D printer immediately. Learners ca' +
    'n first use free online design software to develop their skills.');
  lstLines.Add('');
  lstLines.Add('2.6 Cloud Computing');
  lstLines.Add('');
  lstLines.Add('Website: https://edu.google.com/workspace-for-education');
  lstLines.Add('');
  lstLines.Add('Cost: Freemium. Google Workspace for Education Fundamentals is available at no cost to qualifying ed' +
    'ucational institutions. Other editions and additional services may require payment.');
  lstLines.Add('');
  lstLines.Add('Brief overview');
  lstLines.Add('');
  lstLines.Add('Cloud computing refers to accessing computing services such as storage, software and processing thro' +
    'ugh the internet instead of relying only on a local computer. It allows users to store files online ' +
    'and access them from different devices. Examples include online storage, web-based applications and ' +
    'cloud-based learning platforms (Sunyaev, 2024).');
  lstLines.Add('');
  lstLines.Add('Educational purpose');
  lstLines.Add('');
  lstLines.Add('The educational purpose of cloud computing is to help learners understand how information and comput' +
    'ing services can be accessed and stored through the internet. In CAT and IT education, cloud computi' +
    'ng provides opportunities to use online applications, manage digital files and collaborate on docume' +
    'nts. It is useful in CAT because learners can practise creating spreadsheets, presentations and docu' +
    'ments using online applications. Al-Samarraie & Saeed (2018) identified opportunities for cloud comp' +
    'uting tools to support collaboration, while also discussing challenges in blended learning environme' +
    'nts. This suggests that cloud platforms can support learning when teachers provide clear tasks and m' +
    'anage learner participation');
  lstLines.Add('');
  lstLines.Add('Advantages');
  lstLines.Add('');
  lstLines.Add('Allows access to files from different devices.');
  lstLines.Add('');
  lstLines.Add('Supports collaboration and sharing.');
  lstLines.Add('');
  lstLines.Add('Reduces dependence on local storage.');
  lstLines.Add('');
  lstLines.Add('Allows learners to access learning materials outside school.');
  lstLines.Add('');
  lstLines.Add('Supports online teaching and learning.');
  lstLines.Add('');
  lstLines.Add('Limitations');
  lstLines.Add('');
  lstLines.Add('Requires internet connectivity for many functions.');
  lstLines.Add('');
  lstLines.Add('Some services have storage limitations.');
  lstLines.Add('');
  lstLines.Add('Users need to understand online security.');
  lstLines.Add('');
  lstLines.Add('Access may be affected by service interruptions.');
  lstLines.Add('');
  lstLines.Add('Personal information must be protected.');
  lstLines.Add('');
  lstLines.Add('Al-Samarraie and Saeed (2018) reviewed cloud computing tools used in collaborative learning. Their s' +
    'tudy identified opportunities for supporting online collaboration as well as challenges associated w' +
    'ith using these tools in blended learning environments.');
  lstLines.Add('');
  lstLines.Add('CAT classroom applications');
  lstLines.Add('');
  lstLines.Add('Cloud computing supports CAT content relating to Internet and Network Technologies, Systems Technolo' +
    'gies and application software. Learners can create and share documents, use online file storage, col' +
    'laborate on spreadsheets and presentations, compare local storage with cloud storage, and discuss th' +
    'e advantages and risks of storing information online. (Department of Basic Education, 2011).');
  lstLines.Add('');
  lstLines.Add('IT classroom applications');
  lstLines.Add('');
  lstLines.Add('IT learners can investigate cloud computing and online storage, compare local and cloud-based comput' +
    'ing, and explore cloud services and the importance of security when accessing online services.');
  lstLines.Add('');
  lstLines.Add('Teaching and learning strategies supported');
  lstLines.Add('');
  lstLines.Add('Cloud computing supports collaborative learning, blended learning and independent learning. Learners' +
    ' can work together on shared documents, provide feedback and contribute to group tasks. Teachers can' +
    ' also provide online learning materials that learners access outside the classroom.');
  lstLines.Add('');
  lstLines.Add('Opportunities for Self-Directed Learning');
  lstLines.Add('');
  lstLines.Add('Cloud computing can support SDL by giving learners access to learning materials, tutorials and activ' +
    'ities beyond the classroom. Learners can organise digital files, access resources when needed and wo' +
    'rk through activities at their own pace. For example, a CAT learner can use an online spreadsheet ap' +
    'plication to practise formulas, review feedback and improve their work. However, access depends on c' +
    'onnectivity, devices and data availability. Teachers should provide school-based access and alternat' +
    'ives for learners who cannot work online at home.');
  lstLines.Add('');
  lstLines.Add('AI integration opportunities');
  lstLines.Add('');
  lstLines.Add('Cloud computing can develop digital literacy, collaboration, communication, information management a' +
    'nd responsible online behaviour. AI-powered cloud services can assist with explanations and learning' +
    ' support. For example, learners can use an AI tool to receive an explanation of a spreadsheet formul' +
    'a before attempting the task themselves. Teachers should remind learners to verify AI-generated info' +
    'rmation, protect personal data and acknowledge AI use where required');
  lstLines.Add('');
  lstLines.Add('Example classroom activity');
  lstLines.Add('');
  lstLines.Add('Working Together on a Cloud-Based Spreadsheet');
  lstLines.Add('');
  lstLines.Add('Learners work in small groups to create a spreadsheet using an online application. Each learner cont' +
    'ributes information, formats the spreadsheet and adds formulas. The teacher monitors the group''s pro' +
    'gress through the shared document.');
  lstLines.Add('');
  lstLines.Add('Professional recommendation');
  lstLines.Add('');
  lstLines.Add('Cloud computing is highly recommended because it provides practical opportunities for learners to ac' +
    'cess information and collaborate. However, teachers must consider internet access, data costs and on' +
    'line security before introducing cloud-based activities.');
  lstLines.Add('');
  lstLines.Add('3. Comparison of the selected technologies');
  lstLines.Add('');
  lstLines.Add('The six technologies offer different opportunities for CAT and IT education. However, they differ in' +
    ' their educational purpose, resource requirements, curriculum relevance and potential contribution t' +
    'o SDL. Selecting a technology should involve more than considering whether it is new or interesting.' +
    ' Teachers should consider whether it supports the intended learning outcomes and whether it can be i' +
    'mplemented in their school context.');
  lstLines.Add('');
  lstLines.Add('Technology    Main educational contribution    Future-ready skills and SDL    Main implementation' +
    ' challenge');
  lstLines.Add('');
  lstLines.Add('VR    Simulated environments for exploring complex concepts.    Digital literacy, exploration, ind' +
    'ependent investigation and problem-solving.    Cost of headsets and suitable equipment.');
  lstLines.Add('');
  lstLines.Add('AR    Visualises digital representations of real-world objects.    Visual problem-solving, digital' +
    ' literacy and independent exploration.    Access to compatible devices.');
  lstLines.Add('');
  lstLines.Add('IoT    Connects networking concepts to real-life connected devices.    Critical thinking, data awa' +
    'reness, investigation and problem-solving.    Hardware, connectivity and security concerns.');
  lstLines.Add('');
  lstLines.Add('Robotics and automation    Allows learners to create, test and improve programmed instructions.     ' +
    ' Computational thinking, creativity, debugging and collaboration.    Equipment costs and teacher te' +
    'chnical knowledge.');
  lstLines.Add('');
  lstLines.Add('3D printing    Supports digital design and practical solutions.    Creativity, innovation, design ' +
    'thinking and experimentation.    Printer, material and training costs.');
  lstLines.Add('');
  lstLines.Add('Cloud computing    Supports online access, file management and collaboration.    Digital literacy,' +
    ' communication, collaboration and independent learning.    Internet access, data costs and online s' +
    'ecurity.');
  lstLines.Add('');
  lstLines.Add('Affordability is a general comparison, not a verified price ranking. Actual costs depend on the scho' +
    'ol, devices, subscriptions and available infrastructure.');
  lstLines.Add('');
  lstLines.Add('Critical comparison and professional recommendations');
  lstLines.Add('');
  lstLines.Add('Based on the comparison, cloud computing, IoT, AR and robotics offer strong opportunities for CAT an' +
    'd IT education, although their suitability depends on the resources available at the school.');
  lstLines.Add('');
  lstLines.Add('Cloud computing is one of the more practical options where schools have access to computers and inte' +
    'rnet connectivity. It supports application software, digital file management and collaboration. It c' +
    'an also provide opportunities for learners to access learning materials beyond the classroom. Howeve' +
    'r, it cannot be considered equally accessible to all learners because data costs and internet availa' +
    'bility may limit participation.');
  lstLines.Add('');
  lstLines.Add('IoT is particularly relevant because it connects networking concepts to real-life applications. Lear' +
    'ners can investigate smart devices and understand how information is collected and shared. Its use c' +
    'an begin with diagrams, case studies and simulations before schools invest in physical equipment.');
  lstLines.Add('');
  lstLines.Add('AR can help learners understand computer hardware and other difficult concepts through visual repres' +
    'entations. It may be suitable for teacher demonstrations or group activities where only a limited nu' +
    'mber of compatible devices are available. Its effectiveness depends on the quality of the activity a' +
    'nd whether the digital representations support the intended outcomes.');
  lstLines.Add('');
  lstLines.Add('Robotics and automation provide opportunities for learners to apply programming concepts and develop' +
    ' computational thinking. Free simulations such as Open Roberta Lab make it possible to introduce rob' +
    'otics without immediately purchasing physical robots.');
  lstLines.Add('');
  lstLines.Add('VR and 3D printing also have educational value, particularly for experiential learning, digital desi' +
    'gn and practical problem-solving. However, their implementation may be more difficult where schools ' +
    'have limited equipment and funding. Teachers can introduce the concepts through computer-based demon' +
    'strations, videos and digital design platforms before investing in specialised equipment.');
  lstLines.Add('');
  lstLines.Add('No single technology is suitable for every school or learning situation. The choice should depend on' +
    ' learning outcomes, available resources, learner needs and teacher readiness. Technology should not ' +
    'replace effective teaching. Teachers must design activities that encourage learners to think, invest' +
    'igate, practise and reflect.');
  lstLines.Add('');
  lstLines.Add('Alignment with future-ready skills');
  lstLines.Add('');
  lstLines.Add('The selected technologies can contribute to the development of skills that learners need to particip' +
    'ate in a technology-driven society. However, these skills are not developed automatically through ex' +
    'posure to digital tools.');
  lstLines.Add('');
  lstLines.Add('Critical thinking: Learners evaluate information, investigate technological problems and consider po' +
    'ssible solutions.');
  lstLines.Add('');
  lstLines.Add('Problem-solving: Learners use simulations, programming activities and digital design tools to addres' +
    's challenges.');
  lstLines.Add('');
  lstLines.Add('Creativity and innovation: Learners develop digital models, design connected systems and explore new' +
    ' ideas.');
  lstLines.Add('');
  lstLines.Add('Collaboration and communication: Learners work together on projects, share information and explain t' +
    'heir decisions.');
  lstLines.Add('');
  lstLines.Add('Digital literacy: Learners develop an understanding of how technologies operate and how to use them ' +
    'responsibly.');
  lstLines.Add('');
  lstLines.Add('Adaptability and lifelong learning: Learners become more familiar with exploring new tools, finding ' +
    'information and developing skills independently.');
  lstLines.Add('');
  lstLines.Add('These skills should be included in the design of classroom activities. For example, asking learners ' +
    'to explore a VR environment may develop digital awareness, but asking them to investigate a problem,' +
    ' explain their observations and suggest a solution provides a stronger opportunity to develop critic' +
    'al thinking and problem-solving.');
  lstLines.Add('');
  lstLines.Add('Supporting Self-Directed Learning through emerging technologies');
  lstLines.Add('');
  lstLines.Add('SDL is an important consideration when introducing emerging technologies because learners need to de' +
    'velop the ability to take responsibility for their own learning. Knowles (1975) explains that SDL in' +
    'volves identifying learning needs, setting goals, selecting resources, implementing learning strateg' +
    'ies and evaluating outcomes (Knowles, 1975; Garrison, 1997).');
  lstLines.Add('');
  lstLines.Add('The selected technologies can support different parts of this process. VR and AR allow learners to e' +
    'xplore and repeat demonstrations. IoT encourages learners to investigate connected devices and find ' +
    'information about how they work. Robotics allows learners to experiment, identify errors and improve' +
    ' their programmes. 3D modelling gives learners opportunities to develop and evaluate their own desig' +
    'ns. Cloud computing provides access to learning materials and online applications that learners can ' +
    'use beyond the classroom.');
  lstLines.Add('');
  lstLines.Add('Garrison (1997) explains that SDL involves more than allowing learners to work independently. It inc' +
    'ludes self-management, self-monitoring and motivation. This is important when using digital technolo' +
    'gies because learners need to manage learning activities, monitor their understanding and remain mot' +
    'ivated. Therefore, simply providing digital resources will not make learners self-directed. Learners' +
    ' need support to develop the ability to plan, monitor and evaluate their learning.');
  lstLines.Add('');
  lstLines.Add('The teacher therefore remains important in supporting SDL. Teachers should provide clear learning go' +
    'als, suitable resources, guiding questions and feedback. They should gradually allow learners to mak' +
    'e more decisions about how they approach learning activities. This helps learners develop independen' +
    'ce while still receiving the support they need.');
  lstLines.Add('');
  lstLines.Add('Considerations for South African schools');
  lstLines.Add('');
  lstLines.Add('Although emerging technologies offer opportunities for improving teaching and learning, their implem' +
    'entation must consider the realities of South African schools. Access to devices, internet connectiv' +
    'ity, data affordability, electricity and teacher training can influence whether learners benefit fro' +
    'm these technologies.');
  lstLines.Add('');
  lstLines.Add('The Department of Basic Education''s Digital Education Strategy highlights the need to improve access' +
    ' to digital resources, connectivity and teacher training in schools (Department of Basic Education, ' +
    '2025). Digital transformation therefore requires more than introducing new applications. It also req' +
    'uires suitable infrastructure and support for teachers and learners.');
  lstLines.Add('');
  lstLines.Add('Although emerging technologies offer educational benefits, their implementation should consider the ' +
    'realities of South African schools. The Department of Basic Education has been working towards impro' +
    'ving digital education and access to ICT resources in schools.  However, access to technology remain' +
    's uneven. (Parliament of the Republic of South Africa, 2026) reported that only 49% of schools had c' +
    'omputer centres.');
  lstLines.Add('');
  lstLines.Add('Affordability: Teachers should consider free or low-cost platforms before recommending expensive equ' +
    'ipment.');
  lstLines.Add('');
  lstLines.Add('Accessibility: Activities should allow learners to participate even when they do not have personal d' +
    'evices.');
  lstLines.Add('');
  lstLines.Add('Internet connectivity: Teachers should consider offline alternatives or provide school-based access ' +
    'where possible.');
  lstLines.Add('');
  lstLines.Add('Teacher readiness: Educators need opportunities to learn how technologies work and how to integrate ' +
    'them into lessons.');
  lstLines.Add('');
  lstLines.Add('Curriculum alignment: Technologies should support CAPS content and learning outcomes rather than sim' +
    'ply be used because they are interesting.');
  lstLines.Add('');
  lstLines.Add('Learner safety and privacy: Teachers should explain responsible technology use, online security and ' +
    'the risks of sharing personal information.');
  lstLines.Add('');
  lstLines.Add('Sustainability: Schools should consider equipment maintenance, replacement costs and long-term acces' +
    's.');
  lstLines.Add('');
  lstLines.Add('In classrooms where there are not enough computers for every learner, teachers can use group activit' +
    'ies and shared devices. For example, learners can take turns exploring an AR model or work together ' +
    'on an IoT design. Teachers can also use demonstrations, printed diagrams and downloaded learning mat' +
    'erials when internet access is limited. These approaches help ensure that learners are not excluded ' +
    'because of their circumstances.');
  lstLines.Add('');
  lstLines.Add('Overall conclusion');
  lstLines.Add('');
  lstLines.Add('Emerging technologies provide opportunities to improve teaching and learning in Computer Application' +
    's Technology and Information Technology. The six technologies discussed in this chapter offer differ' +
    'ent ways of helping learners understand technological concepts, apply knowledge and develop practica' +
    'l skills. VR and AR support visual and experiential learning, IoT connects networking concepts to re' +
    'al-life devices, robotics supports computational thinking, 3D printing encourages digital design and' +
    ' creativity, while cloud computing supports online access and collaboration.');
  lstLines.Add('');
  lstLines.Add('The discussion also shows that these technologies can contribute to SDL and future-ready skills. Lea' +
    'rners can explore information, practice independently, investigate problems, create digital products' +
    ' and reflect on their progress. However, these benefits depend on how teachers design and guide lear' +
    'ning activities. Technology alone does not guarantee meaningful learning or learner independence.');
  lstLines.Add('');
  lstLines.Add('The CAPS curriculum provides opportunities to connect emerging technologies to existing content, par' +
    'ticularly Systems Technologies, Internet and Network Technologies, programming and the study of new ' +
    'technological developments. Some technologies directly support prescribed content, while others can ' +
    'be used to enrich learning and expose learners to developments beyond the curriculum.');
  lstLines.Add('');
  lstLines.Add('In the South African context, teachers must also consider affordability, connectivity, device availa' +
    'bility and training. Free simulations, shared devices and digital demonstrations can provide practic' +
    'al starting points for schools with limited resources. I therefore recommend that CAT and IT teacher' +
    's introduce emerging technologies gradually and select tools according to their educational value an' +
    'd the needs of their learners. Ultimately, emerging technologies should support meaningful teaching ' +
    'and learning, encourage learner independence and prepare learners to participate responsibly in a ch' +
    'anging digital world. (UNESCO, 2023; Department of Basic Education, 2025).');
  lstLines.Add('');
end;

procedure AddSection4(lstLines: TStrings);
begin
  lstLines.Add('REFERENCING LIST');
  lstLines.Add('');
  lstLines.Add('Abdel‐Basset, M., Manogaran, G., Mohamed, M. and Rushdy, E., 2019. Internet of things in smart educa' +
    'tion environment: Supportive framework in the decision‐making process. Concurrency and Computation: ' +
    'Practice and Experience, 31(10), p.e4515.');
  lstLines.Add('');
  lstLines.Add('Abichandani, P., Sivakumar, V., Lobo, D., Iaboni, C. & Shekhar, P. 2022. Internet-of-Things curricul' +
    'um, pedagogy, and assessment for STEM education: A review of literature. IEEE Access, 10:38351–38369' +
    '. https://doi.org/10.1109/ACCESS.2022.3164709.');
  lstLines.Add('');
  lstLines.Add('Al-Samarraie, H. and Saeed, N., 2018. A systematic review of cloud computing tools for collaborative' +
    ' learning: Opportunities and challenges to the blended-learning environment. Computers & Education, ' +
    '124, pp.77-91. https://doi.org/10.1016/j.compedu.2018.05.016');
  lstLines.Add('');
  lstLines.Add('Arduino. n.d. Arduino Software. Available at: https://www.arduino.cc/en/software/.');
  lstLines.Add('');
  lstLines.Add('Asad, M.M., Naz, A., Churi, P. and Tahanzadeh, M.M., 2021. Virtual reality as pedagogical tool to en' +
    'hance experiential learning: a systematic literature review. Education Research International, 2021(' +
    '1), p.7061623.');
  lstLines.Add('');
  lstLines.Add('Barrón-Hernández, A.R., Castro-Romero, O., Horta-Rangel, F.A. & Ramírez-Díaz, M.H. 2025. Shaping lea' +
    'rning in 3D: Approaching STEM in science education. American Journal of STEM Education. https://doi.' +
    'org/10.32674/sdn45214.');
  lstLines.Add('');
  lstLines.Add('Ching, Y.H. & Hsu, Y.C. 2024. Educational robotics for developing computational thinking in young le' +
    'arners: A systematic review. TechTrends, 68(3):423–434. https://doi.org/10.1007/s11528-023-00841-1.');
  lstLines.Add('');
  lstLines.Add('Conrad, M., Kablitz, D. and Schumann, S., 2024. Learning effectiveness of immersive virtual reality ' +
    'in education and training: A systematic review of findings. Computers & Education: X Reality, 4, p.1' +
    '00053. https://doi.org/10.1016/j.cexr.2024.100053');
  lstLines.Add('');
  lstLines.Add('Dargan, S., Bansal, S., Kumar, M., Mittal, A. and Kumar, K., 2023. Augmented Reality: A Comprehensiv' +
    'e Review: S. Dargan et al. Archives of Computational Methods in Engineering, 30(2), pp.1057-1080.');
  lstLines.Add('');
  lstLines.Add('Deni, A.R.M. and Zainal, Z.I., 2018, October. Padlet as an educational tool: Pedagogical considerati' +
    'ons and lessons learnt. In Proceedings of the 10th International Conference on Education Technology ' +
    'and Computers (pp. 156-162).');
  lstLines.Add('');
  lstLines.Add('Department of Basic Education. 2025. The Digital Education Strategy. Available at: https://www.educa' +
    'tion.gov.za/ArchivedDocuments/ArchivedArticles/TheDigitalEducationStrategy.aspx.');
  lstLines.Add('');
  lstLines.Add('Fraunhofer IAIS. n.d. Open Roberta Lab. Available at: https://lab.open-roberta.org/.');
  lstLines.Add('');
  lstLines.Add('Garrison, D.R., 1997. Self-directed learning: Toward a comprehensive model. Adult education quarterl' +
    'y, 48(1), pp.18-33. https://doi.org/10.1177/074171369704800103');
  lstLines.Add('');
  lstLines.Add('Google for Education. n.d. Google Workspace for Education. Available at: https://edu.google.com/work' +
    'space-for-education/.');
  lstLines.Add('');
  lstLines.Add('Graham, M. and Dutton, W.H. eds., 2019. Society and the internet: How networks of information and co' +
    'mmunication are changing our lives. Oxford University Press.');
  lstLines.Add('');
  lstLines.Add('Huang R, Adarkwah MA, Liu M, Hu Y, Zhuang R, Chang T. Digital pedagogy for sustainable education tra' +
    'nsformation: Enhancing learner-centred learning in the digital era. Frontiers of Digital Education. ' +
    '2024 Dec;1(4):279-94.');
  lstLines.Add('');
  lstLines.Add('Hussaini, I., Ibrahim, S., Wali, B., Libata, I. and Musa, U., 2020. Effectiveness of Google classroo' +
    'm as a digital tool in teaching and learning: Students’ perceptions. International Journal of Resear' +
    'ch and Innovation in Social Science (IJRISS), 4(4), pp.51-54.');
  lstLines.Add('');
  lstLines.Add('Iftakhar, S., 2016. Google classroom: what works and how. Journal of education and social sciences, ' +
    '3(1), pp.12-18.');
  lstLines.Add('');
  lstLines.Add('Kasneci, E., Sessler, K., Küchemann, S., Bannert, M., Dementieva, D., Fischer, F., Gasser, U., Groh,' +
    ' G., Günnemann, S., Hüllermeier, E. & Krusche, S., 2023. ChatGPT for good? On opportunities and chal' +
    'lenges of large language models for education. Learning and Individual Differences, 103, pp.1-15.');
  lstLines.Add('');
  lstLines.Add('Knowles, M.S., 1975. Self-directed learning (Vol. 291). New York: association press.');
  lstLines.Add('');
  lstLines.Add('Knowles, M.S., Holton, E.F. & Swanson, R.A., 2020. The adult learner. 9th ed. New York: Routledge.');
  lstLines.Add('');
  lstLines.Add('Knowles, M.S., Holton, E.F. and Swanson, R.A. (2020). The Adult Learner: The Definitive Classic in A' +
    'dult Education and Human Resource Development. 9th ed. New York: Routledge.');
  lstLines.Add('');
  lstLines.Add('Lin, Y. & Yu, Z. 2023. A meta-analysis of the effects of augmented reality technologies in interacti' +
    've learning environments (2012–2022). Computer Applications in Engineering Education, 31(4):1111–113' +
    '1. https://doi.org/10.1002/cae.22628.');
  lstLines.Add('');
  lstLines.Add('Marougkas, A., Troussas, C., Krouska, A. & Sgouropoulou, C. 2024. How personalized and effective is ' +
    'immersive virtual reality in education? A systematic literature review for the last decade. Multimed' +
    'ia Tools and Applications, 83:18185–18233. https://doi.org/10.1007/s11042-023-15986-7.');
  lstLines.Add('');
  lstLines.Add('Mishra, P. & Koehler, M.J., 2006. Technological pedagogical content knowledge: A framework for teach' +
    'er knowledge. Teachers College Record, 108(6), pp.1017-1054.');
  lstLines.Add('');
  lstLines.Add('Mishra, P. and Koehler, M.J. (2006). Technological pedagogical content knowledge: A framework for te' +
    'acher knowledge. Teachers College Record, 108(6), pp. 1017–1054.');
  lstLines.Add('');
  lstLines.Add('Mthembu, N., the technology hurdles: challenges south African teachers face in integrating 4IR techn' +
    'ology into. education, 21(107), p. e4546. ORCID: https://orcid.org/0000-0002-6950-2805');
  lstLines.Add('');
  lstLines.Add('Padayachee, K., 2017. A snapshot survey of ICT integration in South African schools. South African C' +
    'omputer Journal, 29(2), pp.36-65.');
  lstLines.Add('');
  lstLines.Add('Pakman, A., Pakman, N. and Samur, Y., 2023. The Effects of Coding, Robotics, 3D Design and Game Desi' +
    'gn Education on 21st Century Skills of Primary School Students. Turkish Online Journal of Educationa' +
    'l Technology-TOJET, 22(3), pp.109-124.');
  lstLines.Add('');
  lstLines.Add('Parliament of the Republic of South Africa. 2026. Education Committee concerned about gap between sc' +
    'hool infrastructure reports and conditions observed. Available at: https://parliament.gov.za/press-r' +
    'eleases/media-statement-education-committee-concerned-about-gap-between-school-infrastructure-report' +
    's-and-conditions-observed.');
  lstLines.Add('');
  lstLines.Add('Parliament of the Republic of South Africa. 2026. Media statement: Education Committee concerned abo' +
    'ut gap between school infrastructure reports and conditions observed. https://www.parliament.gov.za/' +
    'press-releases/media-statement-education-committee-concerned-about-gap-between-school-infrastructure' +
    '-reports-and-conditions-observed Date of access: 6 Nov. 2026.');
  lstLines.Add('');
  lstLines.Add('Piaget, J. (1972). The Psychology of the Child. New York: Basic Books.');
  lstLines.Add('');
  lstLines.Add('Piaget, J., 1972. The psychology of the child. New York: Basic Books.');
  lstLines.Add('');
  lstLines.Add('Poupard, M., Larrue, F., Sauzéon, H. and Tricot, A., 2025. A systematic review of immersive technolo' +
    'gies for education: Learning performance, cognitive load and intrinsic motivation. British Journal o' +
    'f Educational Technology, 56(1), pp.5-41. https://doi.org/10.1111/bjet.13503');
  lstLines.Add('');
  lstLines.Add('Puentedura, R.R., 2014. SAMR and TPACK: A hands-on approach to classroom practice. Boston: Hippasus ' +
    'Educational Consulting.');
  lstLines.Add('');
  lstLines.Add('Shahid, F., Aleem, M., Islam, M.A., Iqbal, M.A. and Yousaf, M.M., 2019. A review of technological to' +
    'ols in teaching and learning computer science. Eurasia journal of mathematics, science and technolog' +
    'y Education, 15(11), p.em1773.');
  lstLines.Add('');
  lstLines.Add('Siemens, G. (2005). Connectivism: A learning theory for the digital age. International Journal of In' +
    'structional Technology and Distance Learning, 2(1).');
  lstLines.Add('');
  lstLines.Add('Siemens, G., 2005. Connectivism: A learning theory for the digital age. International Journal of Ins' +
    'tructional Technology and Distance Learning, 2(1), pp.3-10.');
  lstLines.Add('');
  lstLines.Add('Tejera, M., Galiç, S. and Lavicza, Z., 2026. 3D modelling and printing in teacher education: A syste' +
    'matic literature review. Journal for STEM Education Research, 9(1), pp.1-32. https://doi.org/10.1007' +
    '/s41979-025-00147-2');
  lstLines.Add('');
  lstLines.Add('Tomasik, M.J., Berger, S. and Moser, U., 2018. On the development of a computer-based tool for forma' +
    'tive student assessment: Epistemological, methodological, and practical issues. Frontiers in psychol' +
    'ogy, 9, p.2245.');
  lstLines.Add('');
  lstLines.Add('van Zyl, S. and Bailey, R., 2025. Technology-supported cooperative learning to promote deeper self-d' +
    'irected learning in computer science education. South African Journal of Education, 45(si1), pp.S1-S' +
    '10.');
  lstLines.Add('');
  lstLines.Add('Vygotsky, L.S. (1978). Mind in Society: The Development of Higher Psychological Processes. Cambridge' +
    ', MA: Harvard University Press.');
  lstLines.Add('');
  lstLines.Add('Vygotsky, L.S., 1978. Mind in society: The development of higher psychological processes. Cambridge,' +
    ' MA: Harvard University Press.');
  lstLines.Add('');
  lstLines.Add('World Economic Forum, 2023. The Future of Jobs Report 2023. Geneva: World Economic Forum.');
  lstLines.Add('');
  lstLines.Add('World Economic Forum. (2023). The Future of Jobs Report 2023. Geneva: World Economic Forum.');
  lstLines.Add('');
end;

procedure LoadPaperSection(iSection: Integer; lstLines: TStrings);
begin
  case iSection of
    1: AddSection1(lstLines);
    2: AddSection2(lstLines);
    3: AddSection3(lstLines);
    4: AddSection4(lstLines);
  end;
end;

end.
