﻿unit CAT_U;

interface

uses
  Winapi.Messages, Winapi.Windows, Winapi.ShellAPI, System.Classes, System.SysUtils, System.IOUtils, System.Types,
  System.UITypes, Vcl.Forms, Vcl.Controls, Vcl.StdCtrls,
  Vcl.ExtCtrls, Vcl.ComCtrls, Vcl.Dialogs, Vcl.Graphics, Curriculum_U, Activities_U, Paper_U;

type
  TfrmCAT = class(TForm)
    pnlHeader: TPanel;
    shpHeaderAccent: TShape;
    lblBrand: TLabel;
    lblAudience: TLabel;
    pnlSidebar: TPanel;
    lblBrowse: TLabel;
    lblSearch: TLabel;
    edtSearch: TEdit;
    lblCategory: TLabel;
    cmbCategory: TComboBox;
    lblMatch: TLabel;
    lstActivity: TListBox;
    lblCompletion: TLabel;
    prgCompletion: TProgressBar;
    btnHome: TButton;
    pgcMain: TPageControl;
    tabIntro: TTabSheet;
    lblWelcome: TLabel;
    memIntroduction: TMemo;
    btnStart: TButton;
    tabGuide: TTabSheet;
    lblGuideCategory: TLabel;
    lblGuideTitle: TLabel;
    redGuide: TRichEdit;
    btnOpenQuiz: TButton;
    btnOpenPlan: TButton;
    tabQuiz: TTabSheet;
    lblQuizTitle: TLabel;
    lblQuizStep: TLabel;
    prgQuiz: TProgressBar;
    lblQuestion: TLabel;
    rgpAnswers: TRadioGroup;
    memFeedback: TMemo;
    btnCheck: TButton;
    btnNext: TButton;
    btnRetry: TButton;
    tabPlan: TTabSheet;
    lblPlanTitle: TLabel;
    lblPlanSubject: TLabel;
    lblSubjectGrade: TLabel;
    btnSubjectMenu: TButton;
    tabCurriculum: TTabSheet;
    lblCurriculum: TLabel;
    lblCurrGrade: TLabel;
    cmbCurrGrade: TComboBox;
    lblCurrTerm: TLabel;
    cmbCurrTerm: TComboBox;
    lblDocument: TLabel;
    cmbDocument: TComboBox;
    memCurriculum: TMemo;
    lblCurrCheck: TLabel;
    cmbCurrCheck: TComboBox;
    btnCurrCheck: TButton;
    lblCurrFeedback: TLabel;
    btnOfficial: TButton;
    btnSupportingDocument: TButton;
    btnCircular: TButton;
    btnPAT: TButton;
    btnATPIndex: TButton;
    tabBot: TTabSheet;
    lblBotTitle: TLabel;
    lblBotPrompt: TLabel;
    cmbBotPrompt: TComboBox;
    lblBotQuestion: TLabel;
    edtBotQuestion: TEdit;
    btnAsk: TButton;
    btnClearBot: TButton;
    memBot: TMemo;
    dlgATP: TOpenDialog;
    lblGrade: TLabel;
    cmbGrade: TComboBox;
    lblAccess: TLabel;
    cmbAccess: TComboBox;
    btnGenerate: TButton;
    memPlan: TMemo;
    btnExport: TButton;
    lblPlanStatus: TLabel;
    btnTopicResource, btnTopicReference, btnOpenPaper: TButton;
    tabPaper: TTabSheet;
    lblPaperTitle: TLabel;
    redPaper: TRichEdit;
    cmbPaper: TComboBox;
    procedure cmbPaperChange(Sender: TObject);
    procedure lstActivityDrawItem(ctlList: TWinControl; iIndex: Integer;
      recBounds: TRect; setDrawState: TOwnerDrawState);
    procedure btnTopicReferenceClick(Sender: TObject);
    procedure btnOpenPaperClick(Sender: TObject);
    procedure btnSubjectMenuClick(Sender: TObject);
    procedure cmbCurrGradeChange(Sender: TObject);
    procedure cmbCurrTermChange(Sender: TObject);
    procedure cmbDocumentChange(Sender: TObject);
    procedure btnOfficialClick(Sender: TObject);
    procedure btnSupportingDocumentClick(Sender: TObject);
    procedure btnCircularClick(Sender: TObject);
    procedure btnPATClick(Sender: TObject);
    procedure btnATPIndexClick(Sender: TObject);
    procedure btnCurrCheckClick(Sender: TObject);
    procedure cmbBotPromptChange(Sender: TObject);
    procedure edtBotQuestionKeyPress(Sender: TObject; var cKey: Char);
    procedure btnAskClick(Sender: TObject);
    procedure btnClearBotClick(Sender: TObject);
    procedure FormCloseQuery(Sender: TObject; var bCanClose: Boolean);
    procedure edtSearchChange(Sender: TObject);
    procedure cmbCategoryChange(Sender: TObject);
    procedure lstActivityClick(Sender: TObject);
    procedure btnHomeClick(Sender: TObject);
    procedure btnStartClick(Sender: TObject);
    procedure btnTopicResourceClick(Sender: TObject);
    procedure btnOpenQuizClick(Sender: TObject);
    procedure btnOpenPlanClick(Sender: TObject);
    procedure rgpAnswersClick(Sender: TObject);
    procedure btnCheckClick(Sender: TObject);
    procedure btnNextClick(Sender: TObject);
    procedure btnRetryClick(Sender: TObject);
    procedure btnGenerateClick(Sender: TObject);
    procedure memPlanChange(Sender: TObject);
    procedure btnExportClick(Sender: TObject);
  private
    iSelectedSubject: Integer;
    arrLocalATP: array[10..12] of string;
    iCurrentTopic: Integer;
    arrVisibleTopics: array[0..iActivityCount - 1] of Integer;
    arrCompleted: array[1..iActivityCount] of Boolean;
    iQuestionIndex, iQuizScore: Integer;
    bAnswered, bQuizFinished, bPlanDirty: Boolean;
    procedure RefreshCurriculum;
    procedure RefreshPaper;
    procedure OpenResource(const sResource: string);
    procedure FilterActivities;
    procedure SelectEntry(iTopic: Integer);
    procedure UpdateCompletion;
    procedure ResetQuiz;
    procedure ShowQuestion;
  public
    procedure Initialize(iSubject: Integer);
  end;

var
  frmCAT: TfrmCAT;  // Form Designer reference. Login opens session instances.

implementation

{$R *.dfm}

const
  clSlate = TColor($00273338);
  clSand = TColor($00E5EDF5);
  clOchre = TColor($007BCADF);
  clMintFeedback = TColor($00E6F4E4);
  clAmberFeedback = TColor($00E5F2FF);

function ContainsSearchText(const sText, sQuery: string): Boolean;
var
  iStart, iQueryLength: Integer;
begin
  // Match text with a first-principles loop and basic string operations.
  // Check each possible position using a loop instead of a search routine.
  iQueryLength := Length(sQuery);
  if iQueryLength = 0 then
    Exit(True);

  for iStart := 1 to Length(sText) - iQueryLength + 1 do
  begin
    if Copy(sText, iStart, iQueryLength) = sQuery then
      Exit(True);
  end;
  Result := False;
end;

procedure SetOptions(cmbBox: TComboBox; const arrOptions: array of string);
var
  sOption: string;
begin
  // Populate a selection control with the supplied display labels.
  for sOption in arrOptions do
    cmbBox.Items.Add(sOption);
  cmbBox.ItemIndex := 0;
end;

procedure TfrmCAT.Initialize(iSubject: Integer);
var
  iTopic: Integer;
begin
  // Configure the inherited subject design before loading its activities.
  iSelectedSubject := iSubject;
  Caption := 'Beyond the Computer Lab (' + arrSubject[iSelectedSubject] + ')';
  lblAudience.Caption := arrSubjectName[iSelectedSubject];
  lblSubjectGrade.Caption := arrSubject[iSelectedSubject] + ' for Grades 10-12';
  lblPlanSubject.Caption := arrSubject[iSelectedSubject];
  SetOptions(cmbCategory, ['All technologies', sTeachingCategory, sEmergingCategory]);
  SetOptions(cmbGrade, ['10', '11', '12']);
  SetOptions(cmbPaper, ['Activity reference and reading guide',
    'Chapter 1. Artificial intelligence',
    'Chapter 2. Teaching, assessment and collaboration',
    'Chapter 3. Emerging technologies and future trends',
    'Referencing list']);
  SetOptions(cmbAccess, ['Connected devices', 'Offline / shared devices']);
  SetOptions(cmbCurrGrade, ['10', '11', '12']);
  SetOptions(cmbCurrTerm, ['1', '2', '3', '4']);
  SetOptions(cmbDocument, ['CAPS policy guide', 'ATP planning guide']);
  for iTopic := Low(arrFAQ) to High(arrFAQ) do
    if (arrFAQ[iTopic].iSubject = 0) or (arrFAQ[iTopic].iSubject = iSelectedSubject) then
      cmbBotPrompt.Items.Add(arrFAQ[iTopic].sPrompt);

  // Start on an introduction specific to the selected teaching subject.
  memIntroduction.Text :=
    'Welcome to the ' + arrSubject[iSelectedSubject] + ' workspace.' + sLineBreak +
    sLineBreak + arrIntro[iSelectedSubject] + sLineBreak + sLineBreak +
    '1. Open CAPS and ATP. Select your grade and use the policy guide to ' +
    'identify the skill. In ATP mode, select your term and open the applicable grade plan.' +
    sLineBreak + sLineBreak +
    '2. Browse the technology guide. Read the subject application and choose ' +
    'a tool that fits your learning goal, devices and connectivity. Check your ' +
    'understanding in the section quiz.' + sLineBreak + sLineBreak +
    '3. Generate and adapt a lesson plan. Choose the grade and access ' +
    'level. Edit and export the result as a text file.' + sLineBreak + sLineBreak +
    '4. Use Teacher FAQ for PAT, SBA, shared computers and moderation.' +
    sLineBreak + sLineBreak +
    '5. Open Academic paper when you want to see where an activity came from.';
  prgCompletion.Max := iActivityCount;
  FilterActivities;
  UpdateCompletion;
  RefreshCurriculum;
  btnClearBotClick(nil);
  pgcMain.ActivePage := tabIntro;
end;

procedure TfrmCAT.edtSearchChange(Sender: TObject);
begin
  // Apply the current search phrase as the teacher types.
  FilterActivities;
end;

procedure TfrmCAT.cmbCategoryChange(Sender: TObject);
begin
  // Apply the selected technology category.
  FilterActivities;
end;

procedure TfrmCAT.FilterActivities;
var
  iTopic, iSelected, iRow: Integer;
  sQuery, sLabel: string;
  recTopic: TActivity;
begin
  if iSelectedSubject = 0 then
    Exit;
  sQuery := LowerCase(Trim(edtSearch.Text));
  iSelected := -1;
  lstActivity.Items.BeginUpdate;
  try
    lstActivity.Clear;
    for iTopic := 1 to iActivityCount do
    begin
      recTopic := arrActivities[iTopic];
      if (cmbCategory.ItemIndex > 0) and
        (cmbCategory.Text <> recTopic.sCategory) then
        Continue;
      if not ContainsSearchText(LowerCase(recTopic.sName + ' ' + recTopic.sPurpose +
        ' ' + recTopic.arrCAPS[iSelectedSubject] + ' ' + recTopic.arrTask[iSelectedSubject]), sQuery) then
        Continue;

      iRow := lstActivity.Items.Count;
      arrVisibleTopics[iRow] := iTopic;
      if iTopic = iCurrentTopic then
        iSelected := iRow;
      sLabel := recTopic.sName;
      if arrCompleted[iTopic] then
        sLabel := sLabel + ' [done]';
      lstActivity.Items.Add(sLabel);
    end;
    if (iSelected < 0) and (lstActivity.Items.Count > 0) then
      iSelected := 0;
    lstActivity.ItemIndex := iSelected;
  finally
    lstActivity.Items.EndUpdate;
  end;
  lblMatch.Caption := Format('%d activities', [lstActivity.Items.Count]);
  if iSelected < 0 then
    SelectEntry(0)
  else
    SelectEntry(arrVisibleTopics[iSelected]);
end;

procedure TfrmCAT.SelectEntry(iTopic: Integer);
var
  recTopic: TActivity;

  procedure AddSection(const sHeading, sText: string);
  begin
    redGuide.SelStart := redGuide.GetTextLen;
    redGuide.SelLength := 0;
    redGuide.SelAttributes.Color := clSlate;
    redGuide.SelAttributes.Style := [fsBold];
    redGuide.SelText := sHeading + sLineBreak;
    redGuide.SelAttributes.Color := clWindowText;
    redGuide.SelAttributes.Style := [];
    redGuide.SelText := sText + sLineBreak + sLineBreak;
  end;

begin
  btnTopicResource.Enabled := iTopic > 0;
  btnTopicReference.Enabled := iTopic > 0;
  btnOpenQuiz.Enabled := iTopic > 0;
  btnOpenPlan.Enabled := iTopic > 0;
  btnGenerate.Enabled := iTopic > 0;
  if (iCurrentTopic = iTopic) and (iTopic > 0) then
    Exit;
  iCurrentTopic := iTopic;
  if cmbPaper.ItemIndex = 0 then
    RefreshPaper;
  if iTopic = 0 then
  begin
    lblGuideCategory.Caption := 'Activity library';
    lblGuideTitle.Caption := 'No matching activities';
    redGuide.Text := 'Try a different search or choose All technologies.';
    ResetQuiz;
    Exit;
  end;

  recTopic := arrActivities[iTopic];
  lblGuideCategory.Caption := recTopic.sCategory;
  lblGuideTitle.Caption := recTopic.sName;
  redGuide.ReadOnly := False;
  redGuide.Lines.BeginUpdate;
  try
    redGuide.Clear;
    AddSection('CAPS FOCUS', recTopic.arrCAPS[iSelectedSubject]);
    AddSection('BEFORE CLASS', recTopic.sGuidance);
    AddSection('MODEL THE TASK (5 MINUTES)', recTopic.arrExample[iSelectedSubject]);
    AddSection(arrSubject[iSelectedSubject] + ' CLASSROOM IMPLEMENTATION',
      recTopic.arrImplementation[iSelectedSubject]);
    AddSection('INDIVIDUAL EXIT CHECK (5 MINUTES)', recTopic.arrEvidence[iSelectedSubject]);
    AddSection('OFFLINE OR SHARED COMPUTERS', recTopic.arrOffline[iSelectedSubject]);
    AddSection('WHEN TO USE THIS TOOL', recTopic.sLimits);
    AddSection('INDEPENDENT FOLLOW-UP',
      'Ask each learner to choose one part to practise, predict the result, ' +
      'test it independently and explain what they would change next.');
    AddSection('ADDITIONAL RESOURCE', recTopic.sResourceName);
    AddSection('ACADEMIC REFERENCE', recTopic.sPaperSection +
      '. Open the Academic paper tab for the rationale and full assignment.');
  finally
    redGuide.Lines.EndUpdate;
    redGuide.ReadOnly := True;
  end;
  redGuide.SelStart := 0;
  redGuide.Perform(EM_SCROLLCARET, 0, 0);
  ResetQuiz;
end;

procedure TfrmCAT.lstActivityClick(Sender: TObject);
begin
  if lstActivity.ItemIndex < 0 then
    Exit;
  SelectEntry(arrVisibleTopics[lstActivity.ItemIndex]);
  pgcMain.ActivePage := tabGuide;
end;

procedure TfrmCAT.btnTopicResourceClick(Sender: TObject);
begin
  if iCurrentTopic > 0 then
    OpenResource(arrActivities[iCurrentTopic].sResourceURL);
end;

procedure TfrmCAT.lstActivityDrawItem(ctlList: TWinControl; iIndex: Integer;
  recBounds: TRect; setDrawState: TOwnerDrawState);
var
  recMarker: TRect;
begin
  if iIndex < 0 then
    Exit;
  lstActivity.Canvas.Font.Assign(lstActivity.Font);
  lstActivity.Canvas.Brush.Color := clSand;
  lstActivity.Canvas.Font.Color := clSlate;
  if odSelected in setDrawState then
  begin
    lstActivity.Canvas.Brush.Color := clSlate;
    lstActivity.Canvas.Font.Color := clWhite;
  end;
  lstActivity.Canvas.FillRect(recBounds);
  if odSelected in setDrawState then
  begin
    recMarker := recBounds;
    recMarker.Right := recMarker.Left + 4;
    lstActivity.Canvas.Brush.Color := clOchre;
    lstActivity.Canvas.FillRect(recMarker);
  end;
  Inc(recBounds.Left, 10);
  Dec(recBounds.Right, 4);
  DrawText(lstActivity.Canvas.Handle, PChar(lstActivity.Items[iIndex]), -1, recBounds,
    DT_LEFT or DT_VCENTER or DT_SINGLELINE or DT_END_ELLIPSIS or DT_NOPREFIX);
  if odFocused in setDrawState then
    lstActivity.Canvas.DrawFocusRect(recBounds);
end;

procedure TfrmCAT.RefreshPaper;
var
  recTopic: TActivity;
begin
  redPaper.Lines.BeginUpdate;
  try
    redPaper.Clear;
    if iCurrentTopic > 0 then
    begin
      recTopic := arrActivities[iCurrentTopic];
      redPaper.Lines.Add('SELECTED ACTIVITY');
      redPaper.Lines.Add(recTopic.sName);
      redPaper.Lines.Add(recTopic.sPaperSection);
      redPaper.Lines.Add(recTopic.sRationale);
      redPaper.Lines.Add('');
    end;
    redPaper.Lines.Add('READ THE GROUP ASSIGNMENT');
    redPaper.Lines.Add('Chapter 1 covers AI in CAT and IT, including SDL, scaffolding, ' +
      'TPACK and curriculum alignment. Start with Theoretical and pedagogical foundations.');
    redPaper.Lines.Add('');
    redPaper.Lines.Add('Chapter 2 examines teaching, assessment and collaboration tools. ' +
      'See Educational theory and justification and the named platform sections.');
    redPaper.Lines.Add('');
    redPaper.Lines.Add('Chapter 3 evaluates emerging technologies. See Alignment with future-ready skills, ' +
      'Supporting Self-Directed Learning through emerging technologies and the named technology sections.');
    redPaper.Lines.Add('');
    redPaper.Lines.Add('The paper ends with the Referencing List. Use CAPS and ATP ' +
      'for the curriculum documents, and Additional resource for each technology guide.');
  finally
    redPaper.Lines.EndUpdate;
  end;
  redPaper.SelStart := 0;
  redPaper.Perform(EM_SCROLLCARET, 0, 0);
end;

procedure TfrmCAT.cmbPaperChange(Sender: TObject);
begin
  if cmbPaper.ItemIndex <= 0 then
  begin
    RefreshPaper;
    Exit;
  end;
  redPaper.Lines.BeginUpdate;
  try
    redPaper.Clear;
    LoadPaperSection(cmbPaper.ItemIndex, redPaper.Lines);
  finally
    redPaper.Lines.EndUpdate;
  end;
  redPaper.SelStart := 0;
  redPaper.Perform(EM_SCROLLCARET, 0, 0);
end;

procedure TfrmCAT.btnTopicReferenceClick(Sender: TObject);
begin
  cmbPaper.ItemIndex := 0;
  RefreshPaper;
  pgcMain.ActivePage := tabPaper;
end;

procedure TfrmCAT.btnOpenPaperClick(Sender: TObject);
const
  sPaperName = 'CSIE_Assignment3_2026.docx';
var
  sFolder, sPaper: string;
begin
  sFolder := ExtractFilePath(ParamStr(0));
  sPaper := TPath.Combine(sFolder, sPaperName);
  if not TFile.Exists(sPaper) then
    sPaper := TPath.GetFullPath(TPath.Combine(sFolder, '..\..\' + sPaperName));
  if TFile.Exists(sPaper) then
    OpenResource(sPaper)
  else
    MessageDlg('Extract the full project ZIP or place ' + sPaperName +
      ' next to the program executable.', mtInformation, [mbOK], 0);
end;

procedure TfrmCAT.btnHomeClick(Sender: TObject);
begin
  // Return to the subject introduction.
  pgcMain.ActivePage := tabIntro;
end;

procedure TfrmCAT.btnStartClick(Sender: TObject);
begin
  // Move from the introduction to the technology guide.
  pgcMain.ActivePage := tabGuide;
  lstActivity.SetFocus;
end;

procedure TfrmCAT.btnOpenQuizClick(Sender: TObject);
begin
  // Open the knowledge check for the current section.
  pgcMain.ActivePage := tabQuiz;
end;

procedure TfrmCAT.btnOpenPlanClick(Sender: TObject);
begin
  // Open the editable lesson planner.
  pgcMain.ActivePage := tabPlan;
end;

procedure TfrmCAT.ResetQuiz;
begin
  // Clear the current attempt and return to the first question.
  iQuestionIndex := 0;
  iQuizScore := 0;
  bQuizFinished := False;
  ShowQuestion;
end;

procedure TfrmCAT.ShowQuestion;
var
  recQuestion: TQuestion;
  iChoice: Integer;
begin
  // Display the next question, options and visual progress.
  bAnswered := False;
  btnCheck.Enabled := False;
  btnNext.Enabled := False;
  btnNext.Caption := '&Next question';
  memFeedback.Color := clWindow;
  memFeedback.Clear;
  rgpAnswers.Items.Clear;
  rgpAnswers.ItemIndex := -1;
  rgpAnswers.Enabled := iCurrentTopic > 0;
  btnRetry.Enabled := iCurrentTopic > 0;
  prgQuiz.Position := 0;
  if iCurrentTopic = 0 then
  begin
    lblQuizTitle.Caption := 'Section quiz';
    lblQuizStep.Caption := '';
    lblQuestion.Caption := 'Choose an activity to load its quiz.';
    Exit;
  end;
  prgQuiz.Max := iQuestionCount;
  prgQuiz.Position := iQuestionIndex;
  lblQuizTitle.Caption := arrActivities[iCurrentTopic].sName;
  lblQuizStep.Caption := Format('Question %d of %d', [iQuestionIndex + 1, iQuestionCount]);
  recQuestion := arrActivities[iCurrentTopic].arrQuiz[iSelectedSubject][iQuestionIndex];
  lblQuestion.Caption := recQuestion.sPrompt;
  for iChoice := Low(recQuestion.arrChoices) to High(recQuestion.arrChoices) do
    rgpAnswers.Items.Add(recQuestion.arrChoices[iChoice]);
  rgpAnswers.ItemIndex := -1;
end;

procedure TfrmCAT.rgpAnswersClick(Sender: TObject);
begin
  // Enable checking only after the teacher has chosen an option.
  btnCheck.Enabled := (iCurrentTopic > 0) and not bAnswered and
    not bQuizFinished and (rgpAnswers.ItemIndex >= 0);
end;

procedure TfrmCAT.btnCheckClick(Sender: TObject);
var
  recQuestion: TQuestion;
  iCorrect: Integer;
begin
  // Score a single answer and show the explanation immediately.
  if (iCurrentTopic = 0) or bAnswered or bQuizFinished or
    (rgpAnswers.ItemIndex < 0) then
    Exit;

  // Lock the response before scoring so each question counts only once.
  bAnswered := True;
  recQuestion := arrActivities[iCurrentTopic].arrQuiz[iSelectedSubject][iQuestionIndex];
  iCorrect := recQuestion.iCorrect;
  if rgpAnswers.ItemIndex = iCorrect then
  begin
    Inc(iQuizScore);
    memFeedback.Color := clMintFeedback;
    memFeedback.Text := 'Correct.' + sLineBreak + recQuestion.sFeedback;
  end
  else
  begin
    memFeedback.Color := clAmberFeedback;
    memFeedback.Text := 'Correct answer: ' + rgpAnswers.Items[iCorrect] +
      sLineBreak + recQuestion.sFeedback;
  end;

  prgQuiz.Position := iQuestionIndex + 1;
  btnNext.Enabled := True;
  if prgQuiz.Position = prgQuiz.Max then
    btnNext.Caption := '&View results';
  btnNext.SetFocus;
  btnCheck.Enabled := False;
  rgpAnswers.Enabled := False;
end;

procedure TfrmCAT.btnNextClick(Sender: TObject);
begin
  // Advance the quiz or display the final score and completion status.
  if not bAnswered or bQuizFinished then
    Exit;
  if iQuestionIndex + 1 < iQuestionCount then
  begin
    Inc(iQuestionIndex);
    ShowQuestion;
    Exit;
  end;

  // Record completion once per activity, even if the teacher retakes its quiz.
  bQuizFinished := True;
  arrCompleted[iCurrentTopic] := True;
  UpdateCompletion;
  FilterActivities;
  lblQuizStep.Caption := 'Quiz complete';
  memFeedback.Color := clMintFeedback;
  lblQuestion.Caption := Format('You scored %d out of %d.', [iQuizScore, iQuestionCount]);
  rgpAnswers.Items.Clear;
  memFeedback.Text := 'Return to the guide to review the section, or restart the quiz to practise.';
  btnRetry.SetFocus;
  btnNext.Enabled := False;
end;

procedure TfrmCAT.btnRetryClick(Sender: TObject);
begin
  // Confirm before discarding an unfinished quiz attempt.
  if ((iQuestionIndex > 0) or bAnswered) and not bQuizFinished then
    if MessageDlg('Restart this quiz and clear the current answers?',
      mtConfirmation, [mbYes, mbNo], 0) <> mrYes then
      Exit;
  ResetQuiz;
end;

procedure TfrmCAT.UpdateCompletion;
var
  iTopic, iCount: Integer;
begin
  iCount := 0;
  for iTopic := 1 to iActivityCount do
    if arrCompleted[iTopic] then
      Inc(iCount);
  // Refresh the subject completion bar and count.
  prgCompletion.Position := iCount;
  lblCompletion.Caption := Format('%d of %d section quizzes completed',
    [iCount, iActivityCount]);
end;

procedure TfrmCAT.btnGenerateClick(Sender: TObject);
var
  sRoute: string;
  recTopic: TActivity;

  procedure AddPlanSection(const sHeading, sText: string);
  begin
    memPlan.Lines.Add(sHeading);
    memPlan.Lines.Add(sText);
    memPlan.Lines.Add('');
  end;

begin
  // Build an editable lesson outline for the chosen grade and classroom access.
  if iCurrentTopic = 0 then
    Exit;
  if bPlanDirty and (MessageDlg('Replace the current unsaved lesson plan?',
    mtConfirmation, [mbYes, mbNo], 0) <> mrYes) then
    Exit;

  recTopic := arrActivities[iCurrentTopic];
  sRoute := recTopic.arrImplementation[iSelectedSubject];
  if cmbAccess.ItemIndex = 1 then
    sRoute := recTopic.arrOffline[iSelectedSubject];

  memPlan.Lines.BeginUpdate;
  try
    memPlan.Clear;
    memPlan.Lines.Add(Format('%s (Grade %s %s)',
      [recTopic.sName, cmbGrade.Text, arrSubject[iSelectedSubject]]));
    memPlan.Lines.Add(cmbAccess.Text);
    memPlan.Lines.Add('');
    AddPlanSection('CAPS FOCUS', recTopic.arrCAPS[iSelectedSubject] + sLineBreak +
      'Confirm grade and term placement in CAPS and the ATP.');
    AddPlanSection('BEFORE CLASS', recTopic.sGuidance);
    AddPlanSection('MODEL THE TASK', recTopic.arrExample[iSelectedSubject]);
    AddPlanSection('CLASSROOM ACTIVITY', sRoute);
    AddPlanSection('ASSESSMENT EVIDENCE', recTopic.arrEvidence[iSelectedSubject]);
    AddPlanSection('EXIT TICKET', 'Set one practice goal. Test an example and explain what you will try next.');
    AddPlanSection('ADDITIONAL RESOURCE', recTopic.sResourceName + sLineBreak + recTopic.sResourceURL);
    AddPlanSection('ACADEMIC PAPER', recTopic.sPaperSection);
  finally
    memPlan.Lines.EndUpdate;
  end;
  memPlanChange(nil);
  memPlan.SetFocus;
  memPlan.SelStart := 0;
end;

procedure TfrmCAT.memPlanChange(Sender: TObject);
begin
  // Track changes and enable export when the plan contains text.
  bPlanDirty := True;
  btnExport.Enabled := Trim(memPlan.Text) <> '';
  lblPlanStatus.Font.Color := clWindowText;
  lblPlanStatus.Caption := 'Unsaved changes';
end;

procedure TfrmCAT.btnExportClick(Sender: TObject);
var
  dlgSave: TSaveDialog;
begin
  // Save an editable UTF-8 plan through the Windows save dialog.
  dlgSave := TSaveDialog.Create(Self);
  try
    dlgSave.Title := 'Export lesson plan';
    dlgSave.Filter := 'Text files (*.txt)|*.txt';
    dlgSave.DefaultExt := 'txt';
    dlgSave.FileName := 'Lesson-plan.txt';
    dlgSave.Options := dlgSave.Options + [ofOverwritePrompt, ofPathMustExist];
    if not dlgSave.Execute then
      Exit;
    try
      TFile.WriteAllText(dlgSave.FileName, memPlan.Text, TEncoding.UTF8);
      bPlanDirty := False;
      lblPlanStatus.Font.Color := clSlate;
      lblPlanStatus.Caption := 'Lesson plan exported successfully';
    except
      on E: Exception do
        MessageDlg('The plan could not be exported.' + sLineBreak + E.Message,
          mtError, [mbOK], 0);
    end;
  finally
    dlgSave.Free;
  end;
end;

procedure TfrmCAT.FormCloseQuery(Sender: TObject; var bCanClose: Boolean);
begin
  bCanClose := not bPlanDirty;
  if bCanClose then
    Exit;

  case MessageDlg('Export your lesson plan before closing?' + sLineBreak +
    'Select No to discard your changes.', mtConfirmation,
    [mbYes, mbNo, mbCancel], 0) of
    mrYes:
      begin
        btnExportClick(Sender);
        bCanClose := not bPlanDirty;
      end;
    mrNo: bCanClose := True;
  end;
end;


procedure TfrmCAT.btnSubjectMenuClick(Sender: TObject);
begin
  // Close the modal workspace and return to the subject chooser.
  Close;
end;

procedure TfrmCAT.RefreshCurriculum;
var
  iGrade, iTerm: Integer;
begin
  // Render the selected policy or term guide and reset its self-check.
  if (cmbCurrGrade.ItemIndex < 0) or (cmbCurrTerm.ItemIndex < 0) or
    (cmbDocument.ItemIndex < 0) then
    Exit;
  iGrade := 10 + cmbCurrGrade.ItemIndex;
  iTerm := 1 + cmbCurrTerm.ItemIndex;
  cmbCurrCheck.Items.Clear;
  lblCurrFeedback.Caption := '';
  lblCurrFeedback.Font.Color := clWindowText;
  if cmbDocument.ItemIndex = 0 then
  begin
    memCurriculum.Text := CAPSGuide(iSelectedSubject, iGrade);
    btnOfficial.Caption := 'Open DBE &CAPS PDF';
    lblCurrCheck.Caption := 'Self-check. Where do you verify subject content and assessment policy?';
    cmbCurrCheck.Items.Add('The CAPS and applicable amendments');
    cmbCurrCheck.Items.Add('A previous lesson timetable');
    cmbCurrCheck.Items.Add('The list of devices in the lab');
  end
  else
  begin
    memCurriculum.Text := ATPGuide(iSelectedSubject, iGrade, iTerm);
    btnOfficial.Caption := 'Open &2026 grade ATP';
    lblCurrCheck.Caption := 'Self-check. What should you confirm before setting weekly pacing?';
    cmbCurrCheck.Items.Add('The number of textbook pages');
    cmbCurrCheck.Items.Add('The current subject, grade and term in the applicable ATP');
    cmbCurrCheck.Items.Add('The prior-year dates only');
  end;
  cmbCurrCheck.ItemIndex := -1;
  cmbCurrTerm.Enabled := cmbDocument.ItemIndex = 1;
  if cmbDocument.ItemIndex = 1 then
    btnSupportingDocument.Caption := 'Open &local ATP'
  else
    btnSupportingDocument.Caption := 'CAPS &update';
end;

procedure TfrmCAT.cmbCurrGradeChange(Sender: TObject);
begin
  // Grade applies to both policy reading notes and term planning.
  RefreshCurriculum;
end;

procedure TfrmCAT.cmbCurrTermChange(Sender: TObject);
begin
  // Refresh the term checklist without changing the selected grade.
  RefreshCurriculum;
end;

procedure TfrmCAT.cmbDocumentChange(Sender: TObject);
begin
  // Switch between the policy and the pacing views.
  RefreshCurriculum;
end;

procedure TfrmCAT.btnCurrCheckClick(Sender: TObject);
begin
  // The order of the correct answer differs between the two reading guides.
  if cmbCurrCheck.ItemIndex < 0 then
    lblCurrFeedback.Caption := 'Choose an answer first.'
  else if cmbCurrCheck.ItemIndex = cmbDocument.ItemIndex then
    lblCurrFeedback.Caption := 'Correct. Use the applicable official source for the decision.'
  else
    lblCurrFeedback.Caption := 'Review the distinction between curriculum policy and yearly pacing.';
end;

procedure TfrmCAT.OpenResource(const sResource: string);
begin
  // Let Windows open the selected PDF or a verified DBE link in the default app.
  if NativeInt(ShellExecute(Handle, 'open', PChar(sResource), nil, nil,
    SW_SHOWNORMAL)) <= 32 then
    MessageDlg('Windows could not open this resource.' + sLineBreak + sResource,
      mtError, [mbOK], 0);
end;

procedure TfrmCAT.btnOfficialClick(Sender: TObject);
begin
  // The index may contain both current and archived versions.
  if cmbDocument.ItemIndex = 0 then
    OpenResource(arrCAPSUrl[iSelectedSubject])
  else
    OpenResource(arrATPUrl[iSelectedSubject, 10 + cmbCurrGrade.ItemIndex]);
end;

procedure TfrmCAT.btnSupportingDocumentClick(Sender: TObject);
var
  iGrade: Integer;
begin
  // Open the official amendment circular or a local ATP, depending on the view.
  if cmbDocument.ItemIndex = 0 then
  begin
    OpenResource(sCAPSUpdateUrl);
    Exit;
  end;
  // Keep the selected local PDF path per grade for this workspace session.
  iGrade := 10 + cmbCurrGrade.ItemIndex;
  dlgATP.FileName := arrLocalATP[iGrade];
  if dlgATP.Execute then
  begin
    if not SameText(ExtractFileExt(dlgATP.FileName), '.pdf') then
    begin
      MessageDlg('Choose an ATP PDF.', mtInformation, [mbOK], 0);
      Exit;
    end;
    arrLocalATP[iGrade] := dlgATP.FileName;
    OpenResource(arrLocalATP[iGrade]);
  end;
end;

procedure TfrmCAT.btnPATClick(Sender: TObject);
begin
  // Open the DBE PAT index for the current 2026 Grade 12 packs.
  OpenResource(sPATUrl);
end;

procedure TfrmCAT.btnATPIndexClick(Sender: TObject);
begin
  // Offer the DBE index as a source alongside the grade-specific resource.
  OpenResource(sATPFETUrl);
end;

procedure TfrmCAT.btnCircularClick(Sender: TObject);
begin
  // Use the DBE circular listing to check S9, S19 and subsequent directives.
  OpenResource(sCircularUrl);
end;

procedure TfrmCAT.cmbBotPromptChange(Sender: TObject);
begin
  // Copy a suggested prompt so the teacher can still edit the question.
  if cmbBotPrompt.ItemIndex >= 0 then
    edtBotQuestion.Text := cmbBotPrompt.Text;
end;

procedure TfrmCAT.edtBotQuestionKeyPress(Sender: TObject; var cKey: Char);
begin
  // Enter submits a question without inserting a new line.
  if cKey = #13 then
  begin
    cKey := #0;
    btnAskClick(Sender);
  end;
end;

procedure TfrmCAT.btnAskClick(Sender: TObject);
var
  sQuestion: string;
begin
  // Match a local FAQ response and replace the visible conversation for privacy.
  sQuestion := Trim(edtBotQuestion.Text);
  if sQuestion = '' then
  begin
    memBot.Text := 'Type a question or choose one of the suggested topics.';
    edtBotQuestion.SetFocus;
    Exit;
  end;
  memBot.Text := 'YOU' + sLineBreak + sQuestion + sLineBreak + sLineBreak +
    'TEACHER FAQ' + sLineBreak + BotAnswer(iSelectedSubject, sQuestion);
end;

procedure TfrmCAT.btnClearBotClick(Sender: TObject);
begin
  // Questions and answers stay in memory and are cleared with this action.
  cmbBotPrompt.ItemIndex := -1;
  edtBotQuestion.Clear;
  memBot.Text := 'Ask a question about your ' + arrSubject[iSelectedSubject] +
    ' classroom. Try CAPS versus ATP, PAT, SBA, moderation, power outages, ' +
    'shared computers or learner privacy. Enter topic words and avoid learner names.';
end;

end.
