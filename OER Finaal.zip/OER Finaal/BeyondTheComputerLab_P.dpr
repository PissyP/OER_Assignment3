program BeyondTheComputerLab_P;

uses
  Vcl.Forms,
  Login_U in 'Login_U.pas' {frmLogin},
  CAT_U in 'CAT_U.pas' {frmCAT},
  IT_U in 'IT_U.pas' {frmIT},
  Curriculum_U in 'Curriculum_U.pas';

{$R Delphi13Icon.res}

begin
  // The login form owns startup and controls access to the subject forms.
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.Title := 'Beyond the Computer Lab';
  Application.CreateForm(TfrmLogin, frmLogin);
  Application.Run;
end.
