unit CAT_U;

interface

uses
  Winapi.Messages, Winapi.Windows, Winapi.ShellAPI, System.Classes, System.SysUtils, System.IOUtils, System.JSON,
  System.UITypes, System.Types, Vcl.Forms, Vcl.Controls, Vcl.StdCtrls,
  Vcl.ExtCtrls, Vcl.ComCtrls, Vcl.Dialogs, Vcl.Graphics, Vcl.Imaging.jpeg, Vcl.Imaging.pngimage, Curriculum_U;

type
  TfrmCAT = class(TForm)
    pnlHeader: TPanel;
    shpHeaderAccent: TShape;
    lblBrand: TLabel;
    lblAudience: TLabel;
    pnlSidebar: TPanel;
    lblBrowse: TLabel;
    lblSearch: TLabel;
    edtSearch: TEdit;
    lblCategory: TLabel;
    cmbCategory: TComboBox;
    lblMatch: TLabel;
    lstActivity: TListBox;
    btnHome: TButton;
    pgcMain: TPageControl;
    tabIntro: TTabSheet;
    lblWelcome: TLabel;
    lblIntroFooter: TLabel;
    memIntroduction: TMemo;
    btnStart: TButton;
    tabGuide: TTabSheet;
    lblGuideCategory: TLabel;
    lblGuideTitle: TLabel;
    redGuide: TRichEdit;
    pnlFigures: TPanel;
    lblIllustrations: TLabel;
    imgGuide: TImage;
    lblFigure: TLabel;
    btnPrevFigure: TButton;
    btnNextFigure: TButton;
    btnOpenPlan: TButton;
    tabPlan: TTabSheet;
    lblPlanTitle: TLabel;
    lblPlanSubject: TLabel;
    lblSignedIn: TLabel;
    btnSubjectMenu: TButton;
    tabCurriculum: TTabSheet;
    lblCurriculum: TLabel;
    lblCurrGrade: TLabel;
    cmbCurrGrade: TComboBox;
    lblCurrTerm: TLabel;
    cmbCurrTerm: TComboBox;
    lblDocument: TLabel;
    cmbDocument: TComboBox;
    memCurriculum: TMemo;
    btnOfficial: TButton;
    btnSupportingDocument: TButton;
    btnCircular: TButton;
    btnPAT: TButton;
    btnATPIndex: TButton;
    tabBot: TTabSheet;
    lblBotTitle: TLabel;
    lblBotPrompt: TLabel;
    cmbBotPrompt: TComboBox;
    lblBotQuestion: TLabel;
    edtBotQuestion: TEdit;
    btnAsk: TButton;
    btnClearBot: TButton;
    memBot: TMemo;
    dlgATP: TOpenDialog;
    lblGrade: TLabel;
    cmbGrade: TComboBox;
    lblAccess: TLabel;
    cmbAccess: TComboBox;
    btnGenerate: TButton;
    memPlan: TMemo;
    btnExport: TButton;
    lblPlanStatus: TLabel;
    shpChapterAccent: TShape;
    btnHelpForm, btnHelpIntro, btnHelpGuide, btnHelpPlan,
      btnHelpCurriculum, btnHelpBot, btnWCEDGuide: TButton;
    shpAIChapter, shpTeachingChapter, shpEmergingChapter: TShape;
    lblAIChapter, lblAIFocus, lblTeachingChapter, lblTeachingFocus,
      lblEmergingChapter, lblEmergingFocus: TLabel;
    btnAIChapter, btnTeachingChapter, btnEmergingChapter: TButton;
    procedure btnChapterClick(Sender: TObject);
    procedure lstActivityDrawItem(Control: TWinControl; iIndex: Integer;
      rctItem: TRect; State: TOwnerDrawState);
    procedure btnHelpFormClick(Sender: TObject);
    procedure btnTabHelpClick(Sender: TObject);
    procedure btnWCEDGuideClick(Sender: TObject);
    procedure btnPrevFigureClick(Sender: TObject);
    procedure btnNextFigureClick(Sender: TObject);
    procedure btnSubjectMenuClick(Sender: TObject);
    procedure cmbCurrGradeChange(Sender: TObject);
    procedure cmbCurrTermChange(Sender: TObject);
    procedure cmbDocumentChange(Sender: TObject);
    procedure btnOfficialClick(Sender: TObject);
    procedure btnSupportingDocumentClick(Sender: TObject);
    procedure btnCircularClick(Sender: TObject);
    procedure btnPATClick(Sender: TObject);
    procedure btnATPIndexClick(Sender: TObject);
    procedure cmbBotPromptChange(Sender: TObject);
    procedure edtBotQuestionKeyPress(Sender: TObject; var cKey: Char);
    procedure btnAskClick(Sender: TObject);
    procedure btnClearBotClick(Sender: TObject);
    procedure FormCloseQuery(Sender: TObject; var bCanClose: Boolean);
    procedure edtSearchChange(Sender: TObject);
    procedure cmbCategoryChange(Sender: TObject);
    procedure lstActivityClick(Sender: TObject);
    procedure btnHomeClick(Sender: TObject);
    procedure btnStartClick(Sender: TObject);
    procedure btnOpenPlanClick(Sender: TObject);
    procedure btnGenerateClick(Sender: TObject);
    procedure memPlanChange(Sender: TObject);
    procedure btnExportClick(Sender: TObject);
  private
    iActiveSubject, iFigure: Integer;
    sIllustrations: string;
    arrATP: array[10..12] of string;
    arrCatalog: TJSONArray;
    joCurrent: TJSONObject;  // Borrowed from arrCatalog.
    bPlanDirty: Boolean;
    procedure LoadCatalog;
    procedure ShowFigure;
    function FigureCount: Integer;
    procedure RefreshCurriculum;
    procedure OpenResource(const sResource: string);
    procedure FilterActivities;
    procedure SelectEntry(joEntry: TJSONObject);
  public
    destructor Destroy; override;
    procedure Initialize(iSubject: Integer);
  end;

var
  frmCAT: TfrmCAT;  // Form Designer reference. Login opens session instances.

implementation

{$R *.dfm}

const
  clBrandRed = TColor($003E27B9);
  clChapterAI = TColor($004D2573);
  clChapterTeaching = TColor($005A5A14);
  clChapterEmerging = TColor($002246A8);
  sAIChapter = 'Artificial intelligence';
  sTeachingChapter = 'Teaching, assessment and collaboration';
  sEmergingChapter = 'Emerging technologies and future trends';

function ChapterColour(const sCategory: string): TColor;
begin
  // Match each chapter card to its marker and article heading.
  if sCategory = sAIChapter then
    Result := clChapterAI
  else if sCategory = sEmergingChapter then
    Result := clChapterEmerging
  else
    Result := clChapterTeaching;
end;

function Field(joEntry: TJSONObject; const sKey: string): string;
begin
  // Read a text value from the validated catalogue object.
  Result := joEntry.GetValue<string>(sKey);
end;

function ContainsSearchText(const sText, sQuery: string): Boolean;
var
  iStart, iQueryLength: Integer;
begin
  // Match text with a first-principles loop and basic string operations.
  // Check each possible position using a loop instead of a search routine.
  iQueryLength := Length(sQuery);
  if iQueryLength = 0 then
    Exit(True);

  for iStart := 1 to Length(sText) - iQueryLength + 1 do
  begin
    if Copy(sText, iStart, iQueryLength) = sQuery then
      Exit(True);
  end;
  Result := False;
end;

procedure SetOptions(cmbBox: TComboBox; const arrOptions: array of string);
var
  sOption: string;
begin
  // Populate a selection control with the supplied display labels.
  for sOption in arrOptions do
    cmbBox.Items.Add(sOption);
  cmbBox.ItemIndex := 0;
end;

destructor TfrmCAT.Destroy;
begin
  // The catalogue owns the entries displayed in the contents list.
  arrCatalog.Free;
  inherited;
end;

procedure TfrmCAT.Initialize(iSubject: Integer);
var
  iTopic: Integer;
begin
  // Configure the inherited subject design before loading its activities.
  iActiveSubject := iSubject;
  Caption := 'Beyond the Computer Lab | ' + arrSubject[iActiveSubject];
  lblAudience.Caption := arrSubjectName[iActiveSubject] + ' for novice teachers';
  lblSignedIn.Caption := 'SIGNED IN  /  ' + arrSubject[iActiveSubject];
  lblPlanSubject.Caption := arrSubject[iActiveSubject];
  LoadCatalog;
  SetOptions(cmbCategory, ['All chapters', sAIChapter, sTeachingChapter, sEmergingChapter]);
  // Widen the drop-down for chapter names without widening the contents pane.
  cmbCategory.Perform(CB_SETDROPPEDWIDTH, MulDiv(344, PixelsPerInch, 96), 0);
  SetOptions(cmbGrade, ['10', '11', '12']);
  SetOptions(cmbAccess, ['Connected devices', 'Offline / shared devices']);
  SetOptions(cmbCurrGrade, ['10', '11', '12']);
  SetOptions(cmbCurrTerm, ['1', '2', '3', '4']);
  SetOptions(cmbDocument, ['CAPS policy guide', 'ATP planning guide']);
  for iTopic := Low(arrFAQ) to High(arrFAQ) do
    if (arrFAQ[iTopic].iSubject = 0) or (arrFAQ[iTopic].iSubject = iActiveSubject) then
      cmbBotPrompt.Items.Add(arrFAQ[iTopic].sPrompt);

  // Start on an introduction specific to the selected teaching subject.
  memIntroduction.Text :=
    'WELCOME TO THE ' + arrSubject[iActiveSubject] + ' GUIDEBOOK' + sLineBreak +
    sLineBreak + 'This open educational resource is for beginning and pre-service ' +
    'CAT and IT teachers in South African Grades 10-12 classrooms. It is a practical ' +
    'extension of the academic paper on technology integration in CAT and IT ' +
    'education. Where the paper compares tools and teaching approaches, this ' +
    'guide helps you apply those ideas through classroom examples, source ' +
    'documents and a lesson planner.' + sLineBreak + sLineBreak + arrIntro[iActiveSubject] + sLineBreak + sLineBreak +
    '1. Open CAPS and ATP. Select your grade and use the policy guide to ' +
    'identify the skill. In ATP mode, select your term and open the applicable grade plan.' +
    sLineBreak + sLineBreak +
    '2. Browse one of three chapters: artificial intelligence; teaching, assessment ' +
    'and collaboration; or emerging technologies. Compare educational value, ' +
    'limitations and accessibility before choosing a tool.' + sLineBreak + sLineBreak +
    '3. Generate and adapt a lesson plan. Choose the grade and access ' +
    'level. Edit and export the result as a text file.' + sLineBreak + sLineBreak +
    '4. Use Teacher Bot for questions about PAT, SBA, shared computers, moderation ' +
    'and practical teaching. The bot uses a built-in reference bank.';
  FilterActivities;
  RefreshCurriculum;
  btnClearBotClick(nil);
  pgcMain.ActivePage := tabIntro;
end;

procedure TfrmCAT.LoadCatalog;
var
  sFolder, sFileName, sKey, sCategory: string;
  jvValue, jvItem, jvOption: TJSONValue;
  joEntry: TJSONObject;
begin
  // Read and validate the subject catalogue before exposing its entries.
  // Both deployment beside the EXE and the Delphi platform/configuration
  // output folder are supported. The working directory is irrelevant.
  sFolder := ExtractFilePath(ParamStr(0));
  sFileName := TPath.Combine(sFolder, 'catalog.json');
  if not TFile.Exists(sFileName) then
    sFileName := TPath.GetFullPath(TPath.Combine(sFolder, '..\..\catalog.json'));
  if not TFile.Exists(sFileName) then
    raise EInOutError.Create('Keep catalog.json beside the executable or in the project folder.');

  sIllustrations := TPath.Combine(ExtractFilePath(sFileName), 'illustrations');
  jvValue := TJSONObject.ParseJSONValue(TFile.ReadAllText(sFileName, TEncoding.UTF8));
  try
    if not (jvValue is TJSONArray) then
      raise EConvertError.Create('catalog.json must contain an array of activities.');
    if TJSONArray(jvValue).Count = 0 then
      raise EConvertError.Create('catalog.json must contain at least one activity.');
    // Validate the whole catalogue before passing its objects to the GUI.
    for jvItem in TJSONArray(jvValue) do
    begin
      if not (jvItem is TJSONObject) then
        raise EConvertError.Create('Each activity must be a JSON object.');
      joEntry := TJSONObject(jvItem);
      for sKey in TArray<string>.Create('name', 'category', 'purpose', 'benefits',
        'limits', 'cat', 'it', 'activity', 'evidence', 'offline', 'guidance', 'source', 'pedagogy') do
        if Trim(Field(joEntry, sKey)) = '' then
          raise EConvertError.Create('Missing catalogue text for ' + sKey + '.');
      sCategory := Field(joEntry, 'category');
      if (sCategory <> sAIChapter) and (sCategory <> sTeachingChapter) and
        (sCategory <> sEmergingChapter) then
        raise EConvertError.Create('Unknown activity category for ' + Field(joEntry, 'name') + '.');
      // Ensure illustration paths remain relative to the asset folder.
      for jvOption in joEntry.GetValue<TJSONArray>('images') do
        if not (jvOption is TJSONString) or
          (ExtractFileName(jvOption.Value) <> jvOption.Value) or
          ((not SameText(ExtractFileExt(jvOption.Value), '.jpg')) and
           (not SameText(ExtractFileExt(jvOption.Value), '.png'))) then
          raise EConvertError.Create('Use JPG or PNG illustration filenames.');
      if iActiveSubject = iIT then
      begin
        for sKey in TArray<string>.Create('activity_it', 'offline_it', 'evidence_it') do
          if Trim(Field(joEntry, sKey)) = '' then
            raise EConvertError.Create('Missing IT activity text for ' + sKey + '.');
      end;
    end;
    arrCatalog := TJSONArray(jvValue);
    jvValue := nil;
  finally
    jvValue.Free;
  end;
end;

procedure TfrmCAT.edtSearchChange(Sender: TObject);
begin
  // Apply the current search phrase as the teacher types.
  FilterActivities;
end;

procedure TfrmCAT.cmbCategoryChange(Sender: TObject);
begin
  // Apply the selected technology category.
  FilterActivities;
end;

procedure TfrmCAT.FilterActivities;
var
  joEntry: TJSONObject;
  jvItem: TJSONValue;
  sQuery: string;
  iIndex: Integer;
begin
  // Populate the activity list while retaining the selected entry when possible.
  if arrCatalog = nil then
    Exit;
  sQuery := LowerCase(Trim(edtSearch.Text));
  iIndex := -1;
  lstActivity.Items.BeginUpdate;
  try
    lstActivity.Clear;
    for jvItem in arrCatalog do
    begin
      joEntry := TJSONObject(jvItem);
      if (cmbCategory.ItemIndex > 0) and
         (cmbCategory.Text <> Field(joEntry, 'category')) then
        Continue;
      // Search the teaching summaries and classroom activities.
      if (sQuery <> '') and not ContainsSearchText(
        LowerCase(Field(joEntry, 'name') + ' ' +
        Field(joEntry, 'purpose') + ' ' + Field(joEntry, LowerCase(arrSubject[iActiveSubject])) + ' ' +
        Field(joEntry, 'activity') + ' ' +
        Field(joEntry, 'offline')), sQuery) then
        Continue;
      if joEntry = joCurrent then
        iIndex := lstActivity.Items.Count;
      lstActivity.Items.AddObject(Field(joEntry, 'name'), joEntry);
    end;
    if (iIndex < 0) and (lstActivity.Items.Count > 0) then
      iIndex := 0;
    lstActivity.ItemIndex := iIndex;
  finally
    lstActivity.Items.EndUpdate;
  end;
  lblMatch.Caption := Format('%d activities', [lstActivity.Items.Count]);
  if iIndex < 0 then
    SelectEntry(nil)
  else
    SelectEntry(TJSONObject(lstActivity.Items.Objects[iIndex]));
end;

procedure TfrmCAT.SelectEntry(joEntry: TJSONObject);

  procedure AddSection(const sHeading, sKey: string);
  begin
    // Insert contrasting headings into the reading pane without changing the source text.
    redGuide.SelStart := redGuide.GetTextLen;
    redGuide.SelAttributes.Style := [fsBold];
    redGuide.SelAttributes.Color := clBrandRed;
    redGuide.SelText := sHeading + sLineBreak;
    redGuide.SelStart := redGuide.GetTextLen;
    redGuide.SelAttributes.Style := [];
    redGuide.SelAttributes.Color := clWindowText;
    redGuide.SelText := Field(joEntry, sKey) + sLineBreak + sLineBreak;
  end;

begin
  // Render the selected chapter entry and its illustrations.
  btnGenerate.Enabled := joEntry <> nil;
  if (joCurrent = joEntry) and (joEntry <> nil) then
    Exit;
  joCurrent := joEntry;
  iFigure := 0;
  ShowFigure;
  redGuide.Clear;
  if joEntry = nil then
  begin
    lblGuideCategory.Caption := 'Activity library';
    lblGuideTitle.Caption := 'No matching activities';
    redGuide.Text := 'Try a different search or choose All chapters.';
    Exit;
  end;

  lblGuideCategory.Caption := Field(joEntry, 'source');
  // Use chapter-specific colour alongside the text label for accessibility.
  shpChapterAccent.Brush.Color := ChapterColour(Field(joEntry, 'category'));
  lblGuideTitle.Font.Color := shpChapterAccent.Brush.Color;
  lblGuideTitle.Caption := Field(joEntry, 'name');
  redGuide.Lines.BeginUpdate;
  try
    AddSection('PURPOSE', 'purpose');
    AddSection('BENEFITS', 'benefits');
    AddSection('CLASSROOM CONSTRAINTS', 'limits');
    AddSection(arrSubject[iActiveSubject] + ' APPLICATION', LowerCase(arrSubject[iActiveSubject]));
    AddSection('HOW LEARNING IS SUPPORTED', 'pedagogy');
    if iActiveSubject = iIT then
      AddSection('CLASSROOM ACTIVITY', 'activity_it')
    else
      AddSection('CLASSROOM ACTIVITY', 'activity');
    if iActiveSubject = iIT then
    begin
      AddSection('EVIDENCE OF LEARNING', 'evidence_it');
      AddSection('OFFLINE ADAPTATION', 'offline_it');
    end
    else
    begin
      AddSection('EVIDENCE OF LEARNING', 'evidence');
      AddSection('OFFLINE ADAPTATION', 'offline');
    end;
    AddSection('TEACHING AND RESPONSIBLE USE', 'guidance');
  finally
    redGuide.Lines.EndUpdate;
  end;
  redGuide.SelStart := 0;
  redGuide.Perform(EM_SCROLLCARET, 0, 0);
end;

function TfrmCAT.FigureCount: Integer;
begin
  // Some sections have text only. Their reading pane uses the available width.
  Result := 0;
  if joCurrent <> nil then
    Result := joCurrent.GetValue<TJSONArray>('images').Count;
end;

procedure TfrmCAT.ShowFigure;
var
  iCount, iGap: Integer;
  sFile: string;
begin
  // Size the reading area from the current tab and keep illustrations proportional.
  iCount := FigureCount;
  iGap := MulDiv(24, PixelsPerInch, 96);
  imgGuide.Picture.Graphic := nil;
  pnlFigures.Visible := iCount > 0;
  if iCount = 0 then
  begin
    redGuide.Width := tabGuide.ClientWidth - redGuide.Left - iGap;
    Exit;
  end;
  redGuide.Width := pnlFigures.Left - redGuide.Left - iGap;
  lblFigure.Caption := Format('Figure %d of %d', [iFigure + 1, iCount]);
  btnPrevFigure.Enabled := iFigure > 0;
  btnNextFigure.Enabled := iFigure < iCount - 1;
  sFile := TPath.Combine(sIllustrations,
    joCurrent.GetValue<TJSONArray>('images').Items[iFigure].Value);
  try
    imgGuide.Picture.LoadFromFile(sFile);
  except
    on E: Exception do
      lblFigure.Caption := Format('Figure %d unavailable', [iFigure + 1]);
  end;
end;

procedure TfrmCAT.btnPrevFigureClick(Sender: TObject);
begin
  // Move back one image without changing the selected chapter section.
  if iFigure > 0 then
  begin
    Dec(iFigure);
    ShowFigure;
  end;
end;

procedure TfrmCAT.btnNextFigureClick(Sender: TObject);
begin
  // Move forward within the illustrations belonging to this section.
  if iFigure + 1 < FigureCount then
  begin
    Inc(iFigure);
    ShowFigure;
  end;
end;

procedure TfrmCAT.lstActivityClick(Sender: TObject);
begin
  // Show the full guide for the selected technology.
  if lstActivity.ItemIndex < 0 then
    Exit;
  SelectEntry(TJSONObject(lstActivity.Items.Objects[lstActivity.ItemIndex]));
  pgcMain.ActivePage := tabGuide;
end;

procedure TfrmCAT.btnHomeClick(Sender: TObject);
begin
  // Return to the subject introduction.
  pgcMain.ActivePage := tabIntro;
end;

procedure TfrmCAT.btnStartClick(Sender: TObject);
begin
  // Move from the introduction to the technology guide.
  pgcMain.ActivePage := tabGuide;
  lstActivity.SetFocus;
end;

procedure TfrmCAT.btnOpenPlanClick(Sender: TObject);
begin
  // Open the editable lesson planner.
  pgcMain.ActivePage := tabPlan;
end;

procedure TfrmCAT.btnGenerateClick(Sender: TObject);
var
  sSubjectKey, sRoute, sEvidenceKey: string;
begin
  // Build an editable lesson outline for the chosen grade and classroom access.
  if joCurrent = nil then
    Exit;
  if bPlanDirty and (MessageDlg('Replace the current unsaved lesson plan?',
    mtConfirmation, [mbYes, mbNo], 0) <> mrYes) then
    Exit;

  sSubjectKey := LowerCase(arrSubject[iActiveSubject]);
  sRoute := Field(joCurrent, 'activity');
  sEvidenceKey := 'evidence';
  if iActiveSubject = iIT then
  begin
    sRoute := Field(joCurrent, 'activity_it');
    sEvidenceKey := 'evidence_it';
  end;
  if cmbAccess.ItemIndex = 1 then
  begin
    sRoute := Field(joCurrent, 'offline');
    if iActiveSubject = iIT then
      sRoute := Field(joCurrent, 'offline_it');
  end;

  // Keep the guidebook activity and the subject adaptation available together.
  // Build an editable draft around the WCED planning and reflection cycle.
  memPlan.Text := Format('%s | Grade %s %s', [Field(joCurrent, 'name'),
    cmbGrade.Text, arrSubject[iActiveSubject]]) + sLineBreak +
    'Classroom access: ' + cmbAccess.Text + sLineBreak +
    'Date / duration: [complete]    Term / ATP week: [confirm]' + sLineBreak +
    'CAPS topic or skill: [confirm in CAPS and the applicable ATP]' + sLineBreak + sLineBreak +
    '1. LEARNING INTENTION AND SUCCESS CRITERIA' + sLineBreak +
    'By the end of the lesson, learners should be able to [state one observable skill].' +
    sLineBreak + 'Subject application: ' + Field(joCurrent, sSubjectKey) +
    sLineBreak + 'Success looks like: [describe the quality of the work learners submit].' +
    sLineBreak + sLineBreak +
    '2. INTRODUCTION AND PRIOR LEARNING' + sLineBreak +
    'Use one short example or diagnostic prompt. Record the prerequisite ' +
    'skill, likely misconception and time needed.' + sLineBreak + sLineBreak +
    '3. TEACHING AND LEARNING SEQUENCE' + sLineBreak +
    'Model the skill, guide the first attempt, then give learners an individual ' +
    'application. Add time and resources for each step.' + sLineBreak +
    sRoute + sLineBreak + sLineBreak +
    '4. SUPPORT AND ACCESS' + sLineBreak +
    'Specify an access arrangement, one scaffold and one extension. ' +
    Field(joCurrent, 'guidance') + sLineBreak + sLineBreak +
    '5. FORMATIVE ASSESSMENT AND CLOSURE' + sLineBreak +
    Field(joCurrent, sEvidenceKey) + sLineBreak +
    'Use an exit response or demonstration to compare performance with the success criteria.' +
    sLineBreak + sLineBreak +
    '6. REFLECTION AND NEXT STEPS' + sLineBreak +
    'Record what learners achieved, who needs support, and what to reteach or ' +
    'extend. Update the teaching plan after reviewing the evidence.' + sLineBreak + sLineBreak +
    'Planning reference: WCED Teacher Guidelines for Implementing Revised ATPs, section 5.2 (2020).' +
    sLineBreak + sWCEDGuideUrl;
  memPlanChange(nil);
  memPlan.SetFocus;
  memPlan.SelStart := 0;
end;

procedure TfrmCAT.memPlanChange(Sender: TObject);
begin
  // Track changes and enable export when the plan contains text.
  bPlanDirty := True;
  btnExport.Enabled := Trim(memPlan.Text) <> '';
  lblPlanStatus.Font.Color := clWindowText;
  lblPlanStatus.Caption := 'Unsaved changes';
end;

procedure TfrmCAT.btnExportClick(Sender: TObject);
var
  dlgSave: TSaveDialog;
begin
  // Save an editable UTF-8 plan through the Windows save dialog.
  dlgSave := TSaveDialog.Create(Self);
  try
    dlgSave.Title := 'Export lesson plan';
    dlgSave.Filter := 'Text files (*.txt)|*.txt';
    dlgSave.DefaultExt := 'txt';
    dlgSave.FileName := 'Lesson-plan.txt';
    dlgSave.Options := dlgSave.Options + [ofOverwritePrompt, ofPathMustExist];
    if not dlgSave.Execute then
      Exit;
    try
      TFile.WriteAllText(dlgSave.FileName, memPlan.Text, TEncoding.UTF8);
      bPlanDirty := False;
      lblPlanStatus.Font.Color := clBrandRed;
      lblPlanStatus.Caption := 'Lesson plan exported successfully';
    except
      on E: Exception do
        MessageDlg('The plan could not be exported.' + sLineBreak + E.Message,
          mtError, [mbOK], 0);
    end;
  finally
    dlgSave.Free;
  end;
end;

procedure TfrmCAT.FormCloseQuery(Sender: TObject; var bCanClose: Boolean);
begin
  // Protect an unsaved lesson plan when leaving the workspace.
  bCanClose := not bPlanDirty or
    (MessageDlg('Close and discard the unsaved lesson plan?',
      mtConfirmation, [mbYes, mbNo], 0) = mrYes);
end;


procedure TfrmCAT.btnSubjectMenuClick(Sender: TObject);
begin
  // Close the modal workspace and return to the subject chooser.
  Close;
end;

procedure TfrmCAT.RefreshCurriculum;
var
  iGrade, iTerm: Integer;
begin
  // Render the selected policy or term guide and show the relevant official sources.
  if (cmbCurrGrade.ItemIndex < 0) or (cmbCurrTerm.ItemIndex < 0) or
    (cmbDocument.ItemIndex < 0) then
    Exit;
  iGrade := 10 + cmbCurrGrade.ItemIndex;
  iTerm := 1 + cmbCurrTerm.ItemIndex;
  if cmbDocument.ItemIndex = 0 then
  begin
    memCurriculum.Text := CAPSGuide(iActiveSubject, iGrade);
    btnOfficial.Caption := 'Open DBE &CAPS PDF';
  end
  else
  begin
    memCurriculum.Text := ATPGuide(iActiveSubject, iGrade, iTerm);
    btnOfficial.Caption := 'Open &2026 grade ATP';
  end;
  cmbCurrTerm.Enabled := cmbDocument.ItemIndex = 1;
  if cmbDocument.ItemIndex = 1 then
    btnSupportingDocument.Caption := 'Open &local ATP'
  else
    btnSupportingDocument.Caption := 'CAPS &update';
end;

procedure TfrmCAT.cmbCurrGradeChange(Sender: TObject);
begin
  // Grade applies to both policy reading notes and term planning.
  RefreshCurriculum;
end;

procedure TfrmCAT.cmbCurrTermChange(Sender: TObject);
begin
  // Refresh the term checklist without changing the selected grade.
  RefreshCurriculum;
end;

procedure TfrmCAT.cmbDocumentChange(Sender: TObject);
begin
  // Switch between the policy and the pacing views.
  RefreshCurriculum;
end;

procedure TfrmCAT.OpenResource(const sResource: string);
begin
  // Let Windows open the selected PDF or a verified DBE link in the default app.
  if NativeInt(ShellExecute(Handle, 'open', PChar(sResource), nil, nil,
    SW_SHOWNORMAL)) <= 32 then
    MessageDlg('Windows could not open this resource.', mtError, [mbOK], 0);
end;

procedure TfrmCAT.btnOfficialClick(Sender: TObject);
begin
  // The index may contain both current and archived versions.
  if cmbDocument.ItemIndex = 0 then
    OpenResource(arrCAPSUrl[iActiveSubject])
  else
    OpenResource(arrATPUrl[iActiveSubject, 10 + cmbCurrGrade.ItemIndex]);
end;

procedure TfrmCAT.btnSupportingDocumentClick(Sender: TObject);
var
  iGrade: Integer;
begin
  // Open the official amendment circular or a local ATP, depending on the view.
  if cmbDocument.ItemIndex = 0 then
  begin
    OpenResource(sCAPSUpdateUrl);
    Exit;
  end;
  // Keep the selected local PDF path per grade for this workspace session.
  iGrade := 10 + cmbCurrGrade.ItemIndex;
  dlgATP.FileName := arrATP[iGrade];
  if dlgATP.Execute then
  begin
    if not SameText(ExtractFileExt(dlgATP.FileName), '.pdf') then
    begin
      MessageDlg('Choose an ATP PDF.', mtInformation, [mbOK], 0);
      Exit;
    end;
    arrATP[iGrade] := dlgATP.FileName;
    OpenResource(arrATP[iGrade]);
  end;
end;

procedure TfrmCAT.btnPATClick(Sender: TObject);
begin
  // Open the DBE PAT index for the current 2026 Grade 12 packs.
  OpenResource(sPATUrl);
end;

procedure TfrmCAT.btnATPIndexClick(Sender: TObject);
begin
  // Offer the DBE index as a source alongside the grade-specific resource.
  OpenResource(sATPFETUrl);
end;

procedure TfrmCAT.btnCircularClick(Sender: TObject);
begin
  // Use the DBE circular listing to check S9, S19 and subsequent directives.
  OpenResource(sCircularUrl);
end;

procedure TfrmCAT.cmbBotPromptChange(Sender: TObject);
begin
  // Copy a suggested prompt so the teacher can still edit the question.
  if cmbBotPrompt.ItemIndex >= 0 then
    edtBotQuestion.Text := cmbBotPrompt.Text;
end;

procedure TfrmCAT.edtBotQuestionKeyPress(Sender: TObject; var cKey: Char);
begin
  // Enter submits a question without inserting a new line.
  if cKey = #13 then
  begin
    cKey := #0;
    btnAskClick(Sender);
  end;
end;

procedure TfrmCAT.btnAskClick(Sender: TObject);
var
  sQuestion: string;
begin
  // Match a local FAQ response and replace the visible conversation for privacy.
  sQuestion := Trim(edtBotQuestion.Text);
  if sQuestion = '' then
  begin
    memBot.Text := 'Type a question or choose one of the suggested topics.';
    edtBotQuestion.SetFocus;
    Exit;
  end;
  memBot.Text := 'YOU' + sLineBreak + sQuestion + sLineBreak + sLineBreak +
    'TEACHER BOT' + sLineBreak + BotAnswer(iActiveSubject, sQuestion);
end;

procedure TfrmCAT.btnClearBotClick(Sender: TObject);
begin
  // Questions and answers stay in memory and are cleared with this action.
  cmbBotPrompt.ItemIndex := -1;
  edtBotQuestion.Clear;
  memBot.Text := 'Ask a question about your ' + arrSubject[iActiveSubject] +
    ' curriculum. Try Grade 11 ATP Term 2, Grade 10 CAPS, Grade 12 PAT, ' +
    'formal assessment, solution development or Paper 1 (IT). Include the ' +
    'grade and term when you know them.';
end;


procedure TfrmCAT.btnChapterClick(Sender: TObject);
begin
  // The tile and category selector share the same navigation and filtering.
  edtSearch.Clear;
  if Sender = btnAIChapter then
    cmbCategory.ItemIndex := 1
  else if Sender = btnTeachingChapter then
    cmbCategory.ItemIndex := 2
  else
    cmbCategory.ItemIndex := 3;
  FilterActivities;
  pgcMain.ActivePage := tabGuide;
end;

procedure TfrmCAT.lstActivityDrawItem(Control: TWinControl; iIndex: Integer;
  rctItem: TRect; State: TOwnerDrawState);
var
  clBackground, clMarker: TColor;
  sCategory: string;
  rctText: TRect;
  iInset, iMarkerWidth: Integer;
begin
  // Draw the chapter marker, selection and keyboard focus in the contents list.
  if (iIndex < 0) or (iIndex >= lstActivity.Items.Count) then
    Exit;
  clBackground := TColor($00F0F9FF);
  if Odd(iIndex) then
    clBackground := clWhite;
  if odSelected in State then
    clBackground := TColor($00D2CCEF);

  sCategory := '';
  if lstActivity.Items.Objects[iIndex] <> nil then
    sCategory := Field(TJSONObject(lstActivity.Items.Objects[iIndex]), 'category');
  clMarker := ChapterColour(sCategory);

  iInset := MulDiv(14, PixelsPerInch, 96);
  iMarkerWidth := MulDiv(4, PixelsPerInch, 96);
  lstActivity.Canvas.Brush.Color := clBackground;
  lstActivity.Canvas.FillRect(rctItem);
  lstActivity.Canvas.Brush.Color := clMarker;
  lstActivity.Canvas.FillRect(System.Types.Rect(rctItem.Left, rctItem.Top + 2,
    rctItem.Left + iMarkerWidth, rctItem.Bottom - 2));
  rctText := rctItem;
  Inc(rctText.Left, iInset);
  Dec(rctText.Right, iMarkerWidth);
  lstActivity.Canvas.Font.Assign(lstActivity.Font);
  lstActivity.Canvas.Font.Color := clWindowText;
  lstActivity.Canvas.Brush.Color := clBackground;
  Winapi.Windows.DrawText(lstActivity.Canvas.Handle, PChar(lstActivity.Items[iIndex]),
    Length(lstActivity.Items[iIndex]), rctText,
    DT_SINGLELINE or DT_VCENTER or DT_END_ELLIPSIS or DT_NOPREFIX);
  if odFocused in State then
    lstActivity.Canvas.DrawFocusRect(rctItem);
end;

procedure TfrmCAT.btnHelpFormClick(Sender: TObject);
begin
  // Describe navigation shared by the CAT and IT forms.
  MessageDlg(arrSubject[iActiveSubject] + ' workspace' + sLineBreak + sLineBreak +
    'Use Contents to browse chapters or search for a technology. Tabs open ' +
    'the introduction, illustrated guide, lesson planner, CAPS and ATP, or ' +
    'Teacher Bot. Each tab has its own Help button. Subject menu returns to ' +
    'the chooser so you can switch subjects or sign out.',
    mtInformation, [mbOK], 0);
end;

procedure TfrmCAT.btnTabHelpClick(Sender: TObject);
var
  sHelp: string;
begin
  // Explain the active page using its available controls and next steps.
  if pgcMain.ActivePage = tabIntro then
    sHelp := 'Read the guidebook purpose and audience. Choose Start exploring ' +
      'or select a section in Contents. Use the chapter dropdown and search ' +
      'box to narrow the list.'
  else if pgcMain.ActivePage = tabGuide then
    sHelp := 'Select a section in Contents. Read its purpose, benefits, limits, ' +
      'classroom activities and offline alternative. Use Previous figure and ' +
      'Next figure when illustrations are available. Open the lesson planner ' +
      'to adapt the selected section.'
  else if pgcMain.ActivePage = tabPlan then
    sHelp := 'Choose a grade and classroom access option. Use the selected ' +
      'activity to create an editable draft. Confirm the CAPS topic and ATP ' +
      'week, add timing and assessment evidence, then export as a text file. ' +
      'WCED planning guide opens the source in your browser.'
  else if pgcMain.ActivePage = tabCurriculum then
    sHelp := 'Choose your grade and document. CAPS shows subject content ' +
      'guidance and official policy links. ATP also uses the selected term. ' +
      'Open the linked plan or select a local PDF. The bottom buttons open ' +
      'circulars, the ATP index and Grade 12 PAT resources.'
  else
    sHelp := 'Choose a curriculum question or type one. Include the grade ' +
      'and focus, such as "Grade 12 PAT" or "Grade 11 ATP". Ask submits the ' +
      'question and Clear removes the current exchange. The bot works from ' +
      'a fixed bank and directs you to official documents for exact requirements.';
  MessageDlg(sHelp, mtInformation, [mbOK], 0);
end;

procedure TfrmCAT.btnWCEDGuideClick(Sender: TObject);
begin
  // Provide the planning reference used by the original lesson draft.
  OpenResource(sWCEDGuideUrl);
end;

end.
