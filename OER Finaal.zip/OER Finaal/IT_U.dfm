inherited frmIT: TfrmIT
  Caption = 'Beyond the Computer Lab | IT'
  inherited pnlHeader: TPanel
    Color = $003B3B15
    inherited lblAudience: TLabel
      Caption = 'Information Technology for novice teachers'
    end
    inherited lblSignedIn: TLabel
      Caption = 'SIGNED IN  /  IT'
    end
    inherited shpHeaderAccent: TShape
      Brush.Color = $0098A824
    end
  end
end
