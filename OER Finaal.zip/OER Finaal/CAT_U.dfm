object frmCAT: TfrmCAT
    ClientWidth = 1120
    ClientHeight = 744
    Color = $00E2EEF7
    Font.Name = 'Segoe UI'
    Font.Height = -16
    Scaled = True
    PixelsPerInch = 96
    Caption = 'Beyond the Computer Lab'
    Position = poScreenCenter
    Constraints.MinWidth = 1136
    Constraints.MinHeight = 720
    OnCloseQuery = FormCloseQuery
  object pnlHeader: TPanel
    Color = $00251542
      Left = 0
      Top = 0
      Width = 1120
      Height = 96
      Color = $00372F1F
      ParentBackground = False
      BevelOuter = bvNone
      Align = alTop
    object shpHeaderAccent: TShape
      Align = alBottom
      Height = 6
      Brush.Color = $003E27B9
      Pen.Style = psClear
    end
    object lblBrand: TLabel
        Left = 24
        Top = 16
        Width = 590
        Height = 38
        Caption = 'Beyond the Computer Lab'
        AutoSize = False
        Font.Height = -30
        Font.Color = clWhite
        Font.Style = [fsBold]
        ParentFont = False
    end
    object lblAudience: TLabel
      Font.Color = $00C6E1FB
        Left = 25
        Top = 59
        Width = 620
        Height = 22
        Caption = 'A practical guide for novice CAT and IT teachers'
        AutoSize = False
        Font.Height = -15
        Font.Color = $00CFE7FF
        Font.Style = []
        ParentFont = False
    end
    object lblSignedIn: TLabel
      Left = 858
      Top = 19
      Width = 236
      Height = 22
      Caption = 'SIGNED IN  /  CAT'
      AutoSize = False
      Anchors = [akTop, akRight]
      Alignment = taRightJustify
      Font.Color = clWhite
      ParentFont = False
    end
    object btnHelpForm: TButton
      Left = 750
      Top = 50
      Width = 145
      Height = 30
      Caption = '&Workspace help'
      Anchors = [akTop, akRight]
      OnClick = btnHelpFormClick
    end
    object btnSubjectMenu: TButton
      Left = 906
      Top = 50
      Width = 188
      Height = 30
      Caption = '&Subject menu'
      OnClick = btnSubjectMenuClick
      Anchors = [akTop, akRight]
    end
  end
  object pnlSidebar: TPanel
    Color = $00CADAED
    BevelKind = bkFlat
      Left = 16
      Top = 111
      Width = 270
      Height = 617
      Color = clWhite
      ParentBackground = False
      BevelOuter = bvNone
      Anchors = [akLeft, akTop, akBottom]
    object lblBrowse: TLabel
      Font.Color = $001C1030
      Caption = 'Inside the guide'
        Left = 15
        Top = 14
        Width = 237
        Height = 23
        Caption = 'Contents'
        AutoSize = False
        Font.Height = -18
        Font.Color = $003E27B9
        Font.Style = [fsBold]
        ParentFont = False
    end
    object lblSearch: TLabel
        Left = 15
        Top = 49
        Width = 235
        Height = 20
        Caption = '&Search the guide'
        AutoSize = False
        Font.Height = -14
        Font.Color = $00544B65
        Font.Style = []
        ParentFont = False
        FocusControl = edtSearch
    end
    object edtSearch: TEdit
        Left = 15
        Top = 71
        Width = 240
        Height = 28
        OnChange = edtSearchChange
        TextHint = 'Try spreadsheets or robotics'
    end
    object lblCategory: TLabel
        Left = 15
        Top = 110
        Width = 235
        Height = 20
        Caption = '&Chapter'
        AutoSize = False
        Font.Height = -14
        Font.Color = $00544B65
        Font.Style = []
        ParentFont = False
        FocusControl = cmbCategory
    end
    object cmbCategory: TComboBox
        Left = 15
        Top = 132
        Width = 240
        Height = 29
        Style = csDropDownList
        OnChange = cmbCategoryChange
    end
    object lblMatch: TLabel
        Left = 15
        Top = 170
        Width = 240
        Height = 20
        Caption = 'Loading activities'
        AutoSize = False
        Font.Height = -14
        Font.Color = $00544B65
        Font.Style = []
        ParentFont = False
    end
    object lstActivity: TListBox
      OnDrawItem = lstActivityDrawItem
      ItemHeight = 25
      Style = lbOwnerDrawFixed
      Height = 361
        Left = 15
        Top = 194
        Width = 240
        Height = 390
        Anchors = [akLeft, akTop, akBottom]
        OnClick = lstActivityClick
    end
    object btnHome: TButton
        Left = 15
        Top = 572
        Width = 240
        Height = 30
        Caption = '&Introduction'
        OnClick = btnHomeClick
        Anchors = [akLeft, akBottom]
    end
  end
  object pgcMain: TPageControl
      Left = 300
      Top = 111
      Width = 803
      Height = 617
      Anchors = [akLeft, akTop, akRight, akBottom]
      ActivePage = tabIntro
    object tabIntro: TTabSheet
        Caption = 'Introduction'
      object lblWelcome: TLabel
        Font.Color = $001C1030
        Caption = 'Your classroom toolkit'
        Top = 24
          Left = 24
          Top = 24
          Width = 620
          Height = 48
          Caption = 'Teach with technology, one lesson at a time'
          AutoSize = False
          Font.Height = -28
          Font.Color = $003E27B9
          Font.Style = [fsBold]
          ParentFont = False
          Anchors = [akLeft, akTop, akRight]
      end
      object memIntroduction: TMemo
        TabStop = True
        Color = $00F0F9FF
        Height = 287
        Top = 77
          Left = 24
          Top = 87
          Width = 746
          Height = 397
          ReadOnly = True
          ScrollBars = ssVertical
          Anchors = [akLeft, akTop, akRight, akBottom]
          TabStop = False
          BorderStyle = bsNone
          Color = clWhite
      end
      object shpAIChapter: TShape
        Shape = stRoundRect
        Left = 24
        Top = 377
        Width = 240
        Height = 115
        Anchors = [akLeft, akBottom]
        Brush.Color = $004D2573
        Pen.Style = psClear
      end
      object lblAIChapter: TLabel
        Left = 35
        Top = 388
        Width = 218
        Height = 26
        Caption = 'Artificial intelligence'
        AutoSize = False
        Anchors = [akLeft, akBottom]
        ParentFont = False
        Font.Height = -17
        Font.Color = clWhite
        Font.Style = [fsBold]
        Transparent = True
      end
      object lblAIFocus: TLabel
        Font.Color = clWhite
        Left = 35
        Top = 417
        Width = 218
        Height = 24
        Caption = 'Evaluate tools and outputs'
        AutoSize = False
        Anchors = [akLeft, akBottom]
        ParentFont = False
        Font.Height = -13
        Transparent = True
      end
      object btnAIChapter: TButton
        Left = 34
        Top = 449
        Width = 220
        Height = 31
        Caption = 'Explore AI'
        Anchors = [akLeft, akBottom]
        OnClick = btnChapterClick
      end
      object shpTeachingChapter: TShape
        Shape = stRoundRect
        Left = 277
        Top = 377
        Width = 240
        Height = 115
        Anchors = [akLeft, akBottom]
        Brush.Color = $005A5A14
        Pen.Style = psClear
      end
      object lblTeachingChapter: TLabel
        Left = 288
        Top = 388
        Width = 218
        Height = 26
        Caption = 'Teaching platforms'
        AutoSize = False
        Anchors = [akLeft, akBottom]
        ParentFont = False
        Font.Height = -17
        Font.Color = clWhite
        Font.Style = [fsBold]
        Transparent = True
      end
      object lblTeachingFocus: TLabel
        Font.Color = clWhite
        Left = 288
        Top = 417
        Width = 218
        Height = 24
        Caption = 'Support assessment and teamwork'
        AutoSize = False
        Anchors = [akLeft, akBottom]
        ParentFont = False
        Font.Height = -13
        Transparent = True
      end
      object btnTeachingChapter: TButton
        Left = 287
        Top = 449
        Width = 220
        Height = 31
        Caption = 'Explore platforms'
        Anchors = [akLeft, akBottom]
        OnClick = btnChapterClick
      end
      object shpEmergingChapter: TShape
        Shape = stRoundRect
        Left = 530
        Top = 377
        Width = 240
        Height = 115
        Anchors = [akLeft, akBottom]
        Brush.Color = $002246A8
        Pen.Style = psClear
      end
      object lblEmergingChapter: TLabel
        Left = 541
        Top = 388
        Width = 218
        Height = 26
        Caption = 'Emerging technologies'
        AutoSize = False
        Anchors = [akLeft, akBottom]
        ParentFont = False
        Font.Height = -17
        Font.Color = clWhite
        Font.Style = [fsBold]
        Transparent = True
      end
      object lblEmergingFocus: TLabel
        Font.Color = clWhite
        Left = 541
        Top = 417
        Width = 218
        Height = 24
        Caption = 'Explore future classroom uses'
        AutoSize = False
        Anchors = [akLeft, akBottom]
        ParentFont = False
        Font.Height = -13
        Transparent = True
      end
      object btnEmergingChapter: TButton
        Left = 540
        Top = 449
        Width = 220
        Height = 31
        Caption = 'Explore emerging tech'
        Anchors = [akLeft, akBottom]
        OnClick = btnChapterClick
      end
      object lblIntroFooter: TLabel
        Left = 232
        Top = 515
        Width = 520
        Height = 25
        Anchors = [akLeft, akRight, akBottom]
        AutoSize = False
        Caption = 'SOUTH AFRICAN CLASSROOMS   /   GRADES 10-12'
        Font.Color = $00544B65
        Font.Height = -13
        Font.Style = [fsBold]
        ParentFont = False
      end
      object btnStart: TButton
          Left = 24
          Top = 509
          Width = 190
          Height = 38
          Caption = '&Start exploring'
          OnClick = btnStartClick
          Anchors = [akLeft, akBottom]
      end
      object btnHelpIntro: TButton
        Left = 680
        Top = 12
        Width = 90
        Height = 29
        Caption = '&Help'
        Anchors = [akTop, akRight]
        OnClick = btnTabHelpClick
      end
    end
    object tabGuide: TTabSheet
        Caption = 'Read the guide'
      object shpChapterAccent: TShape
        Left = 24
        Top = 74
        Width = 746
        Height = 4
        Anchors = [akLeft, akTop, akRight]
        Pen.Style = psClear
        Brush.Color = $003E27B9
      end
      object lblGuideCategory: TLabel
          Left = 24
          Top = 12
          Width = 640
          Height = 21
          Caption = 'Activity'
          AutoSize = False
          Font.Height = -14
          Font.Color = $00544B65
          Font.Style = []
          ParentFont = False
          Anchors = [akLeft, akTop, akRight]
      end
      object lblGuideTitle: TLabel
          Left = 24
          Top = 36
          Width = 745
          Height = 38
          Caption = 'Activity'
          AutoSize = False
          Font.Height = -26
          Font.Color = $003E27B9
          Font.Style = [fsBold]
          ParentFont = False
          Anchors = [akLeft, akTop, akRight]
      end
      object redGuide: TRichEdit
        BorderStyle = bsNone
        Color = $00F0F9FF
        Left = 24
        Top = 83
        Width = 746
        Height = 401
        ReadOnly = True
        ScrollBars = ssVertical
        Anchors = [akLeft, akTop, akRight, akBottom]
      end
      object pnlFigures: TPanel
        BevelKind = bkFlat
        Left = 492
        Top = 83
        Width = 278
        Height = 401
        Anchors = [akTop, akRight, akBottom]
        BevelOuter = bvNone
        ParentBackground = False
        Color = $00CBDDED
        object lblIllustrations: TLabel
          Left = 12
          Top = 12
          Width = 254
          Height = 24
          AutoSize = False
          Caption = 'ILLUSTRATIONS'
          ParentFont = False
          Font.Style = [fsBold]
          Font.Color = $003E27B9
        end
        object imgGuide: TImage
          Left = 12
          Top = 44
          Width = 254
          Height = 288
          Anchors = [akLeft, akTop, akRight, akBottom]
          Center = True
          Proportional = True
          Stretch = True
        end
        object lblFigure: TLabel
          Left = 12
          Top = 339
          Width = 254
          Height = 22
          AutoSize = False
          Caption = ''
          Alignment = taCenter
          Anchors = [akLeft, akRight, akBottom]
        end
        object btnPrevFigure: TButton
          Left = 12
          Top = 367
          Width = 118
          Height = 26
          Caption = '&Previous figure'
          OnClick = btnPrevFigureClick
          Anchors = [akLeft, akBottom]
        end
        object btnNextFigure: TButton
          Left = 148
          Top = 367
          Width = 118
          Height = 26
          Caption = '&Next figure'
          OnClick = btnNextFigureClick
          Anchors = [akRight, akBottom]
        end
      end
      object btnOpenPlan: TButton
          Left = 24
          Top = 509
          Width = 190
          Height = 38
          Caption = 'Open lesson &planner'
          OnClick = btnOpenPlanClick
          Anchors = [akLeft, akBottom]
      end
      object btnHelpGuide: TButton
        Left = 680
        Top = 12
        Width = 90
        Height = 29
        Caption = '&Help'
        Anchors = [akTop, akRight]
        OnClick = btnTabHelpClick
      end
    end
    object tabPlan: TTabSheet
        Caption = 'Lesson planner'
      object lblPlanTitle: TLabel
          Left = 24
          Top = 18
          Width = 746
          Height = 36
          Caption = 'Build a lesson plan'
          AutoSize = False
          Font.Height = -25
          Font.Color = $003E27B9
          Font.Style = [fsBold]
          ParentFont = False
          Anchors = [akLeft, akTop, akRight]
      end
      object lblPlanSubject: TLabel
        Left = 24
        Top = 89
        Width = 126
        Height = 28
        Caption = 'CAT'
        AutoSize = False
        ParentFont = False
        Font.Height = -24
        Font.Color = $003E27B9
        Font.Style = [fsBold]
      end
      object lblGrade: TLabel
          Left = 167
          Top = 66
          Width = 108
          Height = 20
          Caption = '&Grade'
          AutoSize = False
          Font.Height = -14
          Font.Color = $00544B65
          Font.Style = []
          ParentFont = False
          FocusControl = cmbGrade
      end
      object cmbGrade: TComboBox
          Left = 167
          Top = 89
          Width = 108
          Height = 29
          Style = csDropDownList
      end
      object lblAccess: TLabel
          Left = 292
          Top = 66
          Width = 270
          Height = 20
          Caption = 'Classroom &access'
          AutoSize = False
          Font.Height = -14
          Font.Color = $00544B65
          Font.Style = []
          ParentFont = False
          FocusControl = cmbAccess
      end
      object cmbAccess: TComboBox
          Left = 292
          Top = 89
          Width = 270
          Height = 29
          Style = csDropDownList
      end
      object btnGenerate: TButton
          Left = 578
          Top = 84
          Width = 192
          Height = 37
          Caption = '&Use this activity'
          OnClick = btnGenerateClick
          Anchors = [akTop, akRight]
      end
      object memPlan: TMemo
        Color = $00DDF3FF
          Left = 24
          Top = 141
          Width = 746
          Height = 344
          ReadOnly = False
          ScrollBars = ssVertical
          Anchors = [akLeft, akTop, akRight, akBottom]
          OnChange = memPlanChange
      end
      object btnExport: TButton
          Left = 24
          Top = 509
          Width = 178
          Height = 38
          Caption = '&Export lesson plan'
          OnClick = btnExportClick
          Anchors = [akLeft, akBottom]
          Enabled = False
      end
      object lblPlanStatus: TLabel
          Left = 221
          Top = 518
          Width = 322
          Height = 24
          Caption = 'Choose an activity to start.'
          AutoSize = False
          Font.Height = -14
          Font.Color = $00544B65
          Font.Style = []
          ParentFont = False
          Anchors = [akLeft, akRight, akBottom]
      end
      object btnHelpPlan: TButton
        Left = 680
        Top = 12
        Width = 90
        Height = 29
        Caption = '&Help'
        Anchors = [akTop, akRight]
        OnClick = btnTabHelpClick
      end
      object btnWCEDGuide: TButton
        Left = 559
        Top = 509
        Width = 211
        Height = 38
        Caption = 'WCED planning guide'
        Anchors = [akRight, akBottom]
        OnClick = btnWCEDGuideClick
      end
    end
    object tabCurriculum: TTabSheet
      Caption = 'CAPS and ATP'
      object lblCurriculum: TLabel
        Left = 24
        Top = 18
        Width = 640
        Height = 34
        Caption = 'Curriculum and teaching plans'
        AutoSize = False
        ParentFont = False
        Font.Height = -24
        Font.Color = $003E27B9
        Font.Style = [fsBold]
        Anchors = [akLeft, akTop, akRight]
      end
      object lblCurrGrade: TLabel
        Left = 24
        Top = 66
        Width = 100
        Height = 22
        Caption = '&Grade'
        AutoSize = False
        FocusControl = cmbCurrGrade
      end
      object cmbCurrGrade: TComboBox
        Left = 24
        Top = 90
        Width = 100
        Height = 28
        Style = csDropDownList
        OnChange = cmbCurrGradeChange
      end
      object lblCurrTerm: TLabel
        Left = 143
        Top = 66
        Width = 100
        Height = 22
        Caption = '&Term'
        AutoSize = False
        FocusControl = cmbCurrTerm
      end
      object cmbCurrTerm: TComboBox
        Left = 143
        Top = 90
        Width = 100
        Height = 28
        Style = csDropDownList
        OnChange = cmbCurrTermChange
      end
      object lblDocument: TLabel
        Left = 261
        Top = 66
        Width = 260
        Height = 22
        Caption = '&Document'
        AutoSize = False
        FocusControl = cmbDocument
      end
      object cmbDocument: TComboBox
        Left = 261
        Top = 90
        Width = 260
        Height = 28
        Style = csDropDownList
        OnChange = cmbDocumentChange
      end
      object memCurriculum: TMemo
        Color = $00DAE9F8
        Left = 24
        Top = 133
        Width = 746
        Height = 348
        ReadOnly = True
        ScrollBars = ssVertical
        Anchors = [akLeft, akTop, akRight, akBottom]
      end
      object btnOfficial: TButton
        Left = 24
        Top = 513
        Width = 166
        Height = 34
        Caption = 'Open DBE &CAPS PDF'
        OnClick = btnOfficialClick
        Anchors = [akLeft, akBottom]
      end
      object btnSupportingDocument: TButton
        Left = 199
        Top = 513
        Width = 134
        Height = 34
        Caption = 'Open &local ATP'
        OnClick = btnSupportingDocumentClick
        Anchors = [akLeft, akBottom]
      end
      object btnCircular: TButton
        Left = 342
        Top = 513
        Width = 128
        Height = 34
        Caption = 'DBE ci&rculars'
        OnClick = btnCircularClick
        Anchors = [akLeft, akBottom]
      end
      object btnATPIndex: TButton
        Left = 479
        Top = 513
        Width = 131
        Height = 34
        Caption = 'DBE ATP inde&x'
        OnClick = btnATPIndexClick
        Anchors = [akLeft, akBottom]
      end
      object btnPAT: TButton
        Left = 619
        Top = 513
        Width = 151
        Height = 34
        Caption = 'Grade 12 &PATs'
        OnClick = btnPATClick
        Anchors = [akLeft, akBottom]
      end
      object btnHelpCurriculum: TButton
        Left = 680
        Top = 12
        Width = 90
        Height = 29
        Caption = '&Help'
        Anchors = [akTop, akRight]
        OnClick = btnTabHelpClick
      end
    end
    object tabBot: TTabSheet
      Caption = 'Teacher Bot'
      object lblBotTitle: TLabel
        Left = 24
        Top = 18
        Width = 640
        Height = 34
        Caption = 'Teacher Bot'
        AutoSize = False
        ParentFont = False
        Font.Height = -24
        Font.Color = $003E27B9
        Font.Style = [fsBold]
        Anchors = [akLeft, akTop, akRight]
      end
      object lblBotPrompt: TLabel
        Left = 24
        Top = 65
        Width = 740
        Height = 23
        Caption = '&Suggested questions for South African teachers'
        AutoSize = False
        FocusControl = cmbBotPrompt
      end
      object cmbBotPrompt: TComboBox
        Left = 24
        Top = 91
        Width = 746
        Height = 28
        Style = csDropDownList
        Anchors = [akLeft, akTop, akRight]
        OnChange = cmbBotPromptChange
      end
      object lblBotQuestion: TLabel
        Left = 24
        Top = 136
        Width = 635
        Height = 24
        Caption = '&Your question'
        AutoSize = False
        FocusControl = edtBotQuestion
      end
      object edtBotQuestion: TEdit
        Left = 24
        Top = 163
        Width = 599
        Height = 30
        Anchors = [akLeft, akTop, akRight]
        MaxLength = 350
        OnKeyPress = edtBotQuestionKeyPress
      end
      object btnAsk: TButton
        Left = 634
        Top = 160
        Width = 136
        Height = 34
        Caption = '&Ask bot'
        OnClick = btnAskClick
        Anchors = [akTop, akRight]
      end
      object memBot: TMemo
        Color = $00ECE7F7
        Left = 24
        Top = 214
        Width = 746
        Height = 280
        ReadOnly = True
        ScrollBars = ssVertical
        Anchors = [akLeft, akTop, akRight, akBottom]
      end
      object btnClearBot: TButton
        Left = 24
        Top = 513
        Width = 166
        Height = 34
        Caption = '&Clear conversation'
        OnClick = btnClearBotClick
        Anchors = [akLeft, akBottom]
      end
      object btnHelpBot: TButton
        Left = 680
        Top = 12
        Width = 90
        Height = 29
        Caption = '&Help'
        Anchors = [akTop, akRight]
        OnClick = btnTabHelpClick
      end
    end
  end
  object dlgATP: TOpenDialog
    Title = 'Open the applicable ATP PDF'
    Filter = 'PDF files (*.pdf)|*.pdf'
    Options = [ofHideReadOnly, ofPathMustExist, ofFileMustExist, ofNoDereferenceLinks]
    Left = 224
    Top = 44
  end
end
