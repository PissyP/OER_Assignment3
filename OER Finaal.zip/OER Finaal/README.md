# Beyond the Computer Lab

*A practical OER for novice CAT and IT teachers in Grades 10–12*

An editable Delphi VCL project for Windows. The two subject workspaces adapt the group's guidebook to South African secondary classrooms and add curriculum reading support and novice teacher FAQs.

## Open, sign in and edit

1. Extract the ZIP and open **BeyondTheComputerLab_P.dpr** in Delphi 13 with VCL and the Windows compiler installed.
2. Press **F9**. The loading animation runs for about 4.4 seconds. The purpose page then reveals its text from top to bottom. Select **Continue to game** after it appears. Press **Jump** or Space to play Dino Dash, or select **Continue to sign in**.
3. Enter the separately supplied demo credentials. The password is case-sensitive. The app uses a local demo gate with no user accounts.
4. Select **CAT** or **IT**. Use **Subject menu** to return to the chooser, or **Sign out** to return to the login screen.
5. In Delphi, press **F12** from a form unit to switch between source and design. Delphi uses the `.pas` extension for unit source files.

| Form | Files | Role |
| --- | --- | --- |
| `frmLogin` | `Login_U.pas`, `Login_U.dfm` | Startup animation, credential validation, and subject selection |
| `frmCAT` | `CAT_U.pas`, `CAT_U.dfm` | CAT workspace and shared workspace layout and events |
| `frmIT` | `IT_U.pas`, `IT_U.dfm` | IT workspace, visually inherited from CAT with IT content and branding |

`Curriculum_U.pas` contains the subject, grade, term, ATP-link and FAQ arrays. `catalog.json` contains 17 guidebook sections across three chapters, with subject applications and teaching considerations. The accompanying `illustrations` directory contains the 26 guidebook figures. Every routine has a purpose comment. The code uses Delphi form events and descriptive prefixes consistent with DBE IT Paper 1 examples, including `frm`, `btn`, `edt`, `cmb`, `lbl`, `i`, `s`, `b` and `arr`. The catalogue and curriculum bot use explicit search loops. Dino Dash uses a sprite array, integer arithmetic, selection, repetition and event handlers. The VCL form inheritance, JSON catalogue and Windows integration are application features and sit outside the Paper 1 model. See the DBE guidelines below for the examinable scope.

## Use the subject workspaces

The branded welcome rail leads into the subject selector. On the subject introduction, use the coloured chapter cards to open the matching section list. The contents list uses matching chapter markers. The design draws on the supplied PAT’s split welcome layout, strong wine and cream palette, category navigation and card-based grouping. CAT uses a wine-red header and IT uses a deep petrol header.

- **Introduction** gives a route through the resource for teachers starting out in the subject.
- **CAPS and ATP** provides separate views. In CAPS mode, choose Grade 10, 11 or 12 and use the subject summary, classroom example and DBE source buttons. In ATP mode, select a grade and term, open the matching 2026 ATP in the browser or a local ATP PDF, and use the term planning guide. The app opens the full documents in the default Windows browser or PDF reader. The 2026 ATP links are listed by IT & CAT in EC and may depend on their Drive sharing settings. School-issued PDFs can be opened locally.
- **Illustrated guide** show subject applications, supporting pedagogy, evidence of learning, offline alternatives and colour-coded chapter headings. Where a section has original illustrations, use **Previous figure** and **Next figure** to browse them. Completion is tracked while that workspace is open.
- **Lesson planner** creates an editable connected or offline draft. It adapts the WCED planning cycle into fields for prior learning, learning intentions, teaching sequence, support, assessment and reflection. The WCED source button opens the guide. Confirm the topic and week using the applicable CAPS and ATP.
- **Teacher Bot** accepts a suggested or typed curriculum question. It can supply subject- and grade-specific ATP links, term planning guidance, CAPS links, PAT sources, and guidance on SBA, solution development and IT Paper 1. For school-specific decisions it refers teachers to the applicable documents and school staff. It runs offline without an account, API or saved chat history.

Every workspace tab, both subject forms, and the startup/sign-in form have contextual **Help** buttons.

## Curriculum references

- [WCED Teacher Guidelines for Implementing Revised ATPs](https://wcedonline.westerncape.gov.za/circulars/circulars20/circ18-20-Annexure%20A-Teacher%20guidelines%20for%20the%20implementation%20of%20the%20revised%20ATPs.pdf), section 5.2 (2020). The planner draws on the teaching and reflection process. Use the current ATP for pacing.
- [DBE Grade 12 IT Examination Guidelines](https://www.education.gov.za/Portals/0/CD/2021%20Exam%20Guidelines/Information%20Technology%20GR%2012%20Exam%20Guidelines%202021%20Eng.pdf), Paper 1 scope and programming guidance.
- [DBE FET CAPS index](https://www.education.gov.za/Curriculum/CurriculumAssessmentPolicyStatements(CAPS)/CAPSFET.aspx) and [DBE circulars](https://www.education.gov.za/Curriculum/NationalCirculars.aspx), including S9 of 2025 on CAT and IT CAPS.
- [DBE Circular S19 of 2025](https://www.education.gov.za/Portals/0/Documents/Publications/2026/Circulars/Circular%20S19%20of%202025%20and%20Annexures.pdf). The general 2023/24 ATP rollover excludes CAT and IT for 2026.
- [IT & CAT in EC teacher resources](https://sites.google.com/view/itandcatinec/teachers), source of all six grade-specific 2026 ATP links.
- [DBE 2026 Grade 12 PAT packs](https://www.education.gov.za/Curriculum/NationalCurriculumStatementsGradesR-12/Grade12PATs2026.aspx).
- [DBE May/June 2025 IT Paper 1 marking guidelines](https://www.education.gov.za/LinkClick.aspx?fileticket=JquUx5WmpBM%3D&forcedownload=true&mid=14241&portalid=0&tabid=5475).

## Share on GitHub

Upload the extracted project files to the repository root. To distribute a Windows build, attach a ZIP containing the compiled executable, **catalog.json**, and the **illustrations/** folder to a GitHub Release. The catalogue and its illustrations folder must be beside the executable or in the project root when the IDE uses the standard platform/configuration output folder.

## Editorial credits

Technology content and figures were adapted from the supplied *Technology Integration in CAT and IT Education: Combined Guidebook*. The three chapters cover artificial intelligence, teaching and collaboration, and emerging technologies. The Delphi icon uses the Embarcadero Delphi product mark. The code and original additions use Apache-2.0. Source illustrations and logos retain their respective rights. Confirm image permissions before public redistribution.

## Windows smoke test

- Run the project. Check the loading animation, the top-to-bottom purpose reveal, the game, the incorrect-login message and the supplied demo credentials.
- Open Mentimeter and use **Next figure** to view the second image. Open Google Gemini and confirm the reading pane expands to full width.
- Open CAT and IT from the subject menu. Confirm that each opens on its own introduction and shows subject-specific curriculum and navigate all five tabs with their Help buttons.
- In both workspaces test all grades in CAPS and ATP. Confirm the selected grade opens the corresponding link and that a local ATP PDF opens with internet disconnected.
- Start Dino Dash using Jump, clear a cactus, collide with one, then use Play again. Open Help during play and confirm the round pauses. Continue to sign in and confirm the animation stops.
- Ask **How do I teach spreadsheet formulas in CAT?** from CAT and **How do I teach arrays and debugging?** from IT. Test a blank question and an unmatched question.
- Generate and edit an offline lesson plan, validate the unsaved changes prompt and export the plan.
- Return to the subject menu and sign out. Confirm the subject selector requires signing in again.
