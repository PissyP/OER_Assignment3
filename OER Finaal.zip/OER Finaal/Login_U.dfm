object frmLogin: TfrmLogin
  Left = 0
  Top = 0
  BorderIcons = [biSystemMenu, biMinimize]
  BorderStyle = bsSingle
  Caption = 'Beyond the Computer Lab | Sign in'
  ClientHeight = 585
  ClientWidth = 920
  Color = 14872311
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -16
  Font.Name = 'Segoe UI'
  Font.Style = []
  KeyPreview = True
  Position = poScreenCenter
  OnKeyDown = FormKeyDown
  OnShow = FormShow
  TextHeight = 21
  object pnlBanner: TPanel
    Left = 0
    Top = 0
    Width = 228
    Height = 585
    Align = alLeft
    BevelOuter = bvNone
    Color = 1839152
    ParentBackground = False
    TabOrder = 0
    ExplicitHeight = 577
    DesignSize = (
      228
      585)
    object shpRailAccent: TShape
      Left = 24
      Top = 188
      Width = 80
      Height = 6
      Brush.Color = 4073401
      Pen.Style = psClear
    end
    object lblEdition: TLabel
      Left = 24
      Top = 24
      Width = 180
      Height = 23
      AutoSize = False
      Caption = 'TEACHER GUIDEBOOK'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = 6735103
      Font.Height = -13
      Font.Name = 'Segoe UI'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object lblPhase: TLabel
      Left = 24
      Top = 358
      Width = 180
      Height = 21
      AutoSize = False
      Caption = 'SOUTH AFRICA | GRADES 10-12'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -13
      Font.Name = 'Segoe UI'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object lblBrand: TLabel
      Left = 24
      Top = 65
      Width = 184
      Height = 122
      AutoSize = False
      Caption = 'Beyond the Computer Lab'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -32
      Font.Name = 'Segoe UI'
      Font.Style = [fsBold]
      ParentFont = False
      WordWrap = True
    end
    object lblSubtitle: TLabel
      Left = 24
      Top = 217
      Width = 181
      Height = 84
      AutoSize = False
      Caption = 'A practical teaching guide for novice CAT and IT teachers'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = 12836600
      Font.Height = -16
      Font.Name = 'Segoe UI'
      Font.Style = []
      ParentFont = False
      WordWrap = True
    end
    object btnHelp: TButton
      Left = 24
      Top = 525
      Width = 180
      Height = 36
      Anchors = [akLeft, akBottom]
      Caption = '&Help'
      TabOrder = 0
      OnClick = btnHelpClick
      ExplicitTop = 517
    end
  end
  object pnlPurpose: TPanel
    Left = 255
    Top = 82
    Width = 636
    Height = 422
    BevelKind = bkFlat
    BevelOuter = bvNone
    Color = clWhite
    ParentBackground = False
    TabOrder = 1
    Visible = False
    object lblPurposeTitle: TLabel
      Left = 24
      Top = 23
      Width = 590
      Height = 38
      AutoSize = False
      Caption = 'Teach with purpose'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = 4073401
      Font.Height = -24
      Font.Name = 'Segoe UI'
      Font.Style = [fsBold]
      ParentFont = False
      Visible = False
    end
    object lblPurposeAudience: TLabel
      Left = 24
      Top = 78
      Width = 585
      Height = 68
      AutoSize = False
      Caption = 
        'This open educational resource is a practical extension of the a' +
        'cademic paper on technology integration. It supports beginning a' +
        'nd pre-service CAT and IT teachers in South African Grades 10-12' +
        ' classrooms.'
      Visible = False
      WordWrap = True
    end
    object lblPurposeRead: TLabel
      Left = 24
      Top = 152
      Width = 585
      Height = 66
      AutoSize = False
      Caption = 
        'EXPLORE   Compare artificial intelligence, classroom platforms, ' +
        'and emerging technologies. Consider learning value, access and r' +
        'isk.'
      Color = 15131129
      Font.Charset = DEFAULT_CHARSET
      Font.Color = 2103338
      Font.Height = -16
      Font.Name = 'Segoe UI'
      Font.Style = []
      ParentColor = False
      ParentFont = False
      Transparent = False
      Visible = False
      WordWrap = True
    end
    object lblPurposeApply: TLabel
      Left = 24
      Top = 226
      Width = 585
      Height = 66
      AutoSize = False
      Caption = 
        'APPLY   Connect teaching choices to CAPS and the ATP. Adapt acti' +
        'vities for your learners, including classes with limited devices' +
        ' or internet access.'
      Color = 15134173
      Font.Charset = DEFAULT_CHARSET
      Font.Color = 2103338
      Font.Height = -16
      Font.Name = 'Segoe UI'
      Font.Style = []
      ParentColor = False
      ParentFont = False
      Transparent = False
      Visible = False
      WordWrap = True
    end
    object lblPurposeReflect: TLabel
      Left = 24
      Top = 300
      Width = 585
      Height = 63
      AutoSize = False
      Caption = 
        'REFLECT   Review evidence of learning, and make responsible deci' +
        'sions about AI and learner privacy.'
      Color = 13427708
      Font.Charset = DEFAULT_CHARSET
      Font.Color = 2103338
      Font.Height = -16
      Font.Name = 'Segoe UI'
      Font.Style = []
      ParentColor = False
      ParentFont = False
      Transparent = False
      Visible = False
      WordWrap = True
    end
    object btnContinue: TButton
      Left = 24
      Top = 375
      Width = 200
      Height = 34
      Caption = '&Continue to game'
      TabOrder = 0
      Visible = False
      OnClick = btnContinueClick
    end
  end
  object pnlGame: TPanel
    Left = 255
    Top = 82
    Width = 636
    Height = 422
    BevelKind = bkFlat
    BevelOuter = bvNone
    Color = clWhite
    ParentBackground = False
    TabOrder = 2
    Visible = False
    object lblGameTitle: TLabel
      Left = 24
      Top = 18
      Width = 588
      Height = 41
      AutoSize = False
      Caption = 'Dino Dash'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = 4073401
      Font.Height = -28
      Font.Name = 'Segoe UI'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object lblScore: TLabel
      Left = 24
      Top = 67
      Width = 588
      Height = 26
      AutoSize = False
      Caption = 'Score 0   |   Best 0'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = 5055859
      Font.Height = -16
      Font.Name = 'Segoe UI'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object pbxGame: TPaintBox
      Left = 24
      Top = 101
      Width = 588
      Height = 199
      OnPaint = pbxGamePaint
    end
    object lblGameStatus: TLabel
      Left = 24
      Top = 315
      Width = 588
      Height = 27
      AutoSize = False
      Caption = 'Press Jump to start. Clear the cacti.'
    end
    object btnJump: TButton
      Left = 24
      Top = 360
      Width = 254
      Height = 38
      Caption = '&Jump'
      TabOrder = 0
      OnClick = btnJumpClick
    end
    object btnFinishGame: TButton
      Left = 365
      Top = 360
      Width = 247
      Height = 38
      Caption = 'Continue to &sign in'
      TabOrder = 1
      OnClick = btnFinishGameClick
    end
  end
  object pnlSignIn: TPanel
    Left = 255
    Top = 106
    Width = 636
    Height = 343
    BevelKind = bkFlat
    BevelOuter = bvNone
    Color = clWhite
    ParentBackground = False
    TabOrder = 3
    Visible = False
    object lblSignIn: TLabel
      Left = 22
      Top = 13
      Width = 590
      Height = 36
      AutoSize = False
      Caption = 'Teacher sign-in'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = 4073401
      Font.Height = -24
      Font.Name = 'Segoe UI'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object lblUsername: TLabel
      Left = 22
      Top = 58
      Width = 500
      Height = 21
      AutoSize = False
      Caption = '&Username'
      FocusControl = edtUsername
    end
    object lblPassword: TLabel
      Left = 22
      Top = 119
      Width = 500
      Height = 21
      AutoSize = False
      Caption = '&Password'
      FocusControl = edtPassword
    end
    object lblLoginStatus: TLabel
      Left = 22
      Top = 266
      Width = 590
      Height = 24
      AutoSize = False
      Font.Charset = DEFAULT_CHARSET
      Font.Color = 3355552
      Font.Height = -16
      Font.Name = 'Segoe UI'
      Font.Style = []
      ParentFont = False
    end
    object edtUsername: TEdit
      Left = 22
      Top = 81
      Width = 380
      Height = 29
      MaxLength = 80
      TabOrder = 0
    end
    object edtPassword: TEdit
      Left = 22
      Top = 142
      Width = 380
      Height = 29
      MaxLength = 80
      PasswordChar = '*'
      TabOrder = 1
    end
    object chkShow: TCheckBox
      Left = 22
      Top = 181
      Width = 380
      Height = 24
      Caption = 'Show password'
      TabOrder = 2
      OnClick = chkShowClick
    end
    object btnSignIn: TButton
      Left = 22
      Top = 216
      Width = 168
      Height = 38
      Caption = '&Sign in'
      Default = True
      TabOrder = 3
      OnClick = btnSignInClick
    end
  end
  object pnlSubjects: TPanel
    Left = 255
    Top = 106
    Width = 636
    Height = 372
    BevelKind = bkFlat
    BevelOuter = bvNone
    Color = clWhite
    ParentBackground = False
    TabOrder = 4
    Visible = False
    object lblChoose: TLabel
      Left = 22
      Top = 25
      Width = 590
      Height = 36
      AutoSize = False
      Caption = 'Choose your teaching subject'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = 4073401
      Font.Height = -24
      Font.Name = 'Segoe UI'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object lblChooseHelp: TLabel
      Left = 22
      Top = 78
      Width = 590
      Height = 45
      AutoSize = False
      Caption = 
        'Each workspace includes CAPS, ATP, the illustrated guide and Tea' +
        'cher Bot.'
      WordWrap = True
    end
    object shpCATCard: TShape
      Left = 22
      Top = 125
      Width = 274
      Height = 63
      Brush.Color = 4073401
      Pen.Style = psClear
      Shape = stRoundRect
    end
    object lblCATCard: TLabel
      Left = 34
      Top = 135
      Width = 252
      Height = 21
      AutoSize = False
      Caption = 'CAT'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -18
      Font.Name = 'Segoe UI'
      Font.Style = [fsBold]
      ParentFont = False
      Transparent = True
    end
    object lblCATScope: TLabel
      Left = 34
      Top = 161
      Width = 252
      Height = 22
      AutoSize = False
      Caption = 'Computer Applications Technology'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -14
      Font.Name = 'Segoe UI'
      Font.Style = []
      ParentFont = False
      Transparent = True
    end
    object shpITCard: TShape
      Left = 340
      Top = 125
      Width = 274
      Height = 63
      Brush.Color = 5921300
      Pen.Style = psClear
      Shape = stRoundRect
    end
    object lblITCard: TLabel
      Left = 352
      Top = 135
      Width = 252
      Height = 21
      AutoSize = False
      Caption = 'IT'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -18
      Font.Name = 'Segoe UI'
      Font.Style = [fsBold]
      ParentFont = False
      Transparent = True
    end
    object lblITScope: TLabel
      Left = 352
      Top = 161
      Width = 252
      Height = 22
      AutoSize = False
      Caption = 'Information Technology'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -14
      Font.Name = 'Segoe UI'
      Font.Style = []
      ParentFont = False
      Transparent = True
    end
    object btnCAT: TButton
      Left = 22
      Top = 199
      Width = 274
      Height = 44
      Caption = 'Open &CAT guide'
      TabOrder = 0
      OnClick = btnCATClick
    end
    object btnIT: TButton
      Left = 340
      Top = 199
      Width = 274
      Height = 44
      Caption = 'Open &IT guide'
      TabOrder = 1
      OnClick = btnITClick
    end
    object btnSignOut: TButton
      Left = 22
      Top = 302
      Width = 172
      Height = 34
      Caption = 'Sign &out'
      TabOrder = 2
      OnClick = btnSignOutClick
    end
  end
  object pnlLoading: TPanel
    Left = 255
    Top = 106
    Width = 636
    Height = 343
    BevelKind = bkFlat
    BevelOuter = bvNone
    Color = clWhite
    ParentBackground = False
    TabOrder = 5
    object lblLoadTitle: TLabel
      Left = 22
      Top = 53
      Width = 590
      Height = 39
      AutoSize = False
      Caption = 'Preparing the teacher workspace'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = 4073401
      Font.Height = -24
      Font.Name = 'Segoe UI'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object lblLoadStatus: TLabel
      Left = 22
      Top = 131
      Width = 575
      Height = 26
      AutoSize = False
      Caption = 'Starting up...'
    end
    object prgLoad: TProgressBar
      Left = 22
      Top = 168
      Width = 590
      Height = 15
      Smooth = True
      TabOrder = 0
    end
  end
  object tmrGame: TTimer
    Enabled = False
    Interval = 20
    OnTimer = tmrGameTimer
  end
  object tmrPurpose: TTimer
    Enabled = False
    Interval = 410
    OnTimer = tmrPurposeTimer
  end
  object tmrLoad: TTimer
    Enabled = False
    Interval = 30
    OnTimer = tmrLoadTimer
    Left = 634
    Top = 32
  end
end
