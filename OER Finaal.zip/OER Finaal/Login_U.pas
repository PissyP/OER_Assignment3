unit Login_U;

interface

uses
  Winapi.Windows, System.Types, System.UITypes, Vcl.Graphics, System.Classes, System.SysUtils, Vcl.Forms, Vcl.StdCtrls,
  Vcl.ExtCtrls, Vcl.ComCtrls, Vcl.Dialogs, CAT_U, IT_U, Curriculum_U,
  Vcl.Controls;

type
  TfrmLogin = class(TForm)
    pnlBanner, pnlSignIn, pnlSubjects, pnlLoading, pnlPurpose, pnlGame: TPanel;
    lblBrand, lblSubtitle, lblSignIn, lblUsername, lblPassword,
      lblLoginStatus, lblChoose, lblChooseHelp, lblLoadTitle,
      lblLoadStatus: TLabel;
    lblPurposeTitle, lblPurposeAudience, lblPurposeRead, lblPurposeApply,
      lblPurposeReflect: TLabel;
    lblGameTitle, lblScore, lblGameStatus: TLabel;
    btnContinue, btnJump, btnFinishGame, btnHelp: TButton;
    pbxGame: TPaintBox;
    shpRailAccent, shpCATCard, shpITCard: TShape;
    lblEdition, lblPhase, lblCATCard, lblCATScope, lblITCard, lblITScope: TLabel;
    edtUsername, edtPassword: TEdit;
    chkShow: TCheckBox;
    btnSignIn, btnCAT, btnIT, btnSignOut: TButton;
    prgLoad: TProgressBar;
    tmrLoad, tmrPurpose, tmrGame: TTimer;
    procedure btnHelpClick(Sender: TObject);
    procedure btnJumpClick(Sender: TObject);
    procedure btnFinishGameClick(Sender: TObject);
    procedure tmrGameTimer(Sender: TObject);
    procedure pbxGamePaint(Sender: TObject);
    procedure FormKeyDown(Sender: TObject; var iKey: Word; Shift: TShiftState);
    procedure FormShow(Sender: TObject);
    procedure tmrLoadTimer(Sender: TObject);
    procedure tmrPurposeTimer(Sender: TObject);
    procedure btnContinueClick(Sender: TObject);
    procedure chkShowClick(Sender: TObject);
    procedure btnSignInClick(Sender: TObject);
    procedure btnCATClick(Sender: TObject);
    procedure btnITClick(Sender: TObject);
    procedure btnSignOutClick(Sender: TObject);
  private
    iStartTick: UInt64;
    iRevealStep: Integer;
    arrPurpose: array[1..5] of TLabel;
    bSignedIn: Boolean;
    iJumpHeight, iJumpSpeed, iCactusX, iScore, iBest: Integer;
    procedure ResetGame;
    procedure DrawGameBlock(iLeft, iTop, iRight, iBottom: Integer; clBlock: TColor);
    procedure OpenSubject(iSubject: Integer);
  end;

var
  frmLogin: TfrmLogin;

implementation

{$R *.dfm}

const
  iLoadDuration = 4400;
  sDemoUsername = 'teacher';
  sDemoPassword = 'BeyondLab2026';
  iGround = 158;
  iDinoX = 68;
  iCactusWidth = 24;
  iCactusHeight = 38;
  iDinoWidth = 45;
  iDinoHeight = 42;
  arrDino: array[1..14] of string = (
    '.........######', '.........##.###', '.........######',
    '.........###...', '#.......#####..', '##.....####....',
    '###...#######..', '.##########....', '..#########....',
    '...#######.....', '....#####......', '.....#..#......',
    '.....#..#......', '.....##.##.....');

procedure TfrmLogin.FormShow(Sender: TObject);
begin
  // Start the visual introduction once, without blocking Windows input.
  if iStartTick = 0 then
  begin
    iStartTick := GetTickCount64;
    tmrLoad.Enabled := True;
  end;
end;

procedure TfrmLogin.tmrLoadTimer(Sender: TObject);
var
  iElapsed: UInt64;
  iProgress: Integer;
begin
  // Base the bar on elapsed time so slow timer ticks do not extend the intro.
  iElapsed := GetTickCount64 - iStartTick;
  if iElapsed >= iLoadDuration then
  begin
    tmrLoad.Enabled := False;
    prgLoad.Position := 100;
    pnlLoading.Hide;
    arrPurpose[1] := lblPurposeTitle;
    arrPurpose[2] := lblPurposeAudience;
    arrPurpose[3] := lblPurposeRead;
    arrPurpose[4] := lblPurposeApply;
    arrPurpose[5] := lblPurposeReflect;
    iRevealStep := Low(arrPurpose);
    pnlPurpose.Show;
    tmrPurpose.Enabled := True;
    Exit;
  end;
  iProgress := MulDiv(Integer(iElapsed), 100, iLoadDuration);
  prgLoad.Position := iProgress;
  if iProgress < 35 then
    lblLoadStatus.Caption := 'Starting the resource...'
  else if iProgress < 75 then
    lblLoadStatus.Caption := 'Preparing the guidebook...'
  else
    lblLoadStatus.Caption := 'Opening the welcome page...';
end;

procedure TfrmLogin.tmrPurposeTimer(Sender: TObject);
begin
  // Reveal labels in reading order without blocking the message loop.
  if iRevealStep <= High(arrPurpose) then
  begin
    arrPurpose[iRevealStep].Show;
    Inc(iRevealStep);
    Exit;
  end;
  tmrPurpose.Enabled := False;
  btnContinue.Show;
  btnContinue.SetFocus;
end;

procedure TfrmLogin.btnContinueClick(Sender: TObject);
begin
  // Move from the completed reading sequence to the optional game.
  pnlPurpose.Hide;
  ResetGame;
  pnlGame.Show;
  btnJump.SetFocus;
end;

procedure TfrmLogin.chkShowClick(Sender: TObject);
begin
  // Let teachers check a typed demo password, then mask it again.
  if chkShow.Checked then
    edtPassword.PasswordChar := #0
  else
    edtPassword.PasswordChar := '*';
end;

procedure TfrmLogin.btnSignInClick(Sender: TObject);
begin
  // The public OER uses a local demo gate. It stores no user accounts.
  if not SameText(Trim(edtUsername.Text), sDemoUsername) or
    (edtPassword.Text <> sDemoPassword) then
  begin
    lblLoginStatus.Caption := 'Check the username and password and try again.';
    edtPassword.SelectAll;
    edtPassword.SetFocus;
    Exit;
  end;
  bSignedIn := True;
  edtPassword.Clear;
  chkShow.Checked := False;
  chkShowClick(nil);
  lblLoginStatus.Caption := '';
  pnlSignIn.Hide;
  pnlSubjects.Show;
  btnCAT.SetFocus;
end;

procedure TfrmLogin.OpenSubject(iSubject: Integer);
var
  frmSubject: TfrmCAT;
begin
  // Create only the workspace requested by a signed-in teacher.
  if not bSignedIn then
    Exit;
  try
    if iSubject = iCAT then
      frmSubject := TfrmCAT.Create(Self)
    else
      frmSubject := TfrmIT.Create(Self);
    try
      frmSubject.Initialize(iSubject);
      frmSubject.ShowModal;
    finally
      frmSubject.Free;
    end;
  except
    on E: Exception do
      MessageDlg('The subject workspace could not open.' + sLineBreak +
        E.Message, mtError, [mbOK], 0);
  end;
end;

procedure TfrmLogin.btnCATClick(Sender: TObject);
begin
  // Open the CAT workspace with CAT resources and knowledge checks.
  OpenSubject(iCAT);
end;

procedure TfrmLogin.btnITClick(Sender: TObject);
begin
  // Open the distinct IT form with the IT resource bank.
  OpenSubject(iIT);
end;

procedure TfrmLogin.btnSignOutClick(Sender: TObject);
begin
  // Clear credentials and return to the sign-in panel.
  bSignedIn := False;
  edtUsername.Clear;
  edtPassword.Clear;
  pnlSubjects.Hide;
  pnlSignIn.Show;
  edtUsername.SetFocus;
end;


procedure TfrmLogin.ResetGame;
begin
  // Reset a round and keep the best score for this launch.
  iJumpHeight := 0;
  iJumpSpeed := 0;
  iCactusX := 560;
  iScore := 0;
  lblScore.Caption := Format('Score %d   |   Best %d', [iScore, iBest]);
  pbxGame.Invalidate;
end;

procedure TfrmLogin.btnJumpClick(Sender: TObject);
begin
  // Start or retry a round, then allow jumping only from the ground.
  if not tmrGame.Enabled then
  begin
    ResetGame;
    lblGameStatus.Caption := 'Jump over each cactus. One point per cactus.';
    btnJump.Caption := '&Jump';
    tmrGame.Enabled := True;
  end;
  if iJumpHeight = 0 then
    iJumpSpeed := 13;
end;

procedure TfrmLogin.FormKeyDown(Sender: TObject; var iKey: Word; Shift: TShiftState);
begin
  // Support keyboard play in addition to the large on-screen button.
  if pnlGame.Visible and ((iKey = VK_SPACE) or (iKey = VK_UP)) then
  begin
    iKey := 0;
    btnJumpClick(Sender);
  end;
end;

procedure TfrmLogin.btnFinishGameClick(Sender: TObject);
begin
  // Stop animation before switching to the credential fields.
  tmrGame.Enabled := False;
  pnlGame.Hide;
  pnlSignIn.Show;
  edtUsername.SetFocus;
end;

procedure TfrmLogin.tmrGameTimer(Sender: TObject);
var
  iScrollSpeed: Integer;
begin
  // Move the cactus and integrate the jump using integer arithmetic.
  iScrollSpeed := 6 + iScore div 3;
  if iScrollSpeed > 12 then
    iScrollSpeed := 12;
  Dec(iCactusX, iScrollSpeed);
  if (iJumpHeight > 0) or (iJumpSpeed > 0) then
  begin
    Inc(iJumpHeight, iJumpSpeed);
    Dec(iJumpSpeed);
    if iJumpHeight <= 0 then
    begin
      iJumpHeight := 0;
      iJumpSpeed := 0;
    end;
  end;

  // Count only cleared obstacles. A collision pauses the round for a retry.
  if (iCactusX < iDinoX + iDinoWidth - 8) and
    (iCactusX + iCactusWidth > iDinoX + 8) and
    (iJumpHeight < iCactusHeight - 5) then
  begin
    tmrGame.Enabled := False;
    lblGameStatus.Caption := 'Round over. Try again or continue to sign in.';
    btnJump.Caption := '&Play again';
  end
  else if iCactusX + iCactusWidth < 0 then
  begin
    Inc(iScore);
    if iScore > iBest then
      iBest := iScore;
    lblScore.Caption := Format('Score %d   |   Best %d', [iScore, iBest]);
    iCactusX := 590 + Random(95);
  end;
  pbxGame.Invalidate;
end;

procedure TfrmLogin.DrawGameBlock(iLeft, iTop, iRight, iBottom: Integer;
  clBlock: TColor);
begin
  // Scale logical game coordinates to the paint box on high-DPI displays.
  pbxGame.Canvas.Brush.Color := clBlock;
  pbxGame.Canvas.FillRect(System.Types.Rect(MulDiv(iLeft, pbxGame.Width, 588),
    MulDiv(iTop, pbxGame.Height, 199), MulDiv(iRight, pbxGame.Width, 588),
    MulDiv(iBottom, pbxGame.Height, 199)));
end;

procedure TfrmLogin.pbxGamePaint(Sender: TObject);
var
  iRow, iCol, iX, iY: Integer;
begin
  // Draw the landscape, cactus and array-based dinosaur sprite.
  DrawGameBlock(0, 0, 588, 199, TColor($00E8F5FF));
  DrawGameBlock(476, 20, 510, 53, TColor($007DD9FF));
  DrawGameBlock(155, 44, 221, 53, clWhite);
  DrawGameBlock(182, 36, 212, 44, clWhite);
  DrawGameBlock(337, 70, 404, 78, clWhite);
  DrawGameBlock(0, iGround, 588, 199, TColor($00C3D7F0));
  DrawGameBlock(0, iGround, 588, iGround + 3, TColor($005B79A0));
  for iRow := Low(arrDino) to High(arrDino) do
    for iCol := 1 to Length(arrDino[iRow]) do
      if arrDino[iRow][iCol] = '#' then
      begin
        iX := iDinoX + (iCol - 1) * 3;
        iY := iGround - iDinoHeight - iJumpHeight + (iRow - 1) * 3;
        DrawGameBlock(iX, iY, iX + 3, iY + 3, TColor($00624E0B));
      end;
  DrawGameBlock(iCactusX + 9, iGround - iCactusHeight,
    iCactusX + 16, iGround, TColor($006B9028));
  DrawGameBlock(iCactusX, iGround - 25, iCactusX + 9,
    iGround - 13, TColor($006B9028));
  DrawGameBlock(iCactusX + 16, iGround - 30, iCactusX + iCactusWidth,
    iGround - 19, TColor($006B9028));
end;

procedure TfrmLogin.btnHelpClick(Sender: TObject);
var
  sHelp: string;
  bResumeGame: Boolean;
begin
  // Pause an active game while displaying help for the current screen.
  bResumeGame := tmrGame.Enabled;
  tmrGame.Enabled := False;
  try
    if pnlLoading.Visible then
      sHelp := 'Wait for the loading bar. The guidebook purpose appears next.'
    else if pnlPurpose.Visible then
      sHelp := 'Read each part of the introduction as it appears. Continue to game ' +
        'opens the optional dinosaur activity.'
    else if pnlGame.Visible then
      sHelp := 'Press Jump, Space or Up Arrow to leap over a cactus. Clear one ' +
        'for a point. Play again starts a new run. Continue to sign in skips the game.'
    else if pnlSignIn.Visible then
      sHelp := 'Enter the separately supplied username and password, then select ' +
        'Sign in. Show password toggles visibility while you type.'
    else
      sHelp := 'Choose CAT or IT to open its guidebook. Sign out returns you ' +
        'to the credential screen.';
    MessageDlg(sHelp, mtInformation, [mbOK], 0);
  finally
    tmrGame.Enabled := bResumeGame;
  end;
end;

end.
